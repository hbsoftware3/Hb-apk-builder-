plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

// owner/repo of the GitHub repository. GitHub Actions sets GITHUB_REPOSITORY by itself, so the
// update link always follows the repository the APK was built in (no username inside the code).
val repoSlug: String = (project.findProperty("GITHUB_REPO") as String?)
    ?: System.getenv("GITHUB_REPOSITORY")
    ?: "hbsoftware3/Hb"

android {
    namespace = "com.example.videodownloader"
    compileSdk = 35

    defaultConfig {
        // Package name of HB Super App
        applicationId = "com.hbsoftware.aio"
        minSdk = 29
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"
        buildConfigField("String", "UPDATE_JSON_URL", "\"https://raw.githubusercontent.com/$repoSlug/main/update-v1.json\"")
    }

    buildFeatures {
        buildConfig = true
    }

    // Signing: CI (GitHub Actions) passes the keystore through environment variables.
    // Same keystore every time = users can update without "App not installed".
    val ksPath: String? = System.getenv("KEYSTORE_PATH")
    signingConfigs {
        // Personal builds: the same fixed key every time (made by the workflow, stored encrypted), so a new APK installs over the old one
        getByName("debug") {
            val f = rootProject.file("signing/hb-debug.keystore")
            if (f.exists()) {
                storeFile = f
                val pw = System.getenv("HB_KEY_PASSWORD") ?: "android"
                storePassword = pw
                keyAlias = "androiddebugkey"
                keyPassword = pw
            }
        }
        if (!ksPath.isNullOrBlank()) {
            create("release") {
                storeFile = file(ksPath)
                storePassword = System.getenv("KEYSTORE_PASSWORD")
                keyAlias = System.getenv("KEY_ALIAS")
                keyPassword = System.getenv("KEY_PASSWORD")
            }
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            signingConfig = signingConfigs.findByName("release")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }

    packaging {
        jniLibs {
            useLegacyPackaging = true
        }
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("androidx.swiperefreshlayout:swiperefreshlayout:1.0.0")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.8.7")
    implementation("androidx.recyclerview:recyclerview:1.3.2")
    implementation("androidx.documentfile:documentfile:1.0.0")
    implementation("androidx.webkit:webkit:1.11.0")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.1")
    implementation("io.github.junkfood02.youtubedl-android:library:0.18.1")
    implementation("io.github.junkfood02.youtubedl-android:ffmpeg:0.18.1")

    // HB Media Player
    implementation("androidx.media3:media3-exoplayer:1.5.1")
    implementation("androidx.media3:media3-ui:1.5.1")
    implementation("androidx.media3:media3-session:1.5.1")

    // QR studio
    implementation("com.google.zxing:core:3.5.3")
    implementation("com.journeyapps:zxing-android-embedded:4.3.0")
}
