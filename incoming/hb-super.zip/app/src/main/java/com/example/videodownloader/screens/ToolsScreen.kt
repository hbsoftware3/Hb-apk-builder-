package com.example.videodownloader.screens

import android.text.Editable
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.LinearLayout
import com.example.videodownloader.MainActivity
import com.example.videodownloader.Prefs
import com.example.videodownloader.R
import com.example.videodownloader.ui.Hb
import com.example.videodownloader.ui.Screen
import com.example.videodownloader.util.Tool

class ToolsScreen(
    private val act: MainActivity,
    private val onTool: (Tool) -> Unit
) : Screen {

    private lateinit var search: EditText
    private lateinit var body: LinearLayout
    private var query = ""

    override val root: View = run {
        val c = act
        val p = Hb.palette(c)
        val col = Hb.column(c, 18)

        val header = LinearLayout(c).apply { orientation = LinearLayout.VERTICAL; setPadding(0, Hb.dp(c, 4), 0, 0) }
        header.addView(Hb.text(c, "Tools", 22f, p.text, bold = true))
        header.addView(Hb.text(c, "Real utilities, no demo screens", 11.5f, p.muted))
        col.addView(header)

        search = EditText(c).apply {
            hint = "Search tools"
            setHintTextColor(p.muted)
            setTextColor(p.text)
            textSize = 13f
            background = Hb.round(c, 16, p.surface, p.border, 1)
            setPadding(Hb.dp(c, 44), 0, Hb.dp(c, 14), 0)
            minHeight = Hb.dp(c, 52)
            setSingleLine()
            addTextChangedListener(object : TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
                override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                    query = s?.toString().orEmpty().trim()
                    buildBody()
                }
                override fun afterTextChanged(s: Editable?) {}
            })
        }
        val searchWrap = android.widget.FrameLayout(c).apply {
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, Hb.dp(c, 52)).apply {
                topMargin = Hb.dp(c, 14)
            }
            addView(search, android.widget.FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT
            ))
            addView(Hb.icon(c, R.drawable.ic_search, p.muted, 20), android.widget.FrameLayout.LayoutParams(
                Hb.dp(c, 20), Hb.dp(c, 20), Gravity.START or Gravity.CENTER_VERTICAL
            ).apply { marginStart = Hb.dp(c, 14) })
        }
        col.addView(searchWrap)

        body = Hb.listContainer(c)
        col.addView(body)
        buildBody()
        Hb.scroll(c, col)
    }

    private fun buildBody() {
        if (!::body.isInitialized) return
        val c = act
        body.removeAllViews()
        val q = query.lowercase()
        val matches = Tool.entries.filter {
            q.isBlank() || it.title.lowercase().contains(q) || it.subtitle.lowercase().contains(q) || it.category.lowercase().contains(q)
        }

        if (matches.isEmpty()) {
            body.addView(Hb.empty(c, R.drawable.ic_search, "No tools found", "Try “video”, “file”, “QR” or “PDF”"))
            return
        }

        if (q.isBlank()) {
            val favs = Prefs.favoriteTools(c).mapNotNull { Tool.from(it) }
            if (favs.isNotEmpty()) {
                body.addView(Hb.section(c, "Favorites"))
                body.addView(grid(favs))
            }
            Tool.entries.map { it.category }.distinct().forEach { cat ->
                val list = matches.filter { it.category == cat }
                if (list.isNotEmpty()) {
                    body.addView(Hb.section(c, cat))
                    body.addView(grid(list))
                }
            }
        } else {
            body.addView(Hb.section(c, "${matches.size} result${if (matches.size == 1) "" else "s"}"))
            body.addView(grid(matches))
        }
    }

    private fun grid(tools: List<Tool>): View {
        val c = act
        val wrap = LinearLayout(c).apply { orientation = LinearLayout.VERTICAL }
        tools.chunked(2).forEach { rowTools ->
            val row = LinearLayout(c).apply {
                orientation = LinearLayout.HORIZONTAL
                setPadding(0, 0, 0, Hb.dp(c, 10))
            }
            rowTools.forEachIndexed { i, tool ->
                row.addView(tile(tool), LinearLayout.LayoutParams(0, Hb.dp(c, 118), 1f).apply {
                    marginEnd = if (i == 0 && rowTools.size == 2) Hb.dp(c, 10) else 0
                })
            }
            if (rowTools.size == 1) row.addView(View(c), LinearLayout.LayoutParams(0, 1, 1f))
            wrap.addView(row)
        }
        return wrap
    }

    private fun tile(tool: Tool): LinearLayout {
        val c = act
        val p = Hb.palette(c)
        val fav = tool.id in Prefs.favoriteTools(c)
        val tile = LinearLayout(c).apply {
            orientation = LinearLayout.VERTICAL
            background = Hb.ripple(c, Hb.round(c, 20, p.surface, if (fav) p.blue else p.border, 1))
            setPadding(Hb.dp(c, 14), Hb.dp(c, 13), Hb.dp(c, 14), Hb.dp(c, 13))
        }
        val top = LinearLayout(c).apply { orientation = LinearLayout.HORIZONTAL }
        top.addView(Hb.iconCircle(c, tool.icon, p.blue, p.blueSoft, 40))
        val star = Hb.icon(c, R.drawable.ic_star, if (fav) p.warning else p.muted, 18)
        val starWrap = android.widget.FrameLayout(c).apply {
            addView(star, android.widget.FrameLayout.LayoutParams(Hb.dp(c, 18), Hb.dp(c, 18), Gravity.CENTER))
            layoutParams = LinearLayout.LayoutParams(Hb.dp(c, 30), Hb.dp(c, 30))
        }
        Hb.clickable(starWrap) { toggleFavorite(tool) }
        top.addView(starWrap)
        top.addView(View(c), LinearLayout.LayoutParams(0, 1, 1f))
        tile.addView(top)
        tile.addView(Hb.text(c, tool.title, 13.5f, p.text, medium = true).apply {
            setPadding(0, Hb.dp(c, 10), 0, 0)
        })
        tile.addView(Hb.text(c, tool.subtitle, 10.5f, p.muted).apply {
            setPadding(0, Hb.dp(c, 4), 0, 0)
            maxLines = 2
        })
        Hb.clickable(tile) { onTool(tool) }
        Hb.pressScale(tile)
        return tile
    }

    private fun toggleFavorite(tool: Tool) {
        val set = HashSet(Prefs.favoriteTools(act))
        if (!set.add(tool.id)) set.remove(tool.id)
        Prefs.setFavoriteTools(act, set)
        Hb.toast(act, if (tool.id in set) "${tool.title} added to favorites" else "${tool.title} removed from favorites")
        buildBody()
    }

    override fun refresh() {
        buildBody()
    }
}
