package com.example.videodownloader.files

import android.content.ContentUris
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.lifecycle.lifecycleScope
import com.example.videodownloader.R
import com.example.videodownloader.ui.BaseActivity
import com.example.videodownloader.ui.Hb
import com.example.videodownloader.util.Fmt
import com.example.videodownloader.util.Launcher
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

/** Searches Android's file index and the app's own folders by name. Results are opened with the right viewer. */
class FileSearchActivity : BaseActivity() {

    private data class Hit(val uri: android.net.Uri, val name: String, val mime: String, val size: Long, val where: String)

    private lateinit var results: LinearLayout
    private lateinit var summary: TextView
    private var job: kotlinx.coroutines.Job? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val p = Hb.palette(this)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(p.bg)
        }
        root.addView(Hb.topBar(this, "File Search", "Find any indexed file", { finish() }))

        val searchWrap = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(Hb.dp(this@FileSearchActivity, 16), Hb.dp(this@FileSearchActivity, 4),
                Hb.dp(this@FileSearchActivity, 16), Hb.dp(this@FileSearchActivity, 10))
        }
        val input = EditText(this).apply {
            hint = "File name, e.g. holiday or .pdf"
            setHintTextColor(p.muted)
            setTextColor(p.text)
            background = Hb.round(this@FileSearchActivity, 14, p.surfaceAlt, p.border, 1)
            setPadding(Hb.dp(this@FileSearchActivity, 14), Hb.dp(this@FileSearchActivity, 10),
                Hb.dp(this@FileSearchActivity, 14), Hb.dp(this@FileSearchActivity, 10))
            setSingleLine(true)
            imeOptions = EditorInfo.IME_ACTION_SEARCH
            setOnEditorActionListener { _, action, _ ->
                if (action == EditorInfo.IME_ACTION_SEARCH) {
                    search(text.toString())
                    true
                } else false
            }
        }
        searchWrap.addView(input, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        searchWrap.addView(Hb.iconButton(this, R.drawable.ic_search, p.text, 46) { search(input.text.toString()) }.apply {
            (layoutParams as LinearLayout.LayoutParams).marginStart = Hb.dp(this@FileSearchActivity, 8)
        })
        root.addView(searchWrap)

        summary = Hb.text(this, "Type a name to search", 11.5f, p.muted).apply {
            setPadding(Hb.dp(this@FileSearchActivity, 20), 0, Hb.dp(this@FileSearchActivity, 20), Hb.dp(this@FileSearchActivity, 6))
        }
        root.addView(summary)

        val scroll = ScrollView(this).apply { isFillViewport = true }
        results = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(Hb.dp(this@FileSearchActivity, 14), 0, Hb.dp(this@FileSearchActivity, 14), Hb.dp(this@FileSearchActivity, 30))
        }
        scroll.addView(results)
        root.addView(scroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))

        setContentView(root)
        results.addView(Hb.empty(this, R.drawable.ic_search, "Search your files", "Names are matched from Android's media index and HB AIO folders"))
        input.requestFocus()
    }

    private fun search(raw: String) {
        val query = raw.trim()
        if (query.isBlank()) {
            Hb.toast(this, "Enter a file name")
            return
        }
        job?.cancel()
        summary.text = "Searching…"
        results.removeAllViews()
        job = lifecycleScope.launch {
            val hits = withContext(Dispatchers.IO) { run(query) }
            if (hits.isEmpty()) {
                summary.text = "No matches"
                results.addView(Hb.empty(this@FileSearchActivity, R.drawable.ic_search, "Nothing found", "Try fewer words or a different extension"))
            } else {
                summary.text = "${hits.size} results"
                val card = Hb.card(this@FileSearchActivity, 6)
                hits.forEachIndexed { index, hit ->
                    card.addView(Hb.row(this@FileSearchActivity, iconFor(hit.mime), hit.name,
                        "${Fmt.bytes(hit.size)} • ${hit.where}") {
                        Launcher.openFile(this@FileSearchActivity, hit.uri, hit.mime)
                    })
                    if (index != hits.lastIndex) card.addView(Hb.divider(this@FileSearchActivity, 4))
                }
                results.addView(card)
            }
        }
    }

    private fun run(query: String): List<Hit> {
        val out = ArrayList<Hit>()
        val like = "%$query%"
        val files = MediaStore.Files.getContentUri(MediaStore.VOLUME_EXTERNAL)
        try {
            contentResolver.query(
                files,
                arrayOf(MediaStore.MediaColumns._ID, MediaStore.MediaColumns.DISPLAY_NAME,
                    MediaStore.MediaColumns.MIME_TYPE, MediaStore.MediaColumns.SIZE,
                    MediaStore.MediaColumns.RELATIVE_PATH),
                "${MediaStore.MediaColumns.DISPLAY_NAME} LIKE ?", arrayOf(like), null
            )?.use { cur ->
                while (cur.moveToNext() && out.size < 300) {
                    out.add(
                        Hit(
                            ContentUris.withAppendedId(files, cur.getLong(0)),
                            cur.getString(1) ?: "file",
                            cur.getString(2) ?: "*/*",
                            cur.getLong(3),
                            cur.getString(4)?.ifBlank { "Internal storage" } ?: "Internal storage"
                        )
                    )
                }
            }
        } catch (_: Exception) {
        }

        val roots = listOfNotNull(
            getExternalFilesDir(null),
            File(Environment.getExternalStorageDirectory(), "Download")
        )
        var budget = 6000
        roots.forEach { root ->
            val stack = ArrayDeque<File>()
            stack.add(root)
            while (stack.isNotEmpty() && budget > 0 && out.size < 400) {
                val dir = stack.removeFirst()
                val children = try { dir.listFiles() } catch (_: Exception) { null } ?: continue
                children.forEach { f ->
                    budget--
                    if (f.isDirectory) stack.add(f)
                    else if (f.name.contains(query, ignoreCase = true)) {
                        out.add(
                            Hit(
                                android.net.Uri.fromFile(f), f.name,
                                android.webkit.MimeTypeMap.getSingleton()
                                    .getMimeTypeFromExtension(Fmt.ext(f.name).lowercase()) ?: "*/*",
                                f.length(), "HB AIO folder"
                            )
                        )
                    }
                }
            }
        }
        return out.distinctBy { "${it.uri}|${it.name}" }.sortedByDescending { it.size }
    }

    private fun iconFor(mime: String): Int = when {
        mime.startsWith("video/") -> R.drawable.ic_play
        mime.startsWith("audio/") -> R.drawable.ic_music
        mime.startsWith("image/") -> R.drawable.ic_image
        mime == "application/pdf" -> R.drawable.ic_pdf
        mime.contains("zip") -> R.drawable.ic_zip
        else -> R.drawable.ic_file
    }
}
