package com.example.videodownloader.ui

import android.content.Context
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.example.videodownloader.Prefs

open class BaseActivity : AppCompatActivity() {
    override fun attachBaseContext(newBase: Context) {
        super.attachBaseContext(LocaleHelper.wrap(newBase))
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Hb.applySystemBars(this)
    }

    override fun onResume() {
        super.onResume()
        Hb.applySystemBars(this)
    }
}
