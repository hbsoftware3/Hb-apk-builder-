package com.example.videodownloader

import android.Manifest
import android.app.Activity
import android.content.ContentUris
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.DocumentsContract
import android.provider.MediaStore
import android.provider.Settings
import androidx.core.content.ContextCompat
import java.io.File
import android.util.LruCache
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit

/** The two apps whose statuses we can read. */
enum class WaApp(val label: String, val pkg: String, val folder: String, val key: String) {
    WHATSAPP("WhatsApp", "com.whatsapp", "WhatsApp", "wa"),
    BUSINESS("WhatsApp Business", "com.whatsapp.w4b", "WhatsApp Business", "wab")
}

/** One status file (photo or video) found in the WhatsApp .Statuses folder. */
data class StatusItem(
    val uri: Uri,
    val name: String,
    val mime: String,
    val modified: Long
) {
    val isVideo: Boolean get() = mime.startsWith("video/")
}

/**
 * Reads WhatsApp statuses. Android does not let apps read another app's folder directly, so the user
 * grants access ONCE to the .Statuses folder (Storage Access Framework) and we remember it.
 */
object StatusRepo {
    private const val AUTHORITY = "com.android.externalstorage.documents"

    private class Entry(val id: String, val name: String, val mime: String, val modified: Long) {
        val isDir: Boolean get() = mime == DocumentsContract.Document.MIME_TYPE_DIR
    }

    /**
     * Where the folder picker should open. Android 11+: Android/media/<app>/... ; older phones (or phones
     * where WhatsApp still uses the old place): <WhatsApp folder>/Media/.Statuses on the main storage.
     */
    fun initialUri(app: WaApp, legacy: Boolean): Uri {
        // NOTE: we open the visible "Media" folder, not the hidden ".Statuses" one - many folder pickers
        // cannot open a hidden (dot) folder and fall back to the storage root, so the user got lost.
        val docId =
            if (Build.VERSION.SDK_INT >= 30 && !legacy)
                "primary:Android/media/${app.pkg}/${app.folder}/Media"
            else
                "primary:${app.folder}/Media"
        return DocumentsContract.buildDocumentUri(AUTHORITY, docId)
    }

    private fun nameOf(c: Context, tree: Uri, docId: String): String? = try {
        val uri = DocumentsContract.buildDocumentUriUsingTree(tree, docId)
        c.contentResolver.query(uri, arrayOf(DocumentsContract.Document.COLUMN_DISPLAY_NAME), null, null, null)
            ?.use { if (it.moveToFirst()) it.getString(0) else null }
    } catch (_: Exception) {
        null
    }

    private fun children(c: Context, tree: Uri, parentId: String): List<Entry> {
        val out = mutableListOf<Entry>()
        val uri = DocumentsContract.buildChildDocumentsUriUsingTree(tree, parentId)
        c.contentResolver.query(
            uri,
            arrayOf(
                DocumentsContract.Document.COLUMN_DOCUMENT_ID,
                DocumentsContract.Document.COLUMN_DISPLAY_NAME,
                DocumentsContract.Document.COLUMN_MIME_TYPE,
                DocumentsContract.Document.COLUMN_LAST_MODIFIED
            ),
            null, null, null
        )?.use { cur ->
            while (cur.moveToNext()) {
                out += Entry(
                    cur.getString(0).orEmpty(),
                    cur.getString(1).orEmpty(),
                    cur.getString(2).orEmpty(),
                    if (cur.isNull(3)) 0L else cur.getLong(3)
                )
            }
        }
        return out
    }

    /**
     * The chosen folder may be .Statuses itself, or any parent of it (Media / WhatsApp / com.whatsapp ...).
     * Looks up to 5 levels down for the .Statuses folder. Returns its document id, or null if not found.
     */
    fun findStatusDir(c: Context, tree: Uri): String? = try {
        val rootId = DocumentsContract.getTreeDocumentId(tree)
        if (nameOf(c, tree, rootId).equals(".Statuses", ignoreCase = true)) {
            rootId
        } else {
            val skip = setOf(
                "whatsapp images", "whatsapp video", "whatsapp voice notes", "whatsapp documents",
                "whatsapp audio", "whatsapp animated gifs", "whatsapp stickers", "whatsapp profile photos",
                "whatsapp video notes", "whatsapp bug reports", "backups", "databases", "sent", "private"
            )
            var level = listOf(rootId)
            var found: String? = null
            var depth = 0
            var visited = 0
            while (found == null && level.isNotEmpty() && depth < 6 && visited < 200) {
                val next = mutableListOf<String>()
                for (parent in level) {
                    visited++
                    for (e in children(c, tree, parent)) {
                        if (!e.isDir) continue
                        if (e.name.equals(".Statuses", ignoreCase = true)) { found = e.id; break }
                        if (e.name.lowercase() !in skip) next += e.id
                    }
                    if (found != null) break
                }
                level = next
                depth++
            }
            found
        }
    } catch (_: Exception) {
        null
    }

    /**
     * Direct way (most reliable): with "All files access" (Android 11+) or storage permission (Android 10)
     * the app reads the WhatsApp .Statuses folder like a normal folder - no folder picker needed.
     */
    fun hasDirectAccess(c: Context): Boolean =
        if (Build.VERSION.SDK_INT >= 30) Environment.isExternalStorageManager()
        else ContextCompat.checkSelfPermission(c, Manifest.permission.READ_EXTERNAL_STORAGE) ==
            PackageManager.PERMISSION_GRANTED

    /** Opens Android's "All files access" switch for this app (Android 11+). */
    fun openAllFilesSettings(act: Activity) {
        try {
            act.startActivity(
                Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, Uri.parse("package:${act.packageName}"))
            )
        } catch (_: Exception) {
            try {
                act.startActivity(Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION))
            } catch (_: Exception) {
            }
        }
    }

    /** Every place WhatsApp may keep its statuses (new Android/media location and the old one). */
    private fun directDirs(app: WaApp): List<File> {
        val root = Environment.getExternalStorageDirectory()
        return listOf(
            File(root, "Android/media/${app.pkg}/${app.folder}/Media/.Statuses"),
            File(root, "${app.folder}/Media/.Statuses")
        )
    }

    /** Statuses read directly, newest first. null = the folder cannot be read / does not exist on this phone. */
    fun listDirect(app: WaApp): List<StatusItem>? {
        var found = false
        val out = LinkedHashMap<String, StatusItem>()
        for (dir in directDirs(app)) {
            val files = try {
                if (dir.isDirectory) dir.listFiles() else null
            } catch (_: Exception) {
                null
            } ?: continue
            found = true
            for (f in files) {
                if (!f.isFile || f.length() <= 0L) continue
                val mime = mimeFromName(f.name) ?: continue
                out.putIfAbsent(f.name, StatusItem(Uri.fromFile(f), f.name, mime, f.lastModified()))
            }
        }
        return if (found) out.values.sortedByDescending { it.modified } else null
    }

    /** Image/video mime of a status file; looks at the extension when the folder reports a generic type. */
    private fun mimeOf(e: Entry): String? {
        if (e.mime.startsWith("image/") || e.mime.startsWith("video/")) return e.mime
        return mimeFromName(e.name)
    }

    private fun mimeFromName(name: String): String? {
        return when (name.substringAfterLast('.', "").lowercase()) {
            "jpg", "jpeg" -> "image/jpeg"
            "png" -> "image/png"
            "webp" -> "image/webp"
            "gif" -> "image/gif"
            "mp4" -> "video/mp4"
            "3gp" -> "video/3gpp"
            "mkv" -> "video/x-matroska"
            "webm" -> "video/webm"
            else -> null // .nomedia and other junk
        }
    }

    /** Statuses, newest first. null = no access / folder not found. */
    fun list(c: Context, tree: Uri): List<StatusItem>? {
        val dirId = findStatusDir(c, tree) ?: return null
        return try {
            children(c, tree, dirId)
                .filter { !it.isDir }
                .mapNotNull { e ->
                    val mime = mimeOf(e)
                    if (mime == null) null
                    else StatusItem(DocumentsContract.buildDocumentUriUsingTree(tree, e.id), e.name, mime, e.modified)
                }
                .sortedByDescending { it.modified }
        } catch (_: Exception) {
            null
        }
    }

    /** Statuses already saved on this phone by this app (DCIM/HB AIO/Status), newest first. */
    fun listSaved(c: Context): List<StatusItem> {
        val out = mutableListOf<StatusItem>()
        listOf(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, MediaStore.Images.Media.EXTERNAL_CONTENT_URI)
            .forEach { base ->
                try {
                    c.contentResolver.query(
                        base,
                        arrayOf(
                            MediaStore.MediaColumns._ID,
                            MediaStore.MediaColumns.DISPLAY_NAME,
                            MediaStore.MediaColumns.MIME_TYPE,
                            MediaStore.MediaColumns.DATE_ADDED
                        ),
                        "${MediaStore.MediaColumns.RELATIVE_PATH} LIKE ?",
                        arrayOf("DCIM/HB AIO/Status%"),
                        null
                    )?.use { cur ->
                        while (cur.moveToNext()) {
                            out += StatusItem(
                                ContentUris.withAppendedId(base, cur.getLong(0)),
                                cur.getString(1).orEmpty(),
                                cur.getString(2).orEmpty(),
                                cur.getLong(3) * 1000
                            )
                        }
                    }
                } catch (_: Exception) {
                }
            }
        return out.sortedByDescending { it.modified }
    }

    /** Deletes a status that was saved by this app. */
    fun deleteSaved(c: Context, item: StatusItem): Boolean = try {
        val n = c.contentResolver.delete(item.uri, null, null)
        if (n > 0) {
            // saved name is "Status_<time>_<original name>"; forget the original name so it can be saved again
            Prefs.unmarkStatusSaved(c, item.name.removePrefix("Status_").substringAfter('_'))
        }
        n > 0
    } catch (_: Exception) {
        false
    }

    /** Copies a status into the gallery (DCIM/HB AIO/Status). */
    fun save(c: Context, item: StatusItem): Boolean {
        val isVideo = item.isVideo
        val collection =
            if (isVideo) MediaStore.Video.Media.EXTERNAL_CONTENT_URI else MediaStore.Images.Media.EXTERNAL_CONTENT_URI
        val now = System.currentTimeMillis()
        val safeName = ("Status_${now}_" + item.name).replace(Regex("[\\\\/:*?\"<>|\\r\\n]"), "_")
        val values = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, safeName)
            put(MediaStore.MediaColumns.MIME_TYPE, item.mime)
            put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DCIM + "/HB AIO/Status")
            put(MediaStore.MediaColumns.DATE_ADDED, now / 1000)
            put(MediaStore.MediaColumns.DATE_MODIFIED, now / 1000)
            put(MediaStore.MediaColumns.DATE_TAKEN, now)
            put(MediaStore.MediaColumns.IS_PENDING, 1)
        }
        val out = c.contentResolver.insert(collection, values) ?: return false
        return try {
            c.contentResolver.openInputStream(item.uri)!!.use { input ->
                c.contentResolver.openOutputStream(out)!!.use { o -> input.copyTo(o) }
            }
            c.contentResolver.update(
                out,
                ContentValues().apply {
                    put(MediaStore.MediaColumns.IS_PENDING, 0)
                    put(MediaStore.MediaColumns.DATE_TAKEN, now)
                },
                null, null
            )
            Prefs.markStatusSaved(c, item.name)
            true
        } catch (_: Exception) {
            try { c.contentResolver.delete(out, null, null) } catch (_: Exception) { }
            false
        }
    }
}

/** Small preview pictures for the status grid (photos: scaled down; videos: first frame). */
object Thumbs {
    private val cache = LruCache<String, Bitmap>(80)
    private val gate = Semaphore(3) // never decode more than 3 at once

    suspend fun get(c: Context, item: StatusItem, px: Int): Bitmap? = gate.withPermit {
        val key = "${item.uri}#$px"
        cache.get(key) ?: decode(c, item, px)?.also { cache.put(key, it) }
    }

    private fun decode(c: Context, item: StatusItem, px: Int): Bitmap? = try {
        if (item.isVideo) {
            val r = MediaMetadataRetriever()
            try {
                r.setDataSource(c, item.uri)
                val f = r.getFrameAtTime(0, MediaMetadataRetriever.OPTION_CLOSEST_SYNC) ?: r.frameAtTime
                f?.let { scaleDown(it, px) }
            } finally {
                try { r.release() } catch (_: Exception) { }
            }
        } else {
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            c.contentResolver.openInputStream(item.uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
            var sample = 1
            while (bounds.outWidth / (sample * 2) >= px && bounds.outHeight / (sample * 2) >= px) sample *= 2
            val opts = BitmapFactory.Options().apply { inSampleSize = sample }
            c.contentResolver.openInputStream(item.uri)?.use { BitmapFactory.decodeStream(it, null, opts) }
        }
    } catch (_: Exception) {
        null
    }

    private fun scaleDown(b: Bitmap, px: Int): Bitmap {
        val m = maxOf(b.width, b.height)
        if (m <= px * 2) return b
        val s = (px * 2).toFloat() / m
        return Bitmap.createScaledBitmap(b, (b.width * s).toInt().coerceAtLeast(1), (b.height * s).toInt().coerceAtLeast(1), true)
    }
}
