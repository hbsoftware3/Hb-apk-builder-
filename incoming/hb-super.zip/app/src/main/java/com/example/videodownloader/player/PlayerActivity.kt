package com.example.videodownloader.player

import android.Manifest
import android.content.ComponentName
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.graphics.Color
import android.media.AudioManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.Rational
import android.view.GestureDetector
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.core.content.ContextCompat
import androidx.core.view.isVisible
import androidx.lifecycle.lifecycleScope
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.TrackSelectionOverride
import androidx.media3.common.VideoSize
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import com.example.videodownloader.Prefs
import com.example.videodownloader.R
import com.example.videodownloader.ui.BaseActivity
import com.example.videodownloader.ui.Hb
import com.example.videodownloader.util.Fmt
import com.example.videodownloader.util.MediaIndex
import com.example.videodownloader.util.RecentMedia
import com.example.videodownloader.util.RecentStore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class PlayerActivity : BaseActivity() {

    private data class LocalItem(val uri: Uri, val name: String, val mime: String)

    private lateinit var playerView: PlayerView
    private lateinit var gestureView: View
    private lateinit var controls: FrameLayout
    private lateinit var startPanel: ScrollView
    private lateinit var startCol: LinearLayout
    private lateinit var buffer: ProgressBar
    private lateinit var titleText: TextView
    private lateinit var subtitleText: TextView
    private lateinit var playIcon: android.widget.ImageView
    private lateinit var seekBar: SeekBar
    private lateinit var timeCurrent: TextView
    private lateinit var timeTotal: TextView
    private lateinit var gestureHint: TextView
    private lateinit var unlockButton: FrameLayout
    private lateinit var queueLabel: android.widget.LinearLayout

    private var controller: MediaController? = null
    private var releaseController: (() -> Unit)? = null
    private var pendingItems: List<LocalItem>? = null
    private var pendingIndex = 0
    private var dragging = false
    private var locked = false
    private var tickerOn = false
    private var libraryJob: Job? = null

    private val handler = Handler(Looper.getMainLooper())
    private val ticker = object : Runnable {
        override fun run() {
            updateProgress()
            if (tickerOn) handler.postDelayed(this, 500)
        }
    }

    private val hideControls = Runnable {
        if (controller?.isPlaying == true && !locked) controls.isVisible = false
    }

    private val notificationPermission = registerForActivityResult(ActivityResultContracts.RequestPermission()) { }

    private val addFilesPicker = registerForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        if (uris.isNullOrEmpty()) return@registerForActivityResult
        val c = controller ?: return@registerForActivityResult
        val items = uris.map { LocalItem(it, Fmt.name(this, it), Fmt.mime(this, it)) }
        val media = items.map { item ->
            MediaItem.Builder().setUri(item.uri).setMediaId(item.uri.toString())
                .setMimeType(item.mime)
                .setMediaMetadata(MediaMetadata.Builder().setTitle(item.name).build()).build()
        }
        val wasEmpty = c.mediaItemCount == 0
        c.addMediaItems(media)
        if (wasEmpty) {
            c.seekTo(0, 0)
            c.prepare()
            c.play()
            c.setPlaybackSpeed(Prefs.playerSpeed(this))
            startPanel.isVisible = false
            controls.isVisible = true
            val first = items.first()
            titleText.text = first.name
            subtitleText.text = "${if (first.mime.startsWith("audio/")) "Audio" else "Video"} • ${items.size} in queue"
            addRecent(media.first(), 0)
            ensureNotifications()
            scheduleControls()
        }
        updateQueueLabel()
        Hb.toast(this, "${items.size} file${if (items.size == 1) "" else "s"} added to the queue")
    }

    private val playerListener = object : Player.Listener {
        override fun onIsPlayingChanged(isPlaying: Boolean) {
            updatePlayIcon()
            scheduleControls()
        }

        override fun onPlaybackStateChanged(playbackState: Int) {
            buffer.isVisible = playbackState == Player.STATE_BUFFERING
            if (playbackState == Player.STATE_READY) {
                updateProgress()
            }
            if (playbackState == Player.STATE_ENDED) {
                saveProgress()
                showControls()
            }
        }

        override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
            mediaItem ?: return
            titleText.text = mediaItem.mediaMetadata.title ?: "Unknown media"
            subtitleText.text = subtitleFor(mediaItem)
            addRecent(mediaItem, controller?.currentPosition?.coerceAtLeast(0) ?: 0)
            updatePlayIcon()
            updateQueueLabel()
        }

        override fun onPlayerError(error: PlaybackException) {
            buffer.isVisible = false
            showControls()
            Hb.toast(this@PlayerActivity, error.message?.take(120) ?: "Could not play this file")
        }

        override fun onVideoSizeChanged(videoSize: VideoSize) {
            updatePipParams()
        }

        override fun onTracksChanged(tracks: androidx.media3.common.Tracks) {
            // Subtitle tracks are read on demand from the menu.
        }
    }

    private val seekListener = object : SeekBar.OnSeekBarChangeListener {
        override fun onProgressChanged(bar: SeekBar?, progress: Int, fromUser: Boolean) {
            if (!fromUser) return
            val c = controller ?: return
            val duration = c.duration
            if (duration > 0) {
                timeCurrent.text = Fmt.duration((duration * progress) / 1000)
            }
        }

        override fun onStartTrackingTouch(bar: SeekBar?) {
            dragging = true
        }

        override fun onStopTrackingTouch(bar: SeekBar?) {
            val c = controller ?: return
            val duration = c.duration
            if (duration > 0 && bar != null) c.seekTo((duration * bar.progress) / 1000)
            dragging = false
            scheduleControls()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        volumeControlStream = AudioManager.STREAM_MUSIC
        buildUi()
        connectController()
        handleIntent(intent)
    }

    // ------------------------------------------------------------------ UI

    private fun buildUi() {
        val root = FrameLayout(this).apply { setBackgroundColor(Color.BLACK) }

        playerView = PlayerView(this).apply {
            useController = false
            setShowBuffering(PlayerView.SHOW_BUFFERING_NEVER)
            setBackgroundColor(Color.BLACK)
            resizeMode = RESIZE_MODES[Prefs.playerAspect(this@PlayerActivity).coerceIn(0, RESIZE_MODES.lastIndex)]
            setKeepContentOnPlayerReset(true)
        }
        root.addView(playerView, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

        gestureView = View(this)
        root.addView(gestureView, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

        startPanel = ScrollView(this).apply {
            setBackgroundColor(0xF205080D.toInt())
            isFillViewport = true
            visibility = View.GONE
        }
        startCol = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(Hb.dp(this@PlayerActivity, 18), Hb.dp(this@PlayerActivity, 26),
                Hb.dp(this@PlayerActivity, 18), Hb.dp(this@PlayerActivity, 28))
        }
        startPanel.addView(startCol)
        root.addView(startPanel, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

        buffer = ProgressBar(this).apply {
            indeterminateTintList = android.content.res.ColorStateList.valueOf(Hb.palette(this@PlayerActivity).blue)
            visibility = View.GONE
        }
        root.addView(buffer, FrameLayout.LayoutParams(Hb.dp(this, 44), Hb.dp(this, 44), Gravity.CENTER))

        gestureHint = Hb.text(this, "", 15f, Color.WHITE, bold = true).apply {
            gravity = Gravity.CENTER
            setPadding(Hb.dp(this@PlayerActivity, 16), Hb.dp(this@PlayerActivity, 10),
                Hb.dp(this@PlayerActivity, 16), Hb.dp(this@PlayerActivity, 10))
            background = Hb.round(this@PlayerActivity, 14, 0xCC0B1220.toInt())
            visibility = View.GONE
        }
        root.addView(gestureHint, FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.CENTER))

        controls = buildControls()
        root.addView(controls, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

        unlockButton = FrameLayout(this).apply {
            background = Hb.round(this@PlayerActivity, 22, 0x990B1220.toInt())
            addView(Hb.icon(this@PlayerActivity, R.drawable.ic_lock, Color.WHITE, 20),
                FrameLayout.LayoutParams(Hb.dp(this@PlayerActivity, 20), Hb.dp(this@PlayerActivity, 20), Gravity.CENTER))
            visibility = View.GONE
            Hb.clickable(this) {
                locked = false
                unlockButton.visibility = View.GONE
                showControls()
            }
        }
        root.addView(unlockButton, FrameLayout.LayoutParams(Hb.dp(this, 44), Hb.dp(this, 44), Gravity.TOP or Gravity.END).apply {
            topMargin = Hb.dp(this@PlayerActivity, 54)
            marginEnd = Hb.dp(this@PlayerActivity, 16)
        })

        setContentView(root)
        installGestures()
        updatePlayIcon()
    }

    private fun buildControls(): FrameLayout {
        val layer = FrameLayout(this).apply {
            setBackgroundColor(0x22000000)
            isClickable = true
            setOnClickListener { hideControlsNow() }
        }

        val top = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(Hb.dp(this@PlayerActivity, 12), Hb.dp(this@PlayerActivity, 10),
                Hb.dp(this@PlayerActivity, 12), Hb.dp(this@PlayerActivity, 10))
        }
        top.addView(glassyButton(R.drawable.ic_back) { finish() })
        val titles = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(Hb.dp(this@PlayerActivity, 10), 0, Hb.dp(this@PlayerActivity, 8), 0)
        }
        titleText = Hb.text(this, "Media Player", 15.5f, Color.WHITE, medium = true).apply { maxLines = 1 }
        subtitleText = Hb.text(this, "Local videos and music", 11f, 0xAAFFFFFF.toInt()).apply { maxLines = 1 }
        titles.addView(titleText)
        titles.addView(subtitleText)
        top.addView(titles, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        top.addView(glassyButton(R.drawable.ic_pip) { enterPip() })
        top.addView(glassyButton(R.drawable.ic_lock) { lockScreen() }.apply {
            (layoutParams as LinearLayout.LayoutParams).marginStart = Hb.dp(this@PlayerActivity, 6)
        })
        top.addView(glassyButton(R.drawable.ic_more) { showMenu() }.apply {
            (layoutParams as LinearLayout.LayoutParams).marginStart = Hb.dp(this@PlayerActivity, 6)
        })
        layer.addView(top, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.TOP))

        val center = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setPadding(0, 0, 0, Hb.dp(this@PlayerActivity, 40))
        }
        center.addView(glassyButton(R.drawable.ic_back, 48) { previous() })
        val play = FrameLayout(this).apply {
            background = Hb.gradient(this@PlayerActivity, 40, Hb.palette(this@PlayerActivity).blue, 0xFF0668E8.toInt())
            layoutParams = LinearLayout.LayoutParams(Hb.dp(this@PlayerActivity, 68), Hb.dp(this@PlayerActivity, 68)).apply {
                marginStart = Hb.dp(this@PlayerActivity, 24)
                marginEnd = Hb.dp(this@PlayerActivity, 24)
            }
            playIcon = Hb.icon(this@PlayerActivity, R.drawable.ic_play, Color.WHITE, 30)
            addView(playIcon, FrameLayout.LayoutParams(Hb.dp(this@PlayerActivity, 30), Hb.dp(this@PlayerActivity, 30), Gravity.CENTER))
            Hb.clickable(this) { togglePlay() }
        }
        center.addView(play)
        center.addView(glassyButton(R.drawable.ic_forward, 48) { next() })
        layer.addView(center, FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.CENTER))

        val bottom = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = Hb.round(this@PlayerActivity, 20, 0xD90B1220.toInt())
            setPadding(Hb.dp(this@PlayerActivity, 14), Hb.dp(this@PlayerActivity, 10),
                Hb.dp(this@PlayerActivity, 14), Hb.dp(this@PlayerActivity, 12))
        }
        val times = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        timeCurrent = Hb.text(this, "0:00", 11f, Color.WHITE, medium = true)
        timeTotal = Hb.text(this, "0:00", 11f, 0xAAFFFFFF.toInt())
        times.addView(timeCurrent, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        times.addView(timeTotal)
        seekBar = SeekBar(this).apply {
            max = 1000
            progressTintList = android.content.res.ColorStateList.valueOf(Hb.palette(this@PlayerActivity).blue)
            thumbTintList = android.content.res.ColorStateList.valueOf(Hb.palette(this@PlayerActivity).blue)
            progressBackgroundTintList = android.content.res.ColorStateList.valueOf(0x553A4A63)
            setOnSeekBarChangeListener(seekListener)
        }
        bottom.addView(seekBar, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, Hb.dp(this@PlayerActivity, 34)))
        bottom.addView(times)

        val actions = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, Hb.dp(this@PlayerActivity, 4), 0, 0)
        }
        actions.addView(miniAction(R.drawable.ic_speed, "Speed") { speedDialog() })
        actions.addView(miniAction(R.drawable.ic_fullscreen, "Aspect") { aspectDialog() })
        actions.addView(miniAction(R.drawable.ic_text, "Subtitles") { subtitleDialog() })
        queueLabel = miniAction(R.drawable.ic_grid, "Queue") { queueDialog() }
        actions.addView(queueLabel)
        actions.addView(miniAction(R.drawable.ic_add, "Add files") { addFiles() })
        bottom.addView(actions)

        layer.addView(bottom, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM).apply {
            marginStart = Hb.dp(this@PlayerActivity, 12)
            marginEnd = Hb.dp(this@PlayerActivity, 12)
            bottomMargin = Hb.dp(this@PlayerActivity, 14)
        })
        return layer
    }

    private fun glassyButton(icon: Int, size: Int = 40, onTap: () -> Unit): FrameLayout {
        val sizeDp = Hb.dp(this, size)
        val f = FrameLayout(this).apply {
            background = Hb.round(this@PlayerActivity, size / 2f, 0x660B1220)
            layoutParams = LinearLayout.LayoutParams(sizeDp, sizeDp)
            addView(Hb.icon(this@PlayerActivity, icon, Color.WHITE, (size * 0.48f)),
                FrameLayout.LayoutParams(Hb.dp(this@PlayerActivity, (size * 0.48f)), Hb.dp(this@PlayerActivity, (size * 0.48f)), Gravity.CENTER))
            Hb.clickable(this, onTap)
        }
        return f
    }

    private fun miniAction(icon: Int, label: String, onTap: () -> Unit): LinearLayout =
        LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(Hb.dp(this@PlayerActivity, 4), Hb.dp(this@PlayerActivity, 6),
                Hb.dp(this@PlayerActivity, 4), Hb.dp(this@PlayerActivity, 2))
            addView(Hb.icon(this@PlayerActivity, icon, 0xCCFFFFFF.toInt(), 19))
            addView(Hb.text(this@PlayerActivity, label, 9f, 0xAAFFFFFF.toInt()).apply {
                setPadding(0, Hb.dp(this@PlayerActivity, 2), 0, 0)
            })
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            Hb.clickable(this, onTap)
        }

    private fun installGestures() {
        val density = resources.displayMetrics.density
        val detector = GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onSingleTapConfirmed(e: MotionEvent): Boolean {
                if (locked) return true
                if (startPanel.isVisible) return false
                toggleControls()
                return true
            }

            override fun onDoubleTap(e: MotionEvent): Boolean {
                if (locked) return true
                seekRelative(if (e.x < playerView.width / 2) -10_000 else 10_000)
                return true
            }
        })
        var downX = 0f
        var downY = 0f
        var startPosition = 0L
        gestureView.setOnTouchListener { _, event ->
            if (locked || startPanel.isVisible) return@setOnTouchListener false
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    downX = event.x
                    downY = event.y
                    startPosition = controller?.currentPosition ?: 0L
                    gestureHint.isVisible = false
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = event.x - downX
                    val dy = event.y - downY
                    if (kotlin.math.abs(dx) > kotlin.math.abs(dy) && kotlin.math.abs(dx) > 26 * density) {
                        val seconds = ((dx / playerView.width) * 60).toInt()
                        gestureHint.text = if (seconds >= 0) "+$seconds s" else "$seconds s"
                        gestureHint.isVisible = true
                    } else {
                        gestureHint.isVisible = false
                    }
                }
                MotionEvent.ACTION_UP -> {
                    val dx = event.x - downX
                    val dy = event.y - downY
                    gestureHint.isVisible = false
                    if (kotlin.math.abs(dx) > kotlin.math.abs(dy) && kotlin.math.abs(dx) > 40 * density) {
                        val delta = ((dx / playerView.width) * 60_000).toLong()
                        controller?.seekTo((startPosition + delta).coerceAtLeast(0))
                    } else if (kotlin.math.abs(dy) > 40 * density) {
                        if (downX > playerView.width / 2f) adjustVolume(-dy / playerView.height) else adjustBrightness(-dy / playerView.height)
                    }
                }
            }
            detector.onTouchEvent(event)
            true
        }
    }

    // ------------------------------------------------------------------ controller

    private fun connectController() {
        val token = SessionToken(this, ComponentName(this, PlaybackService::class.java))
        val future = MediaController.Builder(this, token).buildAsync()
        releaseController = { MediaController.releaseFuture(future) }
        future.addListener({
            try {
                val c = future.get()
                controller = c
                playerView.player = c
                c.addListener(playerListener)
                c.setPlaybackSpeed(Prefs.playerSpeed(this))
                updateQueueLabel()
                val items = pendingItems
                if (items != null) {
                    playNow(items, pendingIndex)
                } else {
                    showStartPanel()
                }
            } catch (_: Exception) {
                Hb.toast(this, "The media service could not start")
                showStartPanel()
            }
        }, ContextCompat.getMainExecutor(this))
    }

    private fun handleIntent(intent: Intent?) {
        intent ?: return
        val data = intent.data
        val list = intent.getStringArrayListExtra(EXTRA_URIS)
        val names = intent.getStringArrayListExtra(EXTRA_NAMES)
        val mimes = intent.getStringArrayListExtra(EXTRA_MIMES)
        val index = intent.getIntExtra(EXTRA_INDEX, 0)
        val items: List<LocalItem>? = when {
            list != null && list.isNotEmpty() -> list.mapIndexed { i, value ->
                LocalItem(
                    Uri.parse(value),
                    names?.getOrNull(i)?.takeIf { it.isNotBlank() } ?: Fmt.titleFromUrl(value),
                    mimes?.getOrNull(i) ?: mimeOf(Uri.parse(value))
                )
            }
            data != null -> listOf(LocalItem(data, intent.getStringExtra(EXTRA_TITLE) ?: Fmt.name(this, data), intent.type ?: mimeOf(data)))
            else -> null
        }
        if (items == null) {
            showStartPanel()
            return
        }
        pendingItems = items
        pendingIndex = index.coerceIn(0, items.lastIndex)
        startPanel.isVisible = false
        if (controller != null) playNow(items, pendingIndex)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleIntent(intent)
    }

    private fun playNow(items: List<LocalItem>, index: Int) {
        val c = controller ?: return
        val media = items.map { item ->
            MediaItem.Builder()
                .setUri(item.uri)
                .setMediaId(item.uri.toString())
                .setMimeType(item.mime)
                .setMediaMetadata(MediaMetadata.Builder().setTitle(item.name).build())
                .build()
        }
        val chosen = items[index]
        val resume = if (Prefs.playerResume(this)) RecentStore.position(this, chosen.uri.toString()) else 0L
        c.setMediaItems(media, index, if (resume > 3000) resume else 0)
        c.prepare()
        c.play()
        c.setPlaybackSpeed(Prefs.playerSpeed(this))
        startPanel.isVisible = false
        controls.isVisible = true
        ensureNotifications()
        titleText.text = chosen.name
        subtitleText.text = "${if (chosen.mime.startsWith("audio/")) "Audio" else "Video"} • ${items.size} in queue"
        addRecent(media[index], resume.coerceAtLeast(0))
        updateQueueLabel()
    }

    private fun togglePlay() {
        val c = controller ?: return
        if (c.isPlaying) c.pause() else {
            if (c.playbackState == Player.STATE_IDLE) c.prepare()
            c.play()
            ensureNotifications()
        }
        updatePlayIcon()
        scheduleControls()
    }

    private fun previous() {
        val c = controller ?: return
        if (c.currentPosition > 4000) c.seekTo(0) else if (c.hasPreviousMediaItem()) c.seekToPreviousMediaItem() else c.seekTo(0)
    }

    private fun next() {
        val c = controller ?: return
        if (c.hasNextMediaItem()) c.seekToNextMediaItem() else c.seekTo(0)
    }

    private fun seekRelative(ms: Long) {
        val c = controller ?: return
        c.seekTo((c.currentPosition + ms).coerceAtLeast(0))
        gestureHint.text = if (ms > 0) "+${ms / 1000} s" else "${ms / 1000} s"
        gestureHint.isVisible = true
        handler.postDelayed({ gestureHint.isVisible = false }, 700)
    }

    private fun updatePlayIcon() {
        val playing = controller?.isPlaying == true
        playIcon.setImageResource(if (playing) R.drawable.ic_pause else R.drawable.ic_play)
        if (playing) ensureNotifications()
    }

    private fun updateProgress() {
        val c = controller ?: return
        val duration = c.duration.coerceAtLeast(0)
        if (!dragging) {
            seekBar.progress = if (duration > 0) ((c.currentPosition * 1000) / duration).toInt().coerceIn(0, 1000) else 0
            timeCurrent.text = Fmt.duration(c.currentPosition)
            timeTotal.text = Fmt.duration(duration)
        }
        if (queueLabel.isVisible) updateQueueLabel()
        buffer.isVisible = c.playbackState == Player.STATE_BUFFERING
    }

    private fun updateQueueLabel() {
        val count = controller?.mediaItemCount ?: 0
        val current = (controller?.currentMediaItemIndex ?: 0) + 1
        val text = if (count > 0) "$current/$count" else "Queue"
        (queueLabel.getChildAt(1) as? TextView)?.text = text
    }

    private fun subtitleFor(item: MediaItem): String {
        val c = controller
        val audio = item.localConfiguration?.mimeType?.startsWith("audio/") == true
        val count = c?.mediaItemCount ?: 1
        val index = (c?.currentMediaItemIndex ?: 0) + 1
        return "${if (audio) "Audio" else "Video"} • $index of $count"
    }

    // ------------------------------------------------------------------ controls visibility

    private fun showControls() {
        if (locked) return
        controls.isVisible = true
        scheduleControls()
    }

    private fun hideControlsNow() {
        if (locked) return
        controls.isVisible = false
        handler.removeCallbacks(hideControls)
    }

    private fun toggleControls() {
        if (controls.isVisible) hideControlsNow() else showControls()
    }

    private fun scheduleControls() {
        handler.removeCallbacks(hideControls)
        if (controller?.isPlaying == true && !locked) handler.postDelayed(hideControls, 4200)
    }

    private fun lockScreen() {
        locked = true
        controls.isVisible = false
        unlockButton.isVisible = true
        handler.removeCallbacks(hideControls)
        Hb.toast(this, "Screen locked. Tap the lock button to unlock.")
    }

    // ------------------------------------------------------------------ dialogs

    private fun speedDialog() {
        val values = floatArrayOf(0.5f, 0.75f, 1f, 1.25f, 1.5f, 2f)
        val labels = values.map { "${it}x" }.toTypedArray()
        AlertDialog.Builder(this, R.style.HbDialog)
            .setTitle("Playback speed")
            .setItems(labels) { _, which ->
                controller?.setPlaybackSpeed(values[which])
                Prefs.setPlayerSpeed(this, values[which])
                showControls()
            }
            .show()
    }

    private fun aspectDialog() {
        val labels = arrayOf("Fit to screen", "Zoom to fill", "Stretch", "Original width")
        AlertDialog.Builder(this, R.style.HbDialog)
            .setTitle("Aspect ratio")
            .setItems(labels) { _, which ->
                playerView.resizeMode = RESIZE_MODES[which]
                Prefs.setPlayerAspect(this, which)
                showControls()
            }
            .show()
    }

    private fun subtitleDialog() {
        val c = controller ?: return
        val groups = c.currentTracks.groups.filter { it.type == C.TRACK_TYPE_TEXT && it.isSupported }
        if (groups.isEmpty()) {
            Hb.alert(this, "Subtitles", "This file has no embedded subtitle tracks. Subtitles are shown automatically when a video contains them.")
            return
        }
        data class Option(val group: androidx.media3.common.Tracks.Group, val track: Int, val label: String)
        val options = ArrayList<Option>()
        groups.forEach { group ->
            for (i in 0 until group.length) {
                val format = group.getTrackFormat(i)
                val label = format.label ?: format.language ?: "Track ${options.size + 1}"
                options.add(Option(group, i, label))
            }
        }
        val labels = arrayListOf<String>()
        labels.add("Off")
        labels.addAll(options.map { it.label })
        AlertDialog.Builder(this, R.style.HbDialog)
            .setTitle("Subtitles")
            .setItems(labels.toTypedArray()) { _, which ->
                val params = c.trackSelectionParameters.buildUpon()
                    .setTrackTypeDisabled(C.TRACK_TYPE_TEXT, which == 0)
                    .clearOverridesOfType(C.TRACK_TYPE_TEXT)
                if (which > 0) {
                    val option = options[which - 1]
                    params.setOverrideForType(TrackSelectionOverride(option.group.mediaTrackGroup, option.track))
                }
                c.trackSelectionParameters = params.build()
                showControls()
            }
            .show()
    }

    private fun queueDialog() {
        val c = controller ?: return
        val count = c.mediaItemCount
        if (count == 0) {
            Hb.toast(this, "The queue is empty")
            return
        }
        val labels = (0 until count).map { i ->
            val title = c.getMediaItemAt(i).mediaMetadata.title ?: "Item ${i + 1}"
            if (i == c.currentMediaItemIndex) "▶ $title" else title
        }.toTypedArray()
        AlertDialog.Builder(this, R.style.HbDialog)
            .setTitle("Play queue ($count)")
            .setItems(labels) { _, which ->
                c.seekTo(which, 0)
                c.play()
                showControls()
            }
            .show()
    }

    private fun addFiles() {
        addFilesPicker.launch(arrayOf("video/*", "audio/*"))
    }

    private fun showMenu() {
        val items = listOf(
            "Queue" to { queueDialog() },
            "Add files" to { addFiles() },
            "Subtitles" to { subtitleDialog() },
            "Playback speed" to { speedDialog() },
            "Aspect ratio" to { aspectDialog() },
            "Picture in picture" to { enterPip() },
            "Lock screen" to { lockScreen() },
            "Stop playback" to {
                controller?.stop()
                controls.isVisible = true
                updatePlayIcon()
            }
        )
        AlertDialog.Builder(this, R.style.HbDialog)
            .setTitle("Player")
            .setItems(items.map { it.first }.toTypedArray()) { _, which -> items[which].second() }
            .show()
    }

    // ------------------------------------------------------------------ start panel

    private fun showStartPanel() {
        libraryJob?.cancel()
        startCol.removeAllViews()
        startPanel.isVisible = true
        controls.isVisible = false
        val p = Hb.palette(this)
        startCol.addView(Hb.text(this, "Media Player", 26f, p.text, bold = true))
        startCol.addView(Hb.text(this, "Videos, music and your private queue — all offline.", 11.5f, p.muted).apply {
            setPadding(0, Hb.dp(this@PlayerActivity, 4), 0, Hb.dp(this@PlayerActivity, 14))
        })
        startCol.addView(Hb.button(this, "Choose files", primary = true, iconRes = R.drawable.ic_folder, heightDp = 48) {
            addFiles()
        })
        startCol.addView(Hb.spacer(this, 12))

        val recent = RecentStore.all(this)
        if (recent.isNotEmpty()) {
            startCol.addView(Hb.section(this, "Recently played", "Clear") {
                Hb.confirm(this, "Clear recently played?", "Playback positions will be forgotten.", "Clear", destructive = true) {
                    RecentStore.clear(this)
                    showStartPanel()
                }
            })
            val card = Hb.card(this, 6)
            recent.take(12).forEachIndexed { index, item ->
                val uri = Uri.parse(item.uri)
                card.addView(Hb.row(this, if (item.mime.startsWith("audio/")) R.drawable.ic_music else R.drawable.ic_play,
                    item.name, resumeLabel(item)) {
                    playNow(recent.map { LocalItem(Uri.parse(it.uri), it.name, it.mime) }, index)
                })
                if (index != recent.take(12).lastIndex) card.addView(Hb.divider(this, 46))
            }
            startCol.addView(card)
        }

        startCol.addView(Hb.section(this, "Library"))
        val loading = Hb.text(this, "Loading your media…", 12f, p.muted)
        startCol.addView(loading)

        libraryJob = lifecycleScope.launch {
            val videos = withContext(Dispatchers.IO) { MediaIndex.videos(this@PlayerActivity, 80) }
            val audio = withContext(Dispatchers.IO) { MediaIndex.audio(this@PlayerActivity, 80) }
            if (isFinishing || isDestroyed) return@launch
            startCol.removeView(loading)
            fun addSection(title: String, files: List<com.example.videodownloader.util.MediaFile>) {
                if (files.isEmpty()) return
                startCol.addView(Hb.section(this@PlayerActivity, title, "${files.size}"))
                val card = Hb.card(this@PlayerActivity, 6)
                files.take(30).forEachIndexed { index, file ->
                    card.addView(Hb.row(this@PlayerActivity,
                        if (file.mime.startsWith("audio/")) R.drawable.ic_music else R.drawable.ic_play,
                        file.name, "${Fmt.bytes(file.size)} • ${Fmt.ago(file.dateMs)}") {
                        playNow(files.map { LocalItem(it.uri, it.name, it.mime) }, index)
                    })
                    if (index != files.take(30).lastIndex) card.addView(Hb.divider(this@PlayerActivity, 46))
                }
                startCol.addView(card)
            }
            addSection("Videos", videos)
            addSection("Music", audio)
            if (videos.isEmpty() && audio.isEmpty() && recent.isEmpty()) {
                startCol.addView(Hb.empty(this@PlayerActivity, R.drawable.ic_play, "No media found",
                    "Use the file picker, or download a video to see it here."))
            }
        }
    }

    private fun resumeLabel(item: RecentMedia): String {
        if (item.positionMs > 0 && item.durationMs > 0) {
            return "Resume at ${Fmt.duration(item.positionMs)} • ${Fmt.ago(item.at)}"
        }
        return if (item.durationMs > 0) "${Fmt.duration(item.durationMs)} • ${Fmt.ago(item.at)}" else Fmt.ago(item.at)
    }

    // ------------------------------------------------------------------ lifecycle and helpers

    override fun onStart() {
        super.onStart()
        tickerOn = true
        handler.post(ticker)
    }

    override fun onStop() {
        super.onStop()
        tickerOn = false
        handler.removeCallbacks(ticker)
        saveProgress()
        // Keep playing in the background unless the user turned that off. PiP is still "watching".
        if (!Prefs.playerBackground(this) && !isInPictureInPictureMode) controller?.pause()
    }

    override fun onPause() {
        super.onPause()
        saveProgress()
    }

    override fun onDestroy() {
        saveProgress()
        handler.removeCallbacksAndMessages(null)
        controller?.removeListener(playerListener)
        playerView.player = null
        controller = null
        releaseController?.invoke()
        releaseController = null
        super.onDestroy()
    }

    override fun onPictureInPictureModeChanged(isInPictureInPictureMode: Boolean, newConfig: Configuration) {
        super.onPictureInPictureModeChanged(isInPictureInPictureMode, newConfig)
        if (isInPictureInPictureMode) {
            controls.isVisible = false
            startPanel.isVisible = false
            unlockButton.isVisible = false
            buffer.isVisible = false
            gestureHint.isVisible = false
        } else {
            controls.isVisible = true
            scheduleControls()
        }
    }

    private fun saveProgress() {
        val c = controller ?: return
        val item = c.currentMediaItem ?: return
        val uri = item.localConfiguration?.uri?.toString() ?: item.mediaId
        if (uri.isBlank()) return
        val pos = c.currentPosition
        val duration = c.duration.coerceAtLeast(0)
        RecentStore.setPosition(this, uri, pos)
        addRecent(item, pos)
        if (duration > 0) {
            // keep duration fresh for the resume label
            val existing = RecentStore.all(this).firstOrNull { it.uri == uri }
            if (existing != null) RecentStore.add(this, existing.copy(durationMs = duration, positionMs = pos))
        }
    }

    private fun addRecent(item: MediaItem, position: Long) {
        val uri = item.localConfiguration?.uri?.toString() ?: item.mediaId
        if (uri.isBlank()) return
        val mime = item.localConfiguration?.mimeType ?: mimeOf(Uri.parse(uri))
        val duration = controller?.duration?.coerceAtLeast(0) ?: 0
        RecentStore.add(this, RecentMedia(
            uri = uri,
            name = item.mediaMetadata.title?.toString() ?: Fmt.titleFromUrl(uri),
            mime = mime,
            at = System.currentTimeMillis(),
            durationMs = duration,
            positionMs = position
        ))
    }

    private fun mimeOf(uri: Uri): String {
        if (uri.scheme == "content") {
            try {
                contentResolver.getType(uri)?.let { return it }
            } catch (_: Exception) {
            }
        }
        val ext = uri.lastPathSegment?.substringAfterLast('.', "")?.lowercase() ?: ""
        return when (ext) {
            "mp4", "mkv", "webm", "mov", "avi", "3gp", "ts", "m4v" -> "video/$ext"
            "mp3", "m4a", "aac", "ogg", "opus", "wav", "flac" -> "audio/$ext"
            else -> "video/*"
        }
    }

    private fun adjustVolume(deltaFraction: Float) {
        try {
            val am = getSystemService(AUDIO_SERVICE) as AudioManager
            val max = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
            val current = am.getStreamVolume(AudioManager.STREAM_MUSIC)
            val next = (current + (deltaFraction * max * 1.6f)).toInt().coerceIn(0, max)
            am.setStreamVolume(AudioManager.STREAM_MUSIC, next, 0)
            gestureHint.text = "Volume ${(next * 100) / max}%"
            gestureHint.isVisible = true
            handler.postDelayed({ gestureHint.isVisible = false }, 700)
        } catch (_: Exception) {
        }
    }

    private fun adjustBrightness(deltaFraction: Float) {
        try {
            val attrs = window.attributes
            val current = if (attrs.screenBrightness < 0f) 0.5f else attrs.screenBrightness
            val next = (current + deltaFraction).coerceIn(0.08f, 1f)
            attrs.screenBrightness = next
            window.attributes = attrs
            gestureHint.text = "Brightness ${(next * 100).toInt()}%"
            gestureHint.isVisible = true
            handler.postDelayed({ gestureHint.isVisible = false }, 700)
        } catch (_: Exception) {
        }
    }

    private fun ensureNotifications() {
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            try {
                notificationPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
            } catch (_: Exception) {
            }
        }
    }

    private fun updatePipParams() {
        if (Build.VERSION.SDK_INT < 26) return
        try {
            val size = controller?.videoSize
            val ratio = if (size != null && size.width > 0 && size.height > 0) {
                Rational(size.width, size.height)
            } else {
                Rational(16, 9)
            }
            setPictureInPictureParams(android.app.PictureInPictureParams.Builder().setAspectRatio(ratio).build())
        } catch (_: Exception) {
        }
    }

    private fun enterPip() {
        if (Build.VERSION.SDK_INT < 26) {
            Hb.toast(this, "Picture in picture is not supported on this Android version")
            return
        }
        val mime = controller?.currentMediaItem?.localConfiguration?.mimeType
        if (mime != null && mime.startsWith("audio/")) {
            Hb.toast(this, "Picture in picture needs a video. Audio keeps playing in the background.")
            return
        }
        try {
            updatePipParams()
            if (Build.VERSION.SDK_INT >= 31) {
                setPictureInPictureParams(
                    android.app.PictureInPictureParams.Builder()
                        .setAspectRatio(
                            controller?.videoSize?.let { if (it.width > 0 && it.height > 0) Rational(it.width, it.height) else Rational(16, 9) }
                                ?: Rational(16, 9)
                        )
                        .setAutoEnterEnabled(false)
                        .build()
                )
            }
            enterPictureInPictureMode()
        } catch (_: Exception) {
            Hb.toast(this, "This device did not allow picture in picture")
        }
    }

    companion object {
        const val EXTRA_TITLE = "title"
        const val EXTRA_URIS = "uris"
        const val EXTRA_NAMES = "names"
        const val EXTRA_MIMES = "mimes"
        const val EXTRA_INDEX = "index"

        private val RESIZE_MODES = intArrayOf(
            AspectRatioFrameLayout.RESIZE_MODE_FIT,
            AspectRatioFrameLayout.RESIZE_MODE_ZOOM,
            AspectRatioFrameLayout.RESIZE_MODE_FILL,
            AspectRatioFrameLayout.RESIZE_MODE_FIXED_WIDTH
        )
    }
}
