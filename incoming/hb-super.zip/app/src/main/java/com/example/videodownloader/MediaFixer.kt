package com.example.videodownloader

import android.content.ContentUris
import android.content.ContentValues
import android.content.Context
import android.provider.MediaStore

/**
 * Old downloads have no "date taken", so galleries sort them to the year 1970 (bottom, never seen).
 * This sets their date to the download date. It only touches files this app created.
 */
object MediaFixer {
    fun fix(c: Context) {
        val cols = arrayOf(
            MediaStore.MediaColumns._ID,
            MediaStore.MediaColumns.DATE_ADDED,
            MediaStore.MediaColumns.DATE_TAKEN
        )
        val rp = MediaStore.MediaColumns.RELATIVE_PATH
        val where = "$rp LIKE ? OR $rp LIKE ? OR $rp LIKE ?"
        val args = arrayOf("Movies/MyDownloader%", "Pictures/MyDownloader%", "DCIM/HB AIO%")
        listOf(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, MediaStore.Images.Media.EXTERNAL_CONTENT_URI)
            .forEach { base ->
                try {
                    c.contentResolver.query(base, cols, where, args, null)?.use { cur ->
                        while (cur.moveToNext()) {
                            val id = cur.getLong(0)
                            val added = cur.getLong(1) * 1000
                            val taken = if (cur.isNull(2)) 0L else cur.getLong(2)
                            if (added > 0 && taken < added - 86_400_000L) {
                                val v = ContentValues().apply { put(MediaStore.MediaColumns.DATE_TAKEN, added) }
                                c.contentResolver.update(ContentUris.withAppendedId(base, id), v, null, null)
                            }
                        }
                    }
                } catch (_: Exception) {
                }
            }
    }
}
