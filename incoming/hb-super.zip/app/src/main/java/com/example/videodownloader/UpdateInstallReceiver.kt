package com.example.videodownloader

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.PackageInstaller
import android.os.Build
import android.widget.Toast

/** Receives the result of the app update install from Android's PackageInstaller. */
class UpdateInstallReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        when (intent.getIntExtra(PackageInstaller.EXTRA_STATUS, PackageInstaller.STATUS_FAILURE)) {
            PackageInstaller.STATUS_PENDING_USER_ACTION -> {
                // Android needs one tap from the user: open its "Update" screen. The notification stays
                // behind too, because some phones drop a screen opened while the app is in the background.
                @Suppress("DEPRECATION")
                val confirm: Intent? =
                    if (Build.VERSION.SDK_INT >= 33) intent.getParcelableExtra(Intent.EXTRA_INTENT, Intent::class.java)
                    else intent.getParcelableExtra(Intent.EXTRA_INTENT)
                UpdateService.showTapToInstall(context)
                confirm?.let {
                    try {
                        context.startActivity(it.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                    } catch (_: Exception) {
                    }
                }
            }
            PackageInstaller.STATUS_SUCCESS -> {
                /* the app restarts by itself with the new version */
                UpdateStore.clear(context) // installed: the downloaded APK is not needed any more
                UpdateService.hideNotification(context)
                Updater.onInstallResult(true)
            }
            else -> {
                val why = intent.getStringExtra(PackageInstaller.EXTRA_STATUS_MESSAGE).orEmpty()
                // The APK is still on the phone, so the next try is Install alone - no second download.
                if (UpdateStore.status(context) == UpdateStore.INSTALLING) {
                    UpdateStore.setStatus(context, UpdateStore.READY)
                }
                Toast.makeText(context, "Update failed. $why", Toast.LENGTH_LONG).show()
                UpdateService.showTapToInstall(context)
                Updater.onInstallResult(false) // stop the progress box and ask for the update again
            }
        }
    }
}
