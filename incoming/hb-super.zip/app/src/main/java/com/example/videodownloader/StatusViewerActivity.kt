package com.example.videodownloader

import android.annotation.SuppressLint
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.view.GestureDetector
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import android.widget.VideoView
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlin.math.abs

/**
 * Plays a status inside the app (no other app needed). Swipe left/right for the next / previous one,
 * tap to hide or show the buttons. Videos play in a loop.
 */
class StatusViewerActivity : AppCompatActivity() {

    companion object {
        const val EXTRA_URIS = "uris"
        const val EXTRA_MIMES = "mimes"
        const val EXTRA_NAMES = "names"
        const val EXTRA_INDEX = "index"
        const val EXTRA_SAVED = "from_saved"
    }

    private val items = mutableListOf<StatusItem>()
    private var index = 0
    private var fromSaved = false
    private var barsVisible = true

    private lateinit var image: ImageView
    private lateinit var video: VideoView
    private lateinit var counter: TextView
    private lateinit var action: Button
    private lateinit var topBar: View
    private lateinit var bottomBar: View

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    @SuppressLint("ClickableViewAccessibility")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val uris = intent.getStringArrayListExtra(EXTRA_URIS).orEmpty()
        val mimes = intent.getStringArrayListExtra(EXTRA_MIMES).orEmpty()
        val names = intent.getStringArrayListExtra(EXTRA_NAMES).orEmpty()
        uris.forEachIndexed { i, u ->
            items += StatusItem(Uri.parse(u), names.getOrElse(i) { "status" }, mimes.getOrElse(i) { "image/jpeg" }, 0L)
        }
        if (items.isEmpty()) {
            finish()
            return
        }
        fromSaved = intent.getBooleanExtra(EXTRA_SAVED, false)
        index = intent.getIntExtra(EXTRA_INDEX, 0).coerceIn(0, items.size - 1)

        window.statusBarColor = Color.BLACK
        window.navigationBarColor = Color.BLACK

        val root = FrameLayout(this).apply { setBackgroundColor(Color.BLACK) }
        image = ImageView(this).apply { scaleType = ImageView.ScaleType.FIT_CENTER }
        video = VideoView(this)
        root.addView(image, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        root.addView(
            video,
            FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT, Gravity.CENTER)
        )

        // Catches swipes and taps above the picture / video
        val touch = View(this)
        root.addView(touch, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        val detector = GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onDown(e: MotionEvent) = true
            override fun onSingleTapConfirmed(e: MotionEvent): Boolean {
                setBars(!barsVisible)
                return true
            }

            override fun onFling(e1: MotionEvent?, e2: MotionEvent, vx: Float, vy: Float): Boolean {
                val dx = e2.x - (e1?.x ?: e2.x)
                val dy = e2.y - (e1?.y ?: e2.y)
                if (abs(dx) > abs(dy) && abs(dx) > dp(80) && abs(vx) > 500) {
                    if (dx < 0) go(index + 1) else go(index - 1)
                    return true
                }
                return false
            }
        })
        touch.setOnTouchListener { _, e -> detector.onTouchEvent(e) }

        // Top bar: close + counter
        val top = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(8), dp(28), dp(16), dp(8))
            setBackgroundColor(0x66000000)
        }
        top.addView(ImageView(this).apply {
            setImageResource(R.drawable.ic_close)
            setPadding(dp(10), dp(10), dp(10), dp(10))
            setOnClickListener { finish() }
        }, LinearLayout.LayoutParams(dp(48), dp(48)))
        counter = TextView(this).apply {
            setTextColor(Color.WHITE)
            textSize = 14f
            gravity = Gravity.END
        }
        top.addView(counter, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        topBar = top
        root.addView(top, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.TOP))

        // Bottom bar: Save (or Delete for saved ones)
        val bottom = LinearLayout(this).apply {
            gravity = Gravity.CENTER
            setPadding(dp(16), dp(10), dp(16), dp(28))
            setBackgroundColor(0x66000000)
        }
        action = Button(this).apply {
            isAllCaps = false
            textSize = 14f
            setTextColor(Color.WHITE)
            background = androidx.core.content.ContextCompat.getDrawable(this@StatusViewerActivity, R.drawable.bg_btn_primary)
            compoundDrawablePadding = dp(8)
            setPadding(dp(22), 0, dp(22), 0)
            setOnClickListener { onAction() }
        }
        bottom.addView(action, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(46)))
        bottomBar = bottom
        root.addView(bottom, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM))

        setContentView(root)
        show()
    }

    private fun setBars(visible: Boolean) {
        barsVisible = visible
        listOf(topBar, bottomBar).forEach { bar ->
            if (visible) {
                bar.visibility = View.VISIBLE
                bar.animate().alpha(1f).setDuration(180).start()
            } else {
                bar.animate().alpha(0f).setDuration(180).withEndAction { bar.visibility = View.INVISIBLE }.start()
            }
        }
    }

    private fun go(to: Int) {
        if (to < 0 || to >= items.size) return
        index = to
        show()
    }

    private fun show() {
        val item = items[index]
        counter.text = "${index + 1} / ${items.size}"
        updateAction()
        if (item.isVideo) {
            image.visibility = View.GONE
            video.visibility = View.VISIBLE
            video.setOnPreparedListener { mp ->
                mp.isLooping = true
                video.start()
            }
            video.setOnErrorListener { _, _, _ ->
                Toast.makeText(this, "This video cannot be played", Toast.LENGTH_SHORT).show()
                true
            }
            video.setVideoURI(item.uri)
        } else {
            video.stopPlayback()
            video.visibility = View.GONE
            image.visibility = View.VISIBLE
            image.setImageDrawable(null)
            lifecycleScope.launch {
                val bmp = withContext(Dispatchers.IO) { Thumbs.get(this@StatusViewerActivity, item, resources.displayMetrics.widthPixels) }
                if (items.getOrNull(index) === item && bmp != null) image.setImageBitmap(bmp)
            }
        }
    }

    private fun updateAction() {
        val item = items[index]
        when {
            fromSaved -> {
                action.text = "Delete"
                action.isEnabled = true
                action.setCompoundDrawablesWithIntrinsicBounds(R.drawable.ic_delete, 0, 0, 0)
            }
            Prefs.isStatusSaved(this, item.name) -> {
                action.text = "Saved"
                action.isEnabled = false
                action.setCompoundDrawablesWithIntrinsicBounds(R.drawable.ic_check, 0, 0, 0)
            }
            else -> {
                action.text = "Save"
                action.isEnabled = true
                action.setCompoundDrawablesWithIntrinsicBounds(R.drawable.ic_download, 0, 0, 0)
            }
        }
    }

    private fun onAction() {
        val item = items[index]
        action.isEnabled = false
        lifecycleScope.launch {
            if (fromSaved) {
                val ok = withContext(Dispatchers.IO) { StatusRepo.deleteSaved(this@StatusViewerActivity, item) }
                Toast.makeText(this@StatusViewerActivity, if (ok) "Deleted" else "Could not delete", Toast.LENGTH_SHORT).show()
                if (ok) {
                    items.remove(item)
                    if (items.isEmpty()) {
                        finish()
                        return@launch
                    }
                    index = index.coerceAtMost(items.size - 1)
                    show()
                } else {
                    updateAction()
                }
            } else {
                val ok = withContext(Dispatchers.IO) { StatusRepo.save(this@StatusViewerActivity, item) }
                Toast.makeText(this@StatusViewerActivity, if (ok) "Saved on your phone" else "Could not save", Toast.LENGTH_SHORT).show()
                updateAction()
            }
        }
    }

    override fun onPause() {
        super.onPause()
        if (::video.isInitialized) video.pause()
    }

    override fun onResume() {
        super.onResume()
        if (::video.isInitialized && video.visibility == View.VISIBLE) video.start()
    }

    override fun onDestroy() {
        if (::video.isInitialized) video.stopPlayback()
        super.onDestroy()
    }
}
