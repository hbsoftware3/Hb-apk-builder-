package com.example.videodownloader

import com.yausername.youtubedl_android.YoutubeDL
import java.util.concurrent.ConcurrentHashMap

/** Thrown inside a download when the user pressed Cancel. */
class UserCancelled : Exception("Cancelled")

/** Pause / cancel state of one download. */
class DlControl(val id: Int) {
    @Volatile var paused = false
    @Volatile var cancelled = false
    @Volatile var pct = 0
    val processId: String get() = "hb_dl_$id"

    fun throwIfCancelled() {
        if (cancelled) throw UserCancelled()
    }
}

/**
 * Pause / resume / cancel for running downloads. Used by the buttons on the main screen
 * and by the notification buttons.
 *
 * Pause = stop the yt-dlp process but KEEP the half-downloaded file. Resume starts yt-dlp again
 * and it continues from where it stopped (it does not start from zero).
 */
object DownloadControl {
    private val map = ConcurrentHashMap<Int, DlControl>()

    fun register(id: Int): DlControl = DlControl(id).also { map[id] = it }
    fun get(id: Int): DlControl? = map[id]
    fun remove(id: Int) {
        map.remove(id)
    }

    private fun killProcess(c: DlControl) {
        try {
            YoutubeDL.getInstance().destroyProcessById(c.processId)
        } catch (_: Throwable) {
        }
    }

    fun pause(id: Int) {
        val c = map[id] ?: return
        if (c.cancelled) return
        c.paused = true
        DownloadTracker.setPaused(id, true)
        killProcess(c)
    }

    fun resume(id: Int) {
        val c = map[id] ?: return
        c.paused = false
        DownloadTracker.setPaused(id, false)
    }

    fun cancel(id: Int) {
        val c = map[id] ?: return
        c.cancelled = true
        c.paused = false
        DownloadTracker.setPaused(id, false)
        DownloadTracker.progress(id, "Cancelling...", c.pct, true)
        killProcess(c)
    }
}
