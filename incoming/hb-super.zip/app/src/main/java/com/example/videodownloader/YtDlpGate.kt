package com.example.videodownloader

import java.util.concurrent.locks.ReentrantReadWriteLock

/**
 * Keeps a yt-dlp UPDATE away from running yt-dlp commands.
 *
 * An update deletes the whole yt-dlp folder and copies the new file in. A download that is running
 * (or starting) at that moment can fail with strange errors. Many downloads may run together, but an
 * update only runs when none of them is running, and a download that wants to start waits until a
 * running update is finished.
 */
object YtDlpGate {
    private val lock = ReentrantReadWriteLock()

    /** Wrap every yt-dlp command in this. Several can run at the same time. */
    fun <T> withYtDlp(block: () -> T): T {
        val r = lock.readLock()
        r.lock()
        try {
            return block()
        } finally {
            r.unlock()
        }
    }

    /** Runs [block] only if no yt-dlp command is running right now. Returns false if it was skipped. */
    fun updateWhenIdle(block: () -> Unit): Boolean {
        val w = lock.writeLock()
        if (!w.tryLock()) return false
        try {
            block()
        } finally {
            w.unlock()
        }
        return true
    }
}
