package com.example.videodownloader

import android.app.AlertDialog
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageInstaller
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.DefaultLifecycleObserver
import androidx.lifecycle.LifecycleOwner
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.File
import java.lang.ref.WeakReference
import java.net.HttpURLConnection
import java.net.URL

/**
 * In-app update.
 *
 * The app reads UPDATE_JSON_URL, compares versionCode, and hands the APK to [UpdateService], which
 * downloads it outside of every screen: closing the app does not stop it, and a half file is continued
 * where it stopped. The finished file stays on the phone, so opening the app again brings up Install
 * instead of asking or downloading a second time - and that works even with no internet.
 *
 * Android's own installer is opened straight away (with no dialog of the app in the way). A normal app
 * can never install without Android showing one confirm screen; on Android 12+ later updates can even
 * skip that screen when this app installed the previous version itself.
 *
 * update-v1.json:
 * { "versionCode": 20, "versionName": "6.0", "apkUrl": "https://.../app-release.apk",
 *   "minVersionCode": 19, "notes": "What is new", "sha256": "checksum of the APK" }
 *
 * EVERY update is compulsory: as soon as update-v1.json shows a newer versionCode than the installed app,
 * the app cannot be used (not even the share-to-download or status saver) until the update is installed.
 * minVersionCode is still read (older app versions that do not have this rule use it), but this version
 * treats versionCode itself as the minimum.
 */
object Updater {

    // >>> Link of your update-v1.json (must be https and point straight to the file). <<<
    val UPDATE_JSON_URL: String = BuildConfig.UPDATE_JSON_URL

    const val ACTION_STATUS = "com.example.videodownloader.UPDATE_STATUS"

    data class Info(
        val code: Int, val name: String, val apkUrl: String, val notes: String, val minCode: Int,
        val sha256: String = ""
    )

    /** true while a dialog with the "Update required" / "Update downloaded" box is open. */
    @Volatile
    private var dialogShowing = false

    /** true while the update is downloading or waiting for Android's installer. */
    @Volatile
    private var updating = false

    /** Time the APK was handed to Android's installer (0 = not there yet). */
    @Volatile
    private var installHandedAt = 0L

    /** Version already pushed to the installer on its own, so a failed install cannot loop. */
    @Volatile
    private var autoInstallFor = 0

    /** true while the APK is being copied into the installer session (a few seconds for a big file). */
    @Volatile
    private var installing = false

    @Volatile
    private var watched = false

    private var appCtx: Context? = null
    private var progressText = ""
    private var progressDialog: AlertDialog? = null
    private var progressAct: AppCompatActivity? = null
    private var askDialog: AlertDialog? = null
    private var lastInfo: Info? = null
    private var lastMsg: ((String) -> Unit)? = null
    private var lastAct: WeakReference<AppCompatActivity>? = null

    private fun currentAct(): AppCompatActivity? =
        (progressAct ?: lastAct?.get())?.takeIf { !it.isFinishing && !it.isDestroyed }

    private fun say(text: String) {
        if (text.isNotBlank()) lastMsg?.invoke(text)
    }

    // ---------------------------------------------------------------- live state

    /** One collector for the whole process: it reacts to whatever the background service reports. */
    private fun watchNow(c: Context) {
        appCtx = c.applicationContext
        if (watched) return
        watched = true
        scope.launch {
            UpdateTracker.ui.collect { onTracker(it) }
        }
    }

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private val ioScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    private fun onTracker(ui: UpdateTracker.Ui) {
        val c = appCtx ?: return
        when (ui.status) {
            UpdateStore.DOWNLOADING -> {
                updating = true
                installHandedAt = 0L
                setProgress(ui.text)
                say(ui.text)
            }

            UpdateStore.READY -> {
                updating = false
                hideProgress()
                val a = currentAct()
                val i = UpdateStore.info(c)
                if (a != null && i != null && i.code > currentCode(a)) {
                    if (autoInstallFor != i.code) {
                        // the user sat and waited for this: go straight to Android's installer
                        autoInstallFor = i.code
                        installNow(a)
                    } else {
                        showDownloaded(a, i)
                    }
                }
            }

            UpdateStore.INSTALLING -> {
                updating = true
                if (installHandedAt == 0L) installHandedAt = System.currentTimeMillis()
                setProgress("Installing update...\nAndroid shows one confirm screen: tap Install.")
            }

            UpdateStore.FAILED -> {
                updating = false
                installHandedAt = 0L
                hideProgress()
                say(ui.text)
                askAgain()
            }

            else -> {
                // IDLE: only drop the box when the phone really has no job waiting
                val st = UpdateStore.status(c)
                if (st == UpdateStore.IDLE || st == UpdateStore.FAILED) {
                    updating = false
                    hideProgress()
                }
            }
        }
    }

    /** Percent of the download recorded last, for the button label and the progress box. */
    private fun pct(c: Context): Int = with(UpdateStore) {
        val t = total(c)
        if (t > 0) (done(c) * 100 / t).toInt().coerceIn(0, 100) else 0
    }

    /** Short text for the "Update HB Super App" button: what to tap next. */
    fun label(c: Context): String = when {
        UpdateStore.code(c) <= currentCode(c) -> "Update HB Super App"
        UpdateStore.readyApk(c) != null -> "Install update ${UpdateStore.name(c)}"
        UpdateStore.status(c) == UpdateStore.DOWNLOADING -> "Downloading update... ${pct(c)}%"
        else -> "Update HB Super App"
    }

    private fun downloadingText(c: Context): String {
        val live = UpdateTracker.ui.value.text
        if (live.isNotBlank() && UpdateTracker.ui.value.status == UpdateStore.DOWNLOADING) return live
        val p = pct(c)
        val d = UpdateStore.done(c)
        val t = UpdateStore.total(c)
        return if (t > 0)
            "Downloading update... $p%  |  ${HistoryStore.fmtSize(d)} / ${HistoryStore.fmtSize(t)}"
        else "Downloading update... ${HistoryStore.fmtSize(d)}"
    }

    // ---------------------------------------------------------------- dialogs

    /** Shows (or re-shows on a new screen) the box with the update progress. Cannot be closed by tapping outside. */
    private fun showProgress(act: AppCompatActivity) {
        if (act.isFinishing || act.isDestroyed) return
        val old = progressDialog
        if (old != null && old.isShowing && progressAct === act) return
        try { old?.dismiss() } catch (_: Exception) { }
        val d = AlertDialog.Builder(act)
            .setTitle("Updating")
            .setMessage(progressText)
            .setCancelable(false)
            .setNeutralButton("Hide") { _, _ -> hideProgress() }
            .setNegativeButton("Cancel") { _, _ -> cancelUpdate() }
            .create()
        d.show()
        progressDialog = d
        progressAct = act
        lastAct = WeakReference(act)
        act.lifecycle.addObserver(object : DefaultLifecycleObserver {
            override fun onDestroy(owner: LifecycleOwner) {
                if (progressAct === act) {
                    try { d.dismiss() } catch (_: Exception) { }
                    progressDialog = null
                    progressAct = null
                }
            }
        })
    }

    private fun setProgress(text: String) {
        if (text.isNotBlank()) progressText = text
        progressDialog?.setMessage(progressText)
    }

    private fun hideProgress() {
        try { progressDialog?.dismiss() } catch (_: Exception) { }
        progressDialog = null
        progressAct = null
    }

    /** The one question box of the app: Update (or Install) and Exit, and it comes back until done. */
    private fun openAsk(
        act: AppCompatActivity,
        title: String,
        text: String,
        positive: String,
        onPositive: () -> Unit,
        onGone: () -> Unit
    ) {
        if (act.isFinishing || act.isDestroyed || dialogShowing || updating) return
        dialogShowing = true
        try { askDialog?.dismiss() } catch (_: Exception) { }
        val d = AlertDialog.Builder(act)
            .setTitle(title)
            .setMessage(text)
            .setCancelable(false)
            .setPositiveButton(positive) { _, _ -> onPositive() }
            .setNegativeButton("Exit") { _, _ -> act.finishAffinity() }
            .create()
        d.setOnDismissListener {
            dialogShowing = false
            act.window.decorView.postDelayed({ if (!act.isFinishing && !act.isDestroyed) onGone() }, 700)
        }
        d.show()
        askDialog = d
        act.lifecycle.addObserver(object : DefaultLifecycleObserver {
            override fun onDestroy(owner: LifecycleOwner) {
                if (askDialog === d) {
                    try { d.dismiss() } catch (_: Exception) { }
                    askDialog = null
                    dialogShowing = false
                }
            }
        })
    }

    /** Forced update before the download: cannot be closed for good, the app is unusable until installed. */
    private fun showRequired(act: AppCompatActivity, i: Info?, onMessage: (String) -> Unit) {
        lastInfo = i ?: lastInfo
        val text = if (i != null)
            "You must install version ${i.name} to keep using HB Super App.\n\n${i.notes}\n\n" +
                "The download carries on after you close the app, and the next time you open it Install is ready."
        else
            "A required update is waiting. Connect to the internet and tap Update."
        openAsk(act, "Update required", text, "Update", {
            val info = i ?: UpdateStore.info(act)
            if (info != null && info.code > currentCode(act)) startDownload(act, info)
            else check(act, true, onMessage)
        }, {
            if (mustUpdate(act) && !updating) showRequired(act, lastInfo, onMessage)
        })
    }

    /** The APK is already on the phone: one tap and Android's installer opens, no download, no internet. */
    private fun showDownloaded(act: AppCompatActivity, i: Info) {
        openAsk(
            act,
            "Update downloaded",
            "Version ${i.name} is already on this phone, so nothing has to be downloaded again.\n\n" +
                "Tap Install and confirm on the screen Android shows.",
            "Install",
            { if (!installNow(act)) startDownload(act, i) },
            { if (mustUpdate(act) && !updating) showDownloaded(act, i) }
        )
    }

    /** Shows the question box again (after a failure or a cancel), as long as the update is still needed. */
    private fun askAgain() {
        val a = currentAct() ?: return
        if (UpdateStore.readyApk(a) != null) {
            UpdateStore.info(a)?.let { showDownloaded(a, it) }
            return
        }
        val i = lastInfo ?: return
        if (mustUpdate(a)) showRequired(a, i, lastMsg ?: { _ -> })
    }

    /** The user pressed Cancel in the progress box. */
    private fun cancelUpdate() {
        val c = appCtx ?: return
        if (UpdateStore.status(c) == UpdateStore.DOWNLOADING) {
            UpdateService.cancel(c)
            UpdateStore.setStatus(c, UpdateStore.IDLE)
            UpdateTracker.set(UpdateStore.IDLE, "", 0)
        }
        updating = false
        installHandedAt = 0L
        hideProgress()
        askAgain()
    }

    /** Safety: if Android never told us how the install ended, stop waiting after 2 minutes. */
    private fun resetIfStuck() {
        val c = appCtx ?: return
        if (updating && installHandedAt > 0 && System.currentTimeMillis() - installHandedAt > 120_000) {
            updating = false
            installHandedAt = 0L
            if (UpdateStore.status(c) == UpdateStore.INSTALLING) UpdateStore.setStatus(c, UpdateStore.READY)
            hideProgress()
        }
    }

    // ---------------------------------------------------------------- public entry points

    /** Called by InstallUpdateActivity when it hands the file over, so the app knows one is running. */
    fun markHandedOver() {
        updating = true
        installHandedAt = System.currentTimeMillis()
    }

    /** Called by UpdateInstallReceiver when Android says how the install ended. */
    fun onInstallResult(success: Boolean) {
        updating = false
        installHandedAt = 0L
        hideProgress()
        // The receiver already sorted the stored job out (kept for another Install, or dropped).
        val c = appCtx
        if (c != null && UpdateStore.readyApk(c) != null) {
            UpdateTracker.set(UpdateStore.READY, "Tap to install.", 100)
        } else {
            UpdateTracker.set(UpdateStore.IDLE, "", 0)
        }
        if (!success) askAgain()
    }

    fun currentCode(c: Context): Int = try {
        val p = c.packageManager.getPackageInfo(c.packageName, 0)
        if (Build.VERSION.SDK_INT >= 28) p.longVersionCode.toInt() else @Suppress("DEPRECATION") p.versionCode
    } catch (_: Exception) {
        0
    }

    /** true = the last known update-v1.json says this installed version is too old to be used. */
    fun mustUpdate(c: Context): Boolean = Prefs.minVersion(c) > currentCode(c)

    /** Used by screens that must not open while a forced update is pending. */
    fun blockIfForced(act: android.app.Activity): Boolean {
        if (!mustUpdate(act)) return false
        act.startActivity(Intent(act, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        act.finish()
        return true
    }

    /** manual = the user tapped the button (also tells "up to date" / errors). false = quiet check. */
    fun check(act: AppCompatActivity, manual: Boolean, onMessage: (String) -> Unit) {
        lastAct = WeakReference(act)
        lastMsg = onMessage
        appCtx = act.applicationContext
        watchNow(act)
        if (updating) resetIfStuck()
        UpdateStore.prune(act)
        // An installer hand-over from before this process started is over (installed, or Android never
        // answered). The file is still there, so go back to the one-tap Install instead of hanging.
        if (UpdateStore.status(act) == UpdateStore.INSTALLING && installHandedAt == 0L) {
            UpdateStore.setStatus(act, UpdateStore.READY)
        }

        // 1) the update is already sitting on the phone: install it straight away. No download, no internet
        //    and no box of the app asking first - only Android's own confirm screen, which cannot be skipped.
        if (UpdateStore.status(act) == UpdateStore.READY &&
            UpdateStore.code(act) > currentCode(act) && UpdateStore.readyApk(act) != null
        ) {
            val i = UpdateStore.info(act) ?: return
            if (autoInstallFor != i.code) {
                autoInstallFor = i.code
                if (installNow(act)) return
            }
            if (manual) onMessage("Version ${i.name} is downloaded. Tap Install.")
            showDownloaded(act, i)
            return
        }
        // 2) it is downloading (or was left half way): show the progress, and let the service carry on
        if (resumeOrShow(act)) {
            if (manual && UpdateStore.status(act) == UpdateStore.DOWNLOADING) {
                onMessage("Downloading in the background. You can close the app, it keeps going.")
            }
            return
        }
        if (dialogShowing || updating) {
            if (updating) showProgress(act)
            return
        }

        act.lifecycleScope.launch {
            if (manual) onMessage("Checking for app update...")
            val res = withContext(Dispatchers.IO) { runCatching { fetch() } }
            val i = res.getOrNull()
            if (i == null) {
                if (mustUpdate(act)) showRequired(act, UpdateStore.info(act), onMessage)
                else if (manual) onMessage("Could not check update: ${res.exceptionOrNull()?.message}")
                return@launch
            }
            // A newer version in update-v1.json is compulsory (the larger of the two numbers is the minimum)
            Prefs.setMinVersion(act, maxOf(i.minCode, i.code))
            val cur = currentCode(act)
            if (i.code <= cur) {
                UpdateStore.clear(act)
                if (manual) onMessage("You already have the newest version.")
                return@launch
            }
            lastInfo = i
            if (manual) onMessage("New version ${i.name} found.")
            if (act.isFinishing || act.isDestroyed) return@launch
            showRequired(act, i, onMessage)
        }
    }

    /** true when a job for this version already exists: its progress is shown and the service keeps it going. */
    private fun resumeOrShow(act: AppCompatActivity): Boolean {
        val st = UpdateStore.status(act)
        if (st == UpdateStore.IDLE || st == UpdateStore.FAILED || st == UpdateStore.READY) return false
        val i = UpdateStore.info(act) ?: return false
        if (i.code <= currentCode(act)) return false
        lastInfo = i
        if (st == UpdateStore.INSTALLING) {
            updating = true
            resetIfStuck()
            if (!updating) return false
            // Android's installer owns the screen now: the app adds no box of its own
            say("Installing update...")
            return true
        }
        updating = true
        installHandedAt = 0L
        progressText = downloadingText(act)
        showProgress(act)
        // after a reboot or a kill by the phone the service is gone but the half file is not: resume it
        if (!UpdateService.isRunning()) UpdateService.startDownload(act)
        return true
    }

    /** Hands the job to the background service. The download itself is not run in any screen. */
    private fun startDownload(act: AppCompatActivity, i: Info) {
        if (updating) {
            showProgress(act)
            return
        }
        // Android needs "Install unknown apps" allowed once for this app
        if (Build.VERSION.SDK_INT >= 26 && !act.packageManager.canRequestPackageInstalls()) {
            say("Allow \"Install unknown apps\" for HB Super App, then tap Update again.")
            try {
                act.startActivity(
                    Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:${act.packageName}"))
                )
            } catch (_: Exception) {
            }
            return
        }
        lastInfo = i
        Prefs.setMinVersion(act, maxOf(i.minCode, i.code))
        UpdateStore.begin(act, i)
        UpdateTracker.set(UpdateStore.DOWNLOADING, "Starting the download...", 0)
        updating = true
        installHandedAt = 0L
        autoInstallFor = 0
        progressText = "Downloading update... 0%"
        showProgress(act)
        UpdateService.startDownload(act)
    }

    /** The downloaded file is on the phone: opens Android's installer for it. Returns false if the file is gone. */
    private fun installNow(act: AppCompatActivity): Boolean {
        val apk = UpdateStore.readyApk(act) ?: return false
        if (Build.VERSION.SDK_INT >= 26 && !act.packageManager.canRequestPackageInstalls()) {
            say("Allow \"Install unknown apps\" for HB Super App, then tap Install again.")
            try {
                act.startActivity(
                    Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:${act.packageName}"))
                )
            } catch (_: Exception) {
            }
            return true
        }
        if (installing) return true
        installing = true
        updating = true
        installHandedAt = System.currentTimeMillis()
        // No box of the app here: Android's installer is the one screen the user has to touch.
        hideProgress()
        say("Installing update...")
        val c = act.applicationContext
        // the APK is copied into the installer session, which takes a few seconds for a big file
        ioScope.launch {
            val err = runCatching { installFrom(c, apk) }.exceptionOrNull()
            withContext(Dispatchers.Main) {
                installing = false
                if (err != null) {
                    updating = false
                    installHandedAt = 0L
                    UpdateStore.setStatus(c, UpdateStore.READY)
                    say("Could not open the installer: ${err.message}")
                    askAgain()
                } else {
                    UpdateStore.setStatus(c, UpdateStore.INSTALLING)
                    UpdateTracker.set(UpdateStore.INSTALLING, "Opening Android's installer...", 100)
                }
            }
        }
        return true
    }

    private fun fetch(): Info {
        val con = URL(UPDATE_JSON_URL).openConnection() as HttpURLConnection
        con.connectTimeout = 15000
        con.readTimeout = 15000
        con.useCaches = false
        try {
            if (con.responseCode != 200) error("Server answered ${con.responseCode}")
            val j = JSONObject(con.inputStream.bufferedReader().readText())
            return Info(
                j.getInt("versionCode"), j.optString("versionName"), j.getString("apkUrl"),
                j.optString("notes"), j.optInt("minVersionCode", 0), j.optString("sha256")
            )
        } finally {
            con.disconnect()
        }
    }

    /** Hands the APK to Android's PackageInstaller. The result arrives in UpdateInstallReceiver. */
    fun installFrom(c: Context, apk: File) {
        val installer = c.packageManager.packageInstaller
        val params = PackageInstaller.SessionParams(PackageInstaller.SessionParams.MODE_FULL_INSTALL)
        if (Build.VERSION.SDK_INT >= 31) {
            // lets Android install without a confirmation screen when it is allowed to (see class comment)
            params.setRequireUserAction(PackageInstaller.SessionParams.USER_ACTION_NOT_REQUIRED)
        }
        val id = installer.createSession(params)
        installer.openSession(id).use { session ->
            apk.inputStream().use { inp ->
                session.openWrite("update.apk", 0, apk.length()).use { o ->
                    inp.copyTo(o)
                    session.fsync(o)
                }
            }
            val intent = Intent(c, UpdateInstallReceiver::class.java).setAction(ACTION_STATUS)
            val flags = PendingIntent.FLAG_UPDATE_CURRENT or
                (if (Build.VERSION.SDK_INT >= 31) PendingIntent.FLAG_MUTABLE else 0)
            session.commit(PendingIntent.getBroadcast(c, id, intent, flags).intentSender)
        }
    }
}
