package com.example.videodownloader.util

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.TimeUnit

object Fmt {
    fun bytes(n: Long): String {
        if (n <= 0) return "0 B"
        val kb = 1024.0
        val mb = kb * 1024
        val gb = mb * 1024
        return when {
            n < kb -> "$n B"
            n < mb -> String.format(Locale.US, "%.0f KB", n / kb)
            n < gb -> String.format(Locale.US, "%.1f MB", n / mb)
            else -> String.format(Locale.US, "%.2f GB", n / gb)
        }
    }

    fun date(ms: Long): String =
        SimpleDateFormat("dd MMM yyyy, HH:mm", Locale.getDefault()).format(Date(ms))

    fun shortDate(ms: Long): String =
        SimpleDateFormat("dd MMM", Locale.getDefault()).format(Date(ms))

    fun ago(ms: Long): String {
        val diff = System.currentTimeMillis() - ms
        if (diff < 0) return "just now"
        val m = TimeUnit.MILLISECONDS.toMinutes(diff)
        val h = TimeUnit.MILLISECONDS.toHours(diff)
        val d = TimeUnit.MILLISECONDS.toDays(diff)
        return when {
            m < 1 -> "just now"
            m < 60 -> "${m}m ago"
            h < 24 -> "${h}h ago"
            d < 7 -> "${d}d ago"
            else -> shortDate(ms)
        }
    }

    fun duration(ms: Long): String {
        if (ms <= 0) return "--:--"
        val total = ms / 1000
        val h = total / 3600
        val m = (total % 3600) / 60
        val s = total % 60
        return if (h > 0) String.format(Locale.US, "%d:%02d:%02d", h, m, s)
        else String.format(Locale.US, "%d:%02d", m, s)
    }

    fun name(c: Context, uri: Uri): String {
        if (uri.scheme == "file") return uri.lastPathSegment ?: "file"
        return try {
            c.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)
                ?.use { cur -> if (cur.moveToFirst()) cur.getString(0) else null }
                ?: uri.lastPathSegment ?: "file"
        } catch (_: Exception) {
            uri.lastPathSegment ?: "file"
        }
    }

    fun size(c: Context, uri: Uri): Long {
        if (uri.scheme == "file") return uri.path?.let { java.io.File(it).length() } ?: 0L
        return try {
            c.contentResolver.query(uri, arrayOf(OpenableColumns.SIZE), null, null, null)
                ?.use { cur -> if (cur.moveToFirst()) cur.getLong(0) else 0L } ?: 0L
        } catch (_: Exception) {
            0L
        }
    }

    fun mime(c: Context, uri: Uri): String =
        try {
            c.contentResolver.getType(uri) ?: android.webkit.MimeTypeMap.getSingleton()
                .getMimeTypeFromExtension(ext(name(c, uri)).lowercase()) ?: "*/*"
        } catch (_: Exception) {
            "*/*"
        }

    fun ext(name: String): String = name.substringAfterLast('.', "")

    fun base(name: String): String = name.substringBeforeLast('.', name)

    fun safeName(name: String): String =
        name.replace(Regex("""[\\/:*?"<>|]"""), "_").trim().ifBlank { "file" }

    fun titleFromUrl(url: String): String = try {
        val host = Uri.parse(url).host ?: url
        host.removePrefix("www.")
    } catch (_: Exception) {
        url.take(40)
    }
}
