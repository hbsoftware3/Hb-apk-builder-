package com.example.videodownloader.tools

import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.widget.EditText
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import com.example.videodownloader.R
import com.example.videodownloader.ui.BaseActivity
import com.example.videodownloader.ui.Hb
import com.example.videodownloader.util.Launcher
import java.util.Locale

/** Text utilities: counts, case conversion, cleanup, link extraction, copy and share. */
class TextToolsActivity : BaseActivity() {

    private lateinit var input: EditText
    private lateinit var stats: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val p = Hb.palette(this)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(p.bg)
        }
        root.addView(Hb.topBar(this, "Text Tools", "Count, convert and clean text", { finish() }))

        val scroll = ScrollView(this).apply { isFillViewport = true }
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(Hb.dp(this@TextToolsActivity, 16), 0, Hb.dp(this@TextToolsActivity, 16), Hb.dp(this@TextToolsActivity, 30))
        }
        input = EditText(this).apply {
            hint = "Paste or type your text here"
            setHintTextColor(p.muted)
            setTextColor(p.text)
            textSize = 14.5f
            minLines = 8
            gravity = Gravity.TOP
            setPadding(Hb.dp(this@TextToolsActivity, 14), Hb.dp(this@TextToolsActivity, 12),
                Hb.dp(this@TextToolsActivity, 14), Hb.dp(this@TextToolsActivity, 12))
            background = Hb.round(this@TextToolsActivity, 16, p.surface, p.border, 1)
            addTextChangedListener(object : android.text.TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
                override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) { updateStats() }
                override fun afterTextChanged(s: android.text.Editable?) {}
            })
        }
        col.addView(input, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        stats = Hb.text(this, "", 11f, p.muted).apply {
            setPadding(Hb.dp(this@TextToolsActivity, 4), Hb.dp(this@TextToolsActivity, 6), 0, Hb.dp(this@TextToolsActivity, 10))
        }
        col.addView(stats)

        col.addView(Hb.section(this, "Change case"))
        col.addView(chips(listOf(
            "UPPER" to { set(transform { it.uppercase(Locale.getDefault()) }) },
            "lower" to { set(transform { it.lowercase(Locale.getDefault()) }) },
            "Title Case" to { set(transform { it.split(" ").joinToString(" ") { w -> w.replaceFirstChar { c -> if (c.isLowerCase()) c.titlecase(Locale.getDefault()) else c.toString() } } }) },
            "Sentence case" to { set(transform { s ->
                s.split(Regex("(?<=[.!?])\\s+")).joinToString(" ") { part ->
                    part.replaceFirstChar { c -> if (c.isLowerCase()) c.titlecase(Locale.getDefault()) else c.toString() }
                }
            }) }
        )))

        col.addView(Hb.section(this, "Clean up"))
        col.addView(chips(listOf(
            "Extra spaces" to { set(transform { it.replace(Regex("[ \\t]+"), " ").replace(Regex(" *\\n *"), "\n").trim() }) },
            "Blank lines" to { set(transform { it.replace(Regex("\\n{3,}"), "\n\n") }) },
            "Line breaks" to { set(transform { it.replace(Regex("[\\r\\n]+"), " ").trim() }) },
            "Trim lines" to { set(transform { s -> s.lines().joinToString("\n") { it.trim() } }) },
            "Reverse" to { set(transform { it.reversed() }) }
        )))

        col.addView(Hb.section(this, "Extract"))
        col.addView(chips(listOf(
            "Links" to { extractLinks() },
            "Numbers" to { set(transform { s -> Regex("\\d+").findAll(s).joinToString(" ") { it.value } }) },
            "Emails" to { set(transform { s -> Regex("[\\w.+-]+@[\\w-]+\\.[\\w.]+").findAll(s).joinToString(" ") { it.value } }) }
        )))

        col.addView(Hb.section(this, "Use"))
        val actions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        actions.addView(Hb.button(this, "Copy", true, R.drawable.ic_copy) {
            Launcher.copy(this@TextToolsActivity, input.text.toString(), "Text copied")
        }, LinearLayout.LayoutParams(0, Hb.dp(this@TextToolsActivity, 46), 1f).apply { marginEnd = Hb.dp(this@TextToolsActivity, 8) })
        actions.addView(Hb.button(this, "Share", false, R.drawable.ic_share) {
            val text = input.text.toString()
            if (text.isBlank()) Hb.toast(this@TextToolsActivity, "There is no text to share")
            else Launcher.shareText(this@TextToolsActivity, text, "Share text")
        }, LinearLayout.LayoutParams(0, Hb.dp(this@TextToolsActivity, 46), 1f))
        col.addView(actions)
        col.addView(Hb.button(this, "Clear", false, R.drawable.ic_delete) {
            input.setText("")
        }.apply {
            (layoutParams as LinearLayout.LayoutParams).topMargin = Hb.dp(this@TextToolsActivity, 8)
        })

        scroll.addView(col)
        root.addView(scroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        setContentView(root)
        updateStats()
    }

    private fun chips(items: List<Pair<String, () -> Unit>>): HorizontalScrollView {
        val p = Hb.palette(this)
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        items.forEach { (label, action) ->
            val chip = Hb.chip(this, label, false).apply {
                setTextColor(p.text)
                setOnClickListener { action() }
            }
            row.addView(chip, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                marginEnd = Hb.dp(this@TextToolsActivity, 8)
            })
        }
        return HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false
            addView(row)
        }
    }

    private fun transform(block: (String) -> String): String {
        val text = input.text.toString()
        return try {
            block(text)
        } catch (_: Exception) {
            text
        }
    }

    private fun set(text: String) {
        input.setText(text)
        input.setSelection(text.length)
        updateStats()
    }

    private fun updateStats() {
        val text = input.text.toString()
        val chars = text.length
        val words = text.trim().let { if (it.isEmpty()) 0 else it.split(Regex("\\s+")).size }
        val lines = if (text.isEmpty()) 0 else text.lines().size
        stats.text = "$chars characters • $words words • $lines lines"
    }

    private fun extractLinks() {
        val found = Regex("https?://[^\\s]+").findAll(input.text.toString())
            .map { it.value.trimEnd('.', ',', ')', ']', '"') }
            .toList()
        if (found.isEmpty()) {
            Hb.alert(this, "Links", "No http:// or https:// links were found in the text.")
            return
        }
        if (found.size == 1) {
            Hb.confirm(this, "Link found", found[0], "Open") {
                Launcher.openUrl(this, found[0])
            }
        } else {
            androidx.appcompat.app.AlertDialog.Builder(this, R.style.HbDialog)
                .setTitle("${found.size} links found")
                .setItems(found.toTypedArray()) { _, which ->
                    Launcher.openUrl(this, found[which])
                }
                .setNegativeButton("Copy all") { _, _ ->
                    Launcher.copy(this, found.joinToString("\n"), "Links copied")
                }
                .show()
        }
    }
}
