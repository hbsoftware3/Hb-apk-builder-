package com.example.videodownloader.browser

import java.net.URLEncoder

enum class SearchEngine(
    val id: String,
    val label: String,
    val home: String,
    private val template: String
) {
    GOOGLE("google", "Google", "https://www.google.com", "https://www.google.com/search?q=%s"),
    BING("bing", "Bing", "https://www.bing.com", "https://www.bing.com/search?q=%s"),
    DUCKDUCKGO("duckduckgo", "DuckDuckGo", "https://duckduckgo.com", "https://duckduckgo.com/?q=%s"),
    YAHOO("yahoo", "Yahoo", "https://search.yahoo.com", "https://search.yahoo.com/search?p=%s");

    fun searchUrl(query: String): String =
        template.format(URLEncoder.encode(query, "UTF-8"))

    companion object {
        fun from(id: String?): SearchEngine = entries.firstOrNull { it.id == id } ?: GOOGLE
    }
}

object BrowserUrl {

    private val schemeRx = Regex("^[a-zA-Z][a-zA-Z0-9+.-]*:")
    private val hostRx = Regex("^[a-zA-Z0-9][a-zA-Z0-9.-]*(?::\\d{1,5})?(?:/.*)?$")

    fun normalize(input: String, engineId: String? = null): String {
        val raw = input.trim()
        if (raw.isEmpty()) return SearchEngine.from(engineId).home
        val engine = SearchEngine.from(engineId)

        if (schemeRx.containsMatchIn(raw)) {
            val lower = raw.lowercase()
            return if (lower.startsWith("http://") || lower.startsWith("https://")) raw
            else engine.searchUrl(raw)
        }
        if (raw.contains(' ')) return engine.searchUrl(raw)

        val looksHost = hostRx.matches(raw) && (raw.contains('.') || raw.startsWith("localhost"))
        return if (looksHost) "https://$raw" else engine.searchUrl(raw)
    }

    fun isHttp(url: String): Boolean {
        val u = url.trim().lowercase()
        return u.startsWith("http://") || u.startsWith("https://")
    }

    fun host(url: String): String = try {
        android.net.Uri.parse(url).host?.removePrefix("www.") ?: url
    } catch (_: Exception) {
        url
    }

    fun display(url: String): String {
        if (url.isBlank() || url == "about:blank") return ""
        return try {
            val u = android.net.Uri.parse(url)
            val host = u.host ?: return url
            val path = (u.encodedPath ?: "").let { if (it == "/") "" else it }
            val q = u.encodedQuery?.let { "?$it" } ?: ""
            (host.removePrefix("www.") + path + q).take(120)
        } catch (_: Exception) {
            url.take(120)
        }
    }

    fun origin(url: String): String = try {
        val u = android.net.Uri.parse(url)
        "${u.scheme}://${u.host}"
    } catch (_: Exception) {
        url
    }
}
