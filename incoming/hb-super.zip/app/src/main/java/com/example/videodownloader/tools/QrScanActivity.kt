package com.example.videodownloader.tools

import android.Manifest
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import com.example.videodownloader.R
import com.example.videodownloader.ui.BaseActivity
import com.example.videodownloader.ui.Hb
import com.example.videodownloader.util.Launcher
import com.google.zxing.BinaryBitmap
import com.google.zxing.MultiFormatReader
import com.google.zxing.RGBLuminanceSource
import com.google.zxing.common.HybridBinarizer
import com.journeyapps.barcodescanner.ScanContract
import com.journeyapps.barcodescanner.ScanOptions

/** Camera + gallery QR/barcode scanner. Decoding happens on the device; nothing is uploaded. */
class QrScanActivity : BaseActivity() {

    private lateinit var resultCard: LinearLayout

    private val scan = registerForActivityResult(ScanContract()) { result ->
        val text = result.contents
        if (text.isNullOrBlank()) {
            Hb.toast(this, "No code was detected")
        } else {
            showResult(text, result.formatName ?: "Code")
        }
    }

    private val cameraPermission = registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) launchScanner() else Hb.alert(this, "Camera permission", "Without camera access the scanner cannot read codes. You can still scan an image from the gallery.")
    }

    private val gallery = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        uri ?: return@registerForActivityResult
        val decoded = decodeImage(uri)
        if (decoded == null) Hb.alert(this, "Gallery scan", "No readable code was found in that image.")
        else showResult(decoded.first, decoded.second)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val p = Hb.palette(this)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(p.bg)
        }
        root.addView(Hb.topBar(this, "QR Scanner", "Camera or image from gallery", { finish() }))

        val scroll = ScrollView(this).apply { isFillViewport = true }
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(Hb.dp(this@QrScanActivity, 18), Hb.dp(this@QrScanActivity, 6),
                Hb.dp(this@QrScanActivity, 18), Hb.dp(this@QrScanActivity, 30))
        }
        val hero = Hb.card(this, 18)
        hero.addView(Hb.text(this, "Scan a code", 18f, p.text, bold = true))
        hero.addView(Hb.text(this, "Point the camera at a QR or barcode. The result stays on your phone and is never sent anywhere.", 11.5f, p.muted).apply {
            setPadding(0, Hb.dp(this@QrScanActivity, 4), 0, Hb.dp(this@QrScanActivity, 14))
        })
        hero.addView(Hb.button(this, "Start camera scan", true, R.drawable.ic_camera) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
                launchScanner()
            } else {
                cameraPermission.launch(Manifest.permission.CAMERA)
            }
        })
        hero.addView(Hb.button(this, "Pick an image", false, R.drawable.ic_image) {
            gallery.launch(arrayOf("image/*"))
        }.apply {
            (layoutParams as LinearLayout.LayoutParams).topMargin = Hb.dp(this@QrScanActivity, 8)
        })
        col.addView(hero)

        resultCard = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            visibility = View.GONE
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                topMargin = Hb.dp(this@QrScanActivity, 14)
            }
        }
        col.addView(resultCard)
        col.addView(Hb.text(this, "Tip: the scanner can read links, Wi-Fi text, contact cards and plain text. It does not open links automatically.", 10.5f, p.muted).apply {
            setPadding(Hb.dp(this@QrScanActivity, 4), Hb.dp(this@QrScanActivity, 14), 0, 0)
        })
        scroll.addView(col)
        root.addView(scroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        setContentView(root)
    }

    private fun launchScanner() {
        val options = ScanOptions().apply {
            setDesiredBarcodeFormats(ScanOptions.ALL_CODE_TYPES)
            setPrompt("Align the code inside the frame")
            setBeepEnabled(true)
            setOrientationLocked(true)
            setBarcodeImageEnabled(false)
        }
        scan.launch(options)
    }

    private fun showResult(text: String, format: String) {
        resultCard.removeAllViews()
        resultCard.visibility = View.VISIBLE
        val p = Hb.palette(this)
        val card = Hb.card(this, 16)
        card.addView(Hb.text(this, "Scan result", 12f, p.success, bold = true))
        card.addView(Hb.text(this, text, 15f, p.text, medium = true).apply {
            setPadding(0, Hb.dp(this@QrScanActivity, 6), 0, 0)
            setTextIsSelectable(true)
        })
        card.addView(Hb.text(this, format, 10.5f, p.muted).apply {
            setPadding(0, Hb.dp(this@QrScanActivity, 4), 0, Hb.dp(this@QrScanActivity, 10))
        })

        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        row.addView(Hb.button(this, "Copy", true, R.drawable.ic_copy) {
            Launcher.copy(this@QrScanActivity, text, "Copied to clipboard")
        }, LinearLayout.LayoutParams(0, Hb.dp(this@QrScanActivity, 46), 1f).apply {
            marginEnd = Hb.dp(this@QrScanActivity, 8)
        })
        row.addView(Hb.button(this, "Share", false, R.drawable.ic_share) {
            Launcher.shareText(this@QrScanActivity, text, "Share scan")
        }, LinearLayout.LayoutParams(0, Hb.dp(this@QrScanActivity, 46), 1f))
        card.addView(row)

        val url = try { Uri.parse(text) } catch (_: Exception) { null }
        if (url?.scheme?.lowercase() in listOf("http", "https")) {
            card.addView(Hb.button(this, "Open in HB Browser", false, R.drawable.ic_browser) {
                Launcher.openUrl(this@QrScanActivity, text)
            }.apply {
                (layoutParams as LinearLayout.LayoutParams).topMargin = Hb.dp(this@QrScanActivity, 8)
            })
        }
        resultCard.addView(card)
    }

    /** Reads a still image through ZXing. Large photos are sampled so decoding stays quick. */
    private fun decodeImage(uri: Uri): Pair<String, String>? {
        return try {
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
            var sample = 1
            while (bounds.outWidth / sample > 1800 || bounds.outHeight / sample > 1800) sample *= 2
            val opts = BitmapFactory.Options().apply { inSampleSize = sample; inPreferredConfig = Bitmap.Config.ARGB_8888 }
            val bitmap = contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) }
                ?: return null
            val width = bitmap.width
            val height = bitmap.height
            val pixels = IntArray(width * height)
            bitmap.getPixels(pixels, 0, width, 0, 0, width, height)
            bitmap.recycle()
            val source = RGBLuminanceSource(width, height, pixels)
            val binary = BinaryBitmap(HybridBinarizer(source))
            val result = MultiFormatReader().decodeWithState(binary)
            result.text to (result.barcodeFormat?.name ?: "Code")
        } catch (_: Exception) {
            null
        }
    }
}
