package com.example.videodownloader

import java.io.File
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URL

/**
 * Backup way that needs NO login. Used only when yt-dlp failed on every try.
 * Reads the public page of the post, finds the direct video address and downloads it.
 * Works for public Instagram and Facebook videos. Private posts cannot work without login.
 */
object DirectFallback {

    /** Returns true if a video file was written into outDir. */
    fun download(url: String, site: Site, outDir: File, ctl: DlControl?, onProgress: (Int) -> Unit): Boolean {
        val videoUrl = try {
            when (site) {
                Site.INSTAGRAM -> instagramVideoUrl(url)
                Site.FACEBOOK -> facebookVideoUrl(url)
                else -> null
            }
        } catch (_: Exception) {
            null
        } ?: return false

        val out = File(outDir, "${site.label.lowercase()}_video_${System.currentTimeMillis()}.mp4")
        var attempt = 0
        var lastPercent = -1
        while (attempt < 6) {
            try {
                if (ctl?.cancelled == true) return false
                while (ctl != null && ctl.paused && !ctl.cancelled) Thread.sleep(300)

                val alreadyHave = if (out.exists()) out.length() else 0L
                val c = open(videoUrl, UrlTools.DESKTOP_UA, alreadyHave)
                try {
                    val code = c.responseCode
                    // Resume only when the server confirms Range support. Otherwise restart safely.
                    val append = alreadyHave > 0 && code == HttpURLConnection.HTTP_PARTIAL
                    if (alreadyHave > 0 && !append) {
                        c.disconnect()
                        out.delete()
                        continue
                    }
                    if (code !in 200..299) throw java.io.IOException("HTTP $code")
                    val remaining = c.contentLengthLong
                    val total = if (remaining <= 0L) -1L else if (append) alreadyHave + remaining else remaining
                    c.inputStream.use { input ->
                        FileOutputStream(out, append).buffered(256 * 1024).use { output ->
                            val buf = ByteArray(256 * 1024)
                            var done = alreadyHave
                            while (true) {
                                while (ctl != null && ctl.paused && !ctl.cancelled) Thread.sleep(300)
                                if (ctl?.cancelled == true) return false
                                val n = input.read(buf)
                                if (n < 0) break
                                output.write(buf, 0, n)
                                done += n
                                if (total > 0L) {
                                    val pct = (done * 100 / total).toInt().coerceIn(0, 100)
                                    if (pct != lastPercent) {
                                        lastPercent = pct
                                        onProgress(pct)
                                    }
                                }
                            }
                            output.flush()
                        }
                    }
                    if (out.length() > 10_000 && (total <= 0 || out.length() >= total)) return true
                    throw java.io.IOException("Download incomplete")
                } finally {
                    c.disconnect()
                }
            } catch (e: Exception) {
                if (ctl?.cancelled == true) return false
                attempt++
                if (attempt >= 6) break
                // Preserve partial bytes so the next request can continue when Range is supported.
                Thread.sleep((1000L * attempt).coerceAtMost(6000L))
            }
        }
        return false
    }

    private fun open(url: String, ua: String, resumeAt: Long = 0L): HttpURLConnection {
        val c = URL(url).openConnection() as HttpURLConnection
        c.instanceFollowRedirects = true
        c.connectTimeout = 30000
        c.readTimeout = 120000
        c.setRequestProperty("Accept-Encoding", "identity")
        if (resumeAt > 0L) c.setRequestProperty("Range", "bytes=$resumeAt-")
        c.setRequestProperty("User-Agent", ua)
        c.setRequestProperty("Accept-Language", "en-US,en;q=0.9")
        c.setRequestProperty("Accept", "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8")
        return c
    }

    private fun getText(url: String, ua: String): String {
        val c = open(url, ua)
        return try {
            c.inputStream.bufferedReader().use { it.readText() }
        } finally {
            c.disconnect()
        }
    }

    /** Turns "https:\/\/x.com\/a?b=1\u0026c=2" (as found inside page scripts) into a normal address. */
    private fun unescape(s: String): String {
        var r = s
        repeat(2) {
            r = r.replace("\\u0026", "&").replace("\\u0025", "%").replace("\\u003D", "=")
                .replace("\\/", "/").replace("&amp;", "&")
        }
        return r.replace("\\", "")
    }

    private fun instagramVideoUrl(url: String): String? {
        val code = Regex("instagram\\.com/(?:[^/]+/)?(?:p|reel|reels|tv)/([A-Za-z0-9_-]+)")
            .find(url)?.groupValues?.get(1) ?: return null
        val pages = listOf(
            "https://www.instagram.com/p/$code/embed/captioned/",
            "https://www.instagram.com/reel/$code/embed/",
            "https://www.instagram.com/p/$code/embed/"
        )
        val rx = Regex("video_url\\\\*\"\\s*:\\s*\\\\*\"(https:[^\"]+?)\\\\*\"")
        val rxAlt = Regex("<video[^>]+src=\"([^\"]+)\"")
        for (p in pages) {
            val html = try { getText(p, UrlTools.DESKTOP_UA) } catch (_: Exception) { continue }
            rx.find(html)?.groupValues?.get(1)?.let { return unescape(it) }
            rxAlt.find(html)?.groupValues?.get(1)?.let { return unescape(it) }
        }
        return null
    }

    private fun facebookVideoUrl(url: String): String? {
        val pages = listOf(
            UrlTools.facebookMobile(UrlTools.facebookDesktop(url)),
            UrlTools.facebookDesktop(url)
        ).distinct()
        val keys = listOf(
            "browser_native_hd_url", "playable_url_quality_hd", "hd_src", "hd_src_no_ratelimit",
            "browser_native_sd_url", "playable_url", "sd_src", "sd_src_no_ratelimit"
        )
        for (p in pages) {
            for (ua in listOf(UrlTools.MOBILE_UA, UrlTools.DESKTOP_UA)) {
                val html = try { getText(p, ua) } catch (_: Exception) { continue }
                for (k in keys) {
                    Regex("\"$k\"\\s*:\\s*\"(https:[^\"]+)\"").find(html)
                        ?.groupValues?.get(1)?.let { return unescape(it) }
                }
            }
        }
        return null
    }
}
