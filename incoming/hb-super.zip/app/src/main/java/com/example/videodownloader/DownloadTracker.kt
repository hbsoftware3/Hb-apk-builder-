package com.example.videodownloader

import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.update

/** One download that is waiting or running right now. */
data class ActiveDownload(
    val id: Int,
    val site: String,
    val url: String,
    val audio: Boolean,
    val text: String,
    val percent: Int,
    val indeterminate: Boolean,
    val paused: Boolean = false
)

/** Live list of running downloads. The service writes to it, the main screen shows it. */
object DownloadTracker {
    private val _items = MutableStateFlow<List<ActiveDownload>>(emptyList())
    val items: StateFlow<List<ActiveDownload>> = _items

    /** One-time messages for the main screen ("Completed: ...", "Failed: ..."). */
    private val _messages = MutableSharedFlow<String>(extraBufferCapacity = 8)
    val messages: SharedFlow<String> = _messages

    /** true if this exact link is already waiting or running (same video / audio type). */
    fun isActive(url: String, audio: Boolean): Boolean =
        _items.value.any { it.url == url && it.audio == audio }

    fun say(text: String) {
        _messages.tryEmit(text)
    }

    fun start(id: Int, site: String, url: String, audio: Boolean) {
        _items.update { it + ActiveDownload(id, site, url, audio, "Waiting in queue...", 0, true) }
    }

    fun progress(id: Int, text: String, pct: Int, indeterminate: Boolean) {
        _items.update { list ->
            list.map { if (it.id == id) it.copy(text = text, percent = pct, indeterminate = indeterminate) else it }
        }
    }

    fun setPaused(id: Int, paused: Boolean) {
        _items.update { list -> list.map { if (it.id == id) it.copy(paused = paused) else it } }
    }

    fun finish(id: Int) {
        _items.update { list -> list.filter { it.id != id } }
    }

    fun clear() {
        _items.value = emptyList()
    }
}
