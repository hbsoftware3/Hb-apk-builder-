package com.example.videodownloader

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.ContentValues
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.MediaCodecList
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaMetadataRetriever
import android.media.MediaScannerConnection
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.Uri
import android.os.Environment
import android.os.IBinder
import android.provider.MediaStore
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import com.yausername.ffmpeg.FFmpeg
import com.yausername.youtubedl_android.YoutubeDL
import com.yausername.youtubedl_android.YoutubeDLRequest
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import java.io.File
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicInteger

class DownloadService : Service() {

    companion object {
        const val EXTRA_URL = "url"
        const val EXTRA_AUDIO = "audio"
        const val EXTRA_ID = "dl_id"
        const val EXTRA_TAB = "tab"
        // Optional context handed over by HB Browser (all three may be missing)
        const val EXTRA_REFERER = "referer"
        const val EXTRA_UA = "ua"
        const val EXTRA_COOKIES = "cookies_file"
        const val EXTRA_HEIGHT = "height"
        const val EXTRA_PLAYLIST = "playlist"
        const val ACTION_PAUSE = "com.example.videodownloader.PAUSE"
        const val ACTION_RESUME = "com.example.videodownloader.RESUME"
        const val ACTION_CANCEL = "com.example.videodownloader.CANCEL"
        private const val CH_PROGRESS = "progress"
        private const val CH_DONE = "done"
        private const val FG_ID = 1
        // Bigger files are not converted: it would take too long on a phone (the original is kept)
        private const val MAX_CONVERT_BYTES = 300L * 1024 * 1024
    }

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val limiter = Semaphore(3) // max 3 downloads at a time
    private val active = AtomicInteger(0)
    private val ids = AtomicInteger(100)
    private lateinit var nm: NotificationManager

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CH_PROGRESS, "Download progress", NotificationManager.IMPORTANCE_LOW)
        )
        nm.createNotificationChannel(
            NotificationChannel(CH_DONE, "Download result", NotificationManager.IMPORTANCE_DEFAULT)
        )
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        // Buttons on the notification: Pause / Resume / Cancel
        val act = intent?.action
        if (act == ACTION_PAUSE || act == ACTION_RESUME || act == ACTION_CANCEL) {
            val tid = intent?.getIntExtra(EXTRA_ID, -1) ?: -1
            when (act) {
                ACTION_PAUSE -> DownloadControl.pause(tid)
                ACTION_RESUME -> DownloadControl.resume(tid)
                else -> DownloadControl.cancel(tid)
            }
            if (tid >= 0 && DownloadControl.get(tid) == null) nm.cancel(tid) // old leftover notification
            if (active.get() == 0) stopSelf()
            return START_NOT_STICKY
        }
        val url = intent?.getStringExtra(EXTRA_URL)
        if (url == null) {
            showForeground()
            stopIfIdle()
            return START_NOT_STICKY
        }
        val audio = intent?.getBooleanExtra(EXTRA_AUDIO, false) ?: false
        val referer = intent?.getStringExtra(EXTRA_REFERER)?.takeIf { it.startsWith("http") }
        val userAgent = intent?.getStringExtra(EXTRA_UA)?.takeIf { it.isNotBlank() }
        val cookies = intent?.getStringExtra(EXTRA_COOKIES)?.takeIf { it.isNotBlank() }
        val height = intent?.getIntExtra(EXTRA_HEIGHT, 0) ?: 0
        val playlist = intent?.getBooleanExtra(EXTRA_PLAYLIST, false) ?: false
        if (DownloadTracker.isActive(url, audio)) {
            // Same link is already downloading: do not start a second copy
            DownloadTracker.say("Already downloading this link")
            showForeground()
            stopIfIdle()
            return START_NOT_STICKY
        }
        val id = ids.incrementAndGet()
        active.incrementAndGet()
        DownloadControl.register(id)
        DownloadTracker.start(id, Site.detect(url).label, url, audio)
        showForeground()
        scope.launch {
            try {
                limiter.withPermit {
                    runDownload(url, id, audio, referer, userAgent, cookies, height, playlist)
                }
            } finally {
                DownloadTracker.finish(id)
                DownloadControl.remove(id)
                active.decrementAndGet()
                stopIfIdle()
            }
        }
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        DownloadTracker.clear()
        scope.cancel()
        super.onDestroy()
    }

    /** Tapping a notification opens the app, where the live progress is shown. */
    private fun openAppIntent(): PendingIntent {
        val i = Intent(this, MainActivity::class.java)
            .addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP)
            .putExtra(EXTRA_TAB, "downloader")
        return PendingIntent.getActivity(
            this, 0, i, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
    }

    private fun showForeground() {
        val n = NotificationCompat.Builder(this, CH_PROGRESS)
            .setSmallIcon(R.drawable.ic_stat_hb)
            .setContentTitle("HB Super App")
            .setContentText("Downloads running: ${active.get()}")
            .setContentIntent(openAppIntent())
            .setOngoing(true)
            .build()
        ServiceCompat.startForeground(this, FG_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
    }

    private fun stopIfIdle() {
        if (active.get() == 0) {
            ServiceCompat.stopForeground(this, ServiceCompat.STOP_FOREGROUND_REMOVE)
            stopSelf()
        }
    }

    /** One way of trying a download. We try several, one after another, until one works. */
    private data class Attempt(
        val url: String,
        val ytClient: String? = null,
        val userAgent: String? = null,
        val referer: String? = null,
        val extractorArgs: String? = null,
        val cookiesFile: String? = null
    )

    private fun buildAttempts(
        rawUrl: String,
        site: Site,
        height: Int,
        browserReferer: String? = null,
        browserUa: String? = null,
        cookiesFile: String? = null
    ): List<Attempt> {
        val base = baseAttempts(rawUrl, site, height)
        val withCookies = if (cookiesFile == null) base else base.map { it.copy(cookiesFile = cookiesFile) }
        // The browser knows the page it came from (referer) and its own user agent. Try that exact
        // context first: sites that refuse plain yt-dlp often accept it.
        val browser = if (browserReferer != null || browserUa != null) {
            listOf(Attempt(UrlTools.clean(rawUrl), userAgent = browserUa, referer = browserReferer, cookiesFile = cookiesFile))
        } else {
            emptyList()
        }
        return (browser + withCookies).distinct()
    }

    private fun baseAttempts(rawUrl: String, site: Site, height: Int): List<Attempt> {
        val url = UrlTools.clean(rawUrl)
        // Short links (vm.tiktok.com, fb.watch, facebook.com/share/...) -> real address
        val resolved = UrlTools.resolve(url)

        return when (site) {
            Site.YOUTUBE ->
                // Phone-style clients only give low quality, so for 1440p/4K use the web-style ones
                (if (height > 1080) listOf(null, "web", "tv", "ios") else listOf(null, "android", "ios", "web"))
                    .map { Attempt(url, ytClient = it) }

            Site.INSTAGRAM -> {
                val bare = resolved.substringBefore('?')
                val urls = listOf(url, bare).distinct()
                val out = mutableListOf<Attempt>()
                for (u in urls) {
                    out += Attempt(u)
                    out += Attempt(u, userAgent = UrlTools.MOBILE_UA)
                    out += Attempt(u, userAgent = UrlTools.DESKTOP_UA, referer = "https://www.instagram.com/")
                }
                out
            }

            Site.TIKTOK -> {
                val urls = listOf(resolved, url).distinct()
                val out = mutableListOf<Attempt>()
                for (u in urls) {
                    out += Attempt(u, referer = "https://www.tiktok.com/")
                    out += Attempt(u, userAgent = UrlTools.DESKTOP_UA, referer = "https://www.tiktok.com/")
                    out += Attempt(
                        u, userAgent = UrlTools.MOBILE_UA, referer = "https://www.tiktok.com/",
                        extractorArgs = "tiktok:api_hostname=api22-normal-c-useast2a.tiktokv.com"
                    )
                    out += Attempt(
                        u, referer = "https://www.tiktok.com/",
                        extractorArgs = "tiktok:api_hostname=api16-normal-c-useast1a.tiktokv.com"
                    )
                }
                out
            }

            Site.FACEBOOK -> {
                val desktop = UrlTools.facebookDesktop(resolved)
                val urls = listOf(desktop, resolved, url, UrlTools.facebookMobile(desktop)).distinct()
                val out = mutableListOf<Attempt>()
                for (u in urls) {
                    out += Attempt(u)
                    out += Attempt(u, userAgent = UrlTools.DESKTOP_UA, referer = "https://www.facebook.com/")
                    out += Attempt(u, userAgent = UrlTools.MOBILE_UA)
                }
                out
            }

            Site.X -> listOf(
                Attempt(url),
                Attempt(url, userAgent = UrlTools.DESKTOP_UA, referer = "https://x.com/")
            )

            Site.REDDIT -> listOf(
                Attempt(url),
                Attempt(url, userAgent = UrlTools.DESKTOP_UA, referer = "https://www.reddit.com/")
            )

            Site.VIMEO -> listOf(
                Attempt(url),
                Attempt(url, userAgent = UrlTools.DESKTOP_UA, referer = "https://vimeo.com/")
            )

            Site.DAILYMOTION -> listOf(
                Attempt(url),
                Attempt(url, userAgent = UrlTools.DESKTOP_UA, referer = "https://www.dailymotion.com/")
            )

            Site.PINTEREST -> listOf(
                Attempt(url),
                Attempt(url, userAgent = UrlTools.MOBILE_UA, referer = "https://www.pinterest.com/")
            )

            Site.SNAPCHAT -> listOf(
                Attempt(url),
                Attempt(url, userAgent = UrlTools.DESKTOP_UA, referer = "https://www.snapchat.com/")
            )

            Site.THREADS -> listOf(
                Attempt(url),
                Attempt(url, userAgent = UrlTools.MOBILE_UA, referer = "https://www.threads.net/")
            )

            Site.TWITCH -> listOf(
                Attempt(url),
                Attempt(url, userAgent = UrlTools.DESKTOP_UA, referer = "https://www.twitch.tv/")
            )

            Site.LIKEE -> listOf(
                Attempt(url),
                Attempt(url, userAgent = UrlTools.MOBILE_UA, referer = "https://likee.video/")
            )

            Site.LINKEDIN -> listOf(
                Attempt(url),
                Attempt(url, userAgent = UrlTools.DESKTOP_UA, referer = "https://www.linkedin.com/")
            )

            Site.OTHER -> listOf(Attempt(UrlTools.resolve(url)))
        }
    }

    /** Builds the yt-dlp command for one attempt. (Converting to H.264/AAC is done later by Transcoder.) */
    private fun makeRequest(a: Attempt, tmp: File, height: Int, audio: Boolean, playlist: Boolean = false): YoutubeDLRequest =
        YoutubeDLRequest(a.url).apply {
            addOption("-o", "${tmp.absolutePath}/%(title).60s [%(id)s].%(ext)s")
            if (audio) {
                // Audio only: best sound, converted to MP3
                addOption("-f", "bestaudio/best")
                addOption("-x")
                addOption("--audio-format", "mp3")
                addOption("--audio-quality", "0")
            } else {
                addOption("-f", Quality.format(height))
                addOption("-S", Quality.sort(height))
                // mp4 up to 1080p; above that let yt-dlp choose (webm/mkv) because VP9 does not fit mp4 everywhere
                if (height <= 1080) addOption("--merge-output-format", "mp4")
            }
            if (playlist) addOption("--yes-playlist") else addOption("--no-playlist")
            addOption("--no-mtime")
            // Weak / slow network: patient timeouts, many retries with growing pauses,
            // small download pieces (a broken piece is re-fetched, not the whole file), continue half files
            addOption("--retries", "20")
            addOption("--fragment-retries", "20")
            addOption("--extractor-retries", "5")
            addOption("--file-access-retries", "5")
            addOption("--retry-sleep", "http:exp=1:30")
            addOption("--retry-sleep", "fragment:exp=1:30")
            addOption("--socket-timeout", "60")
            // Speed: YouTube keeps its own (larger) piece size; other sites use 8 MB pieces.
            // 16 fragments at once for streams that come in many small parts.
            // --throttled-rate makes yt-dlp start over ("re-extract") when the speed stays below the limit.
            // That is meant for YouTube slowing a download on purpose, but on a slow connection it
            // restarted the same download again and again without end. So: YouTube only, and a low limit.
            val isYoutube = Site.detect(a.url) == Site.YOUTUBE
            if (!isYoutube) addOption("--http-chunk-size", "8M")
            addOption("--buffer-size", "1M")
            addOption("--concurrent-fragments", "16")
            if (isYoutube) addOption("--throttled-rate", "30K")
            addOption("--continue")
            addOption("--force-ipv4")
            addOption("--geo-bypass")
            if (a.ytClient != null) {
                addOption("--extractor-args", "youtube:player_client=${a.ytClient}")
            }
            if (a.extractorArgs != null) {
                addOption("--extractor-args", a.extractorArgs)
            }
            if (a.userAgent != null) {
                addOption("--user-agent", a.userAgent)
            }
            if (a.referer != null) {
                addOption("--referer", a.referer)
            }
            if (a.cookiesFile != null) {
                addOption("--cookies", a.cookiesFile)
            }
        }

    /**
     * True if this phone has no HARDWARE decoder for the video (typical for VP9/AV1/HEVC in some files).
     * Such videos lag, or only play smoothly with "SW decoder" in MX Player, and may not show in the gallery.
     */
    private fun needsRecode(f: File): Boolean {
        val ex = MediaExtractor()
        return try {
            ex.setDataSource(f.absolutePath)
            var checked = false
            for (i in 0 until ex.trackCount) {
                val fmt = ex.getTrackFormat(i)
                val mime = fmt.getString(MediaFormat.KEY_MIME) ?: continue
                if (!mime.startsWith("video/")) continue
                checked = true
                val hw = MediaCodecList(MediaCodecList.REGULAR_CODECS).codecInfos.any { ci ->
                    !ci.isEncoder && ci.isHardwareAccelerated &&
                        ci.supportedTypes.any { it.equals(mime, ignoreCase = true) } &&
                        try {
                            ci.getCapabilitiesForType(mime).isFormatSupported(fmt)
                        } catch (_: Exception) {
                            true
                        }
                }
                if (!hw) return true
            }
            !checked
        } catch (_: Exception) {
            false
        } finally {
            try { ex.release() } catch (_: Exception) { }
        }
    }

    /**
     * Runs yt-dlp. Handles Pause (waits, then continues the same file), weak internet (waits, then
     * continues) and "Wi-Fi only" (if Wi-Fi is lost in the middle, waits for Wi-Fi instead of using mobile data).
     */
    private fun executeResumable(req: YoutubeDLRequest, ctl: DlControl, id: Int, label: String) {
        var netWaits = 0
        var last = -1
        var lastUi = 0L
        var lastWifiCheck = 0L
        var speedText = ""
        var etaSec: Long? = null
        var totalBytes = 0L
        val wifiLost = AtomicBoolean(false)
        while (true) {
            ctl.throwIfCancelled()
            waitWhilePaused(id, ctl)
            wifiLost.set(false)
            try {
                YtDlpGate.withYtDlp {
                    YoutubeDL.getInstance().execute(req, ctl.processId) { p, _, line ->
                        val now = System.currentTimeMillis()
                        // "Download only on Wi-Fi" has to hold for the whole download, not only at the start
                        if (now - lastWifiCheck > 2000) {
                            lastWifiCheck = now
                            if (Prefs.wifiOnly(this) && !onWifi() && !ctl.paused && !ctl.cancelled) {
                                wifiLost.set(true)
                                YoutubeDL.getInstance().destroyProcessById(ctl.processId)
                                return@execute
                            }
                        }
                        ProgressInfo.speed(line)?.let { speedText = "  |  $it" }
                        ProgressInfo.etaSeconds(line)?.let { etaSec = it }
                        ProgressInfo.totalBytes(line)?.let { totalBytes = it }
                        val pct = p.toInt().coerceIn(0, 100)
                        if (!ctl.paused && (pct != last || now - lastUi > 2000)) {
                            last = pct
                            lastUi = now
                            ctl.pct = pct
                            val left = etaSec?.let { "  |  ${ProgressInfo.clock(it)} left" } ?: ""
                            val sizeText = if (totalBytes > 0)
                                "  |  ${HistoryStore.fmtSize(totalBytes * pct / 100)} / ${HistoryStore.fmtSize(totalBytes)}" else ""
                            notifyProgress(id, "Download: $pct%$sizeText  |  $label$speedText$left", pct, false)
                        }
                    }
                }
                return
            } catch (e: Exception) {
                if (ctl.cancelled) throw UserCancelled()
                if (ctl.paused) continue // loop top waits until Resume, then yt-dlp continues the .part file
                if (wifiLost.get()) {
                    waitForWifi(id, ctl) // then yt-dlp continues the same .part file
                    continue
                }
                if (isNetworkError(e.message.orEmpty()) && netWaits < 40) {
                    netWaits++
                    waitForInternet(id, ctl)
                    continue
                }
                throw e
            }
        }
    }

    private fun waitWhilePaused(id: Int, ctl: DlControl) {
        if (!ctl.paused) return
        notifyProgress(id, "Paused. Tap Resume to continue.", ctl.pct, false)
        while (ctl.paused && !ctl.cancelled) Thread.sleep(300)
        ctl.throwIfCancelled()
        notifyProgress(id, "Resuming...", ctl.pct, ctl.pct == 0)
    }

    private fun hasInternet(): Boolean = try {
        val cm = getSystemService(ConnectivityManager::class.java)
        val caps = cm.getNetworkCapabilities(cm.activeNetwork)
        caps != null &&
            caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) &&
            caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED)
    } catch (_: Exception) {
        true
    }

    /** Waits (up to 15 minutes) for the internet to come back. The download then continues by itself. */
    private fun waitForInternet(id: Int, ctl: DlControl) {
        val limit = System.currentTimeMillis() + 15 * 60_000L
        var shown = false
        while (System.currentTimeMillis() < limit) {
            ctl.throwIfCancelled()
            if (ctl.paused) return
            if (hasInternet()) {
                if (shown) Thread.sleep(1500)
                else Thread.sleep(2500) // slow network: short breather, then continue the same file
                notifyProgress(id, "Connection back. Continuing...", ctl.pct, ctl.pct == 0)
                return
            }
            if (!shown) {
                shown = true
                notifyProgress(id, "No internet. Waiting... it continues by itself.", ctl.pct, ctl.pct == 0)
            }
            Thread.sleep(2000)
        }
    }

    /** true if the phone is connected through Wi-Fi (or a cable). */
    private fun onWifi(): Boolean = try {
        val cm = getSystemService(ConnectivityManager::class.java)
        val caps = cm.getNetworkCapabilities(cm.activeNetwork)
        caps != null && (caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) ||
            caps.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET))
    } catch (_: Exception) {
        true
    }

    /** "Download only on Wi-Fi" is on: wait (up to 3 hours) until Wi-Fi is connected, then start by itself. */
    private fun waitForWifi(id: Int, ctl: DlControl) {
        if (!Prefs.wifiOnly(this) || onWifi()) return
        notifyProgress(id, "Waiting for Wi-Fi... it starts by itself (Wi-Fi only is on).", 0, true)
        val limit = System.currentTimeMillis() + 3 * 60 * 60_000L
        while (Prefs.wifiOnly(this) && !onWifi()) {
            ctl.throwIfCancelled()
            if (System.currentTimeMillis() > limit) {
                throw Exception("Wi-Fi was not available for 3 hours. Connect to Wi-Fi and tap Retry in History, or turn off Wi-Fi only in Settings.")
            }
            Thread.sleep(2000)
        }
        notifyProgress(id, "Wi-Fi connected. Starting...", 0, true)
    }

    private fun isNetworkError(raw: String): Boolean {
        val m = raw.lowercase()
        return listOf(
            "unable to resolve host", "no address associated", "timed out", "timeout",
            "connection reset", "connection refused", "connection aborted", "network is unreachable",
            "temporary failure in name resolution", "name or service not known", "remote end closed",
            "incompleteread", "ssl:", "sslerror", "eof occurred", "transporterror", "urlopen error",
            "software caused connection abort", "broken pipe", "read error"
        ).any { it in m }
    }

    private fun runDownload(
        url: String,
        id: Int,
        audio: Boolean,
        referer: String? = null,
        userAgent: String? = null,
        cookies: String? = null,
        heightOverride: Int = 0,
        playlist: Boolean = false
    ) {
        val ctl = DownloadControl.get(id) ?: DownloadControl.register(id)
        if (ctl.cancelled) {
            // Cancelled while waiting in the queue
            nm.cancel(id)
            DownloadTracker.say("Download cancelled")
            return
        }
        val height = if (heightOverride > 0) heightOverride else Prefs.quality(this)
        val qLabel = if (audio) "Audio MP3" else Quality.label(height)
        val site = Site.detect(url)

        notifyProgress(id, "Starting... (${site.label}, $qLabel)", 0, true)
        val tmp = File(cacheDir, "dl_$id").apply { deleteRecursively(); mkdirs() }
        // Link shared from another app has no cookies: use the login saved in HB Browser (Instagram)
        val cookieFile: String? = cookies
            ?: if (Prefs.autoSiteLogin(this)) SiteLogin.cookieFile(this, site) else null
        val hadLogin = cookieFile != null
        try {
            waitWhilePaused(id, ctl)
            waitForWifi(id, ctl)
            YoutubeDL.getInstance().init(application)
            FFmpeg.getInstance().init(application)

            val attempts = buildAttempts(url, site, height, referer, userAgent, cookieFile)

            var lastErr: Exception? = null
            var success = false
            val deadline = System.currentTimeMillis() + 4 * 60_000L // stop trying new ways after 4 minutes
            for (round in 0..1) {
                for (a in attempts) {
                    if (System.currentTimeMillis() > deadline) break
                    try {
                        tmp.listFiles()?.forEach { it.delete() }
                        val req = makeRequest(a, tmp, height, audio, playlist)
                        executeResumable(req, ctl, id, "${site.label}  |  $qLabel")
                        // Make sure a real file came out, otherwise try the next way
                        if (usableFiles(tmp, site, audio).isEmpty()) {
                            throw Exception("ERROR: Downloaded file is empty or has no playable video")
                        }
                        success = true
                        break
                    } catch (e: UserCancelled) {
                        throw e
                    } catch (e: Exception) {
                        lastErr = e
                        // Video is really gone: no point trying other tricks
                        if (isHopeless(e.message.orEmpty())) break
                    }
                }
                if (success) break
                if (lastErr != null && isHopeless(lastErr.message.orEmpty())) break
                if (round == 0 && System.currentTimeMillis() < deadline) {
                    // First round failed: update yt-dlp to nightly and try again
                    notifyProgress(id, "Updating yt-dlp...", 0, true)
                    try {
                        // skipped while other downloads run: replacing yt-dlp under them would break them
                        YtDlpGate.updateWhenIdle {
                            YoutubeDL.getInstance()
                                .updateYoutubeDL(application, YoutubeDL.UpdateChannel.NIGHTLY)
                        }
                    } catch (_: Exception) {
                    }
                    notifyProgress(id, "Retrying...", 0, true)
                }
            }
            if (!success && !audio && (site == Site.INSTAGRAM || site == Site.FACEBOOK) &&
                !(lastErr != null && isHopeless(lastErr.message.orEmpty()))
            ) {
                // Last chance without login: read the public page and download the video directly
                notifyProgress(id, "Trying backup method...", 0, true)
                tmp.listFiles()?.forEach { it.delete() }
                val ok = DirectFallback.download(UrlTools.resolve(UrlTools.clean(url)), site, tmp, ctl) { pct ->
                    ctl.pct = pct
                    notifyProgress(id, "Download: $pct%  |  ${site.label}  |  backup", pct, false)
                }
                ctl.throwIfCancelled()
                if (ok && usableFiles(tmp, site, audio).isNotEmpty()) success = true
            }
            if (!success) throw (lastErr ?: Exception("Unknown error"))

            // Smooth playback check: if this phone can only play the video with the slow software decoder,
            // convert the file we already have to H.264/AAC (no second download). If the conversion does
            // not work, the original file is kept.
            if (!audio) {
                val v = usableFiles(tmp, site, false).firstOrNull { it.extension.lowercase() in videoExt }
                if (v != null && height <= 1080 && v.length() <= MAX_CONVERT_BYTES && needsRecode(v)) {
                    notifyProgress(id, "Making video smooth for your phone... (this can take a minute)", 0, true)
                    val fixed = try {
                        Transcoder.toH264(applicationContext, v, ctl)
                    } catch (e: UserCancelled) {
                        throw e
                    } catch (_: Exception) {
                        null
                    }
                    if (fixed != null) {
                        val target = File(tmp, v.nameWithoutExtension + ".mp4")
                        v.delete()
                        fixed.renameTo(target) // if this fails the converted file just keeps its own name
                    }
                }
            }

            val files = usableFiles(tmp, site, audio)
            if (files.isEmpty()) throw Exception("ERROR: Downloaded file not found")

            notifyProgress(id, "Saving...", 100, true)
            // Save everything that came out (a post can have several videos/photos), each as its real type
            val saved = files.map { f ->
                val mime = mimeFor(f.extension)
                Triple(f, mime, saveFile(f, mime, site))
            }
            val (file, mime, out) = saved.first()
            val uri = out.uri
            val where = out.where +
                (if (saved.any { it.third.fallback }) "  (your chosen folder was not available)" else "")
            val baseTitle = file.nameWithoutExtension.replace(Regex("\\s\\[[^\\]]+\\]$"), "")
            val title = if (saved.size > 1) "$baseTitle (+${saved.size - 1} more)" else baseTitle

            HistoryStore.add(
                this,
                HistoryItem(
                    id = System.currentTimeMillis(), url = url, title = title,
                    uri = uri.toString(), mime = mime, ok = true, message = "Saved in: $where",
                    quality = qLabel, time = System.currentTimeMillis(),
                    size = saved.sumOf { it.first.length() }
                )
            )
            notifyDone(id, uri, mime, title, where)
            DownloadTracker.say("Completed: $title\nSaved in: $where")
        } catch (e: UserCancelled) {
            nm.cancel(id)
            DownloadTracker.say("Download cancelled")
        } catch (e: Exception) {
            val rawMsg = e.message.orEmpty().trim()
            // never show an empty or "null" message: show what really happened instead
            val raw = if (rawMsg.isBlank() || rawMsg == "null") "ERROR: " + e.toString() else rawMsg
            val line = raw.lineSequence().lastOrNull { it.contains("ERROR") } ?: raw
            val msg = friendly(line, site, hadLogin)
            HistoryStore.add(
                this,
                HistoryItem(
                    id = System.currentTimeMillis(), url = url, title = url,
                    uri = null, mime = null, ok = false,
                    message = msg + "\n\nDetails: " + line.take(400),
                    quality = qLabel, time = System.currentTimeMillis()
                )
            )
            notifyError(id, msg.take(300).ifBlank { "Unknown error" })
            DownloadTracker.say("Failed: " + msg.take(160).ifBlank { "Unknown error" })
        } finally {
            tmp.deleteRecursively()
            // A browser cookie file is created for this one download; never keep it around.
            if (cookieFile != null) {
                try {
                    val f = File(cookieFile)
                    if (f.absolutePath.startsWith(cacheDir.absolutePath + File.separator)) f.delete()
                } catch (_: Exception) {
                }
            }
        }
    }

    /** Errors where trying other tricks cannot help (deleted video, photo post, no internet). */
    private fun isHopeless(raw: String): Boolean {
        val m = raw.lowercase()
        return "video has been removed" in m || "video is unavailable" in m ||
            "has been deleted" in m || "does not exist" in m ||
            "unable to resolve host" in m || "no address associated" in m ||
            ("unsupported url" in m && "tiktok.com" in m && "/photo/" in m)
    }

    /** The site refused without login (typical for private posts or when it limits requests). */
    private fun blockedWithoutLogin(raw: String): Boolean {
        val m = raw.lowercase()
        val hints = listOf(
            "login", "log in", "cookies", "private", "restricted", "empty media", "rate-limit",
            "rate limit", "impersonat", "unable to extract", "cannot parse", "you must", "401", "403"
        )
        return hints.any { it in m }
    }

    private fun friendly(raw: String, site: Site, hadLogin: Boolean = false): String {
        val m = raw.lowercase()
        return when {
            site == Site.INSTAGRAM && ("login" in m || "rate-limit" in m || "rate limit" in m || "cookies" in m) ->
                if (hadLogin)
                    "Instagram did not accept your saved login. It may have expired or Instagram wants a check. Open Settings > Instagram login, log in again, then tap Retry."
                else
                    "Instagram needs you to log in once. Open Settings > Instagram login, log in inside HB Browser, then tap Retry. After that, shared links download by themselves."
            "no space left" in m || "enospc" in m || "not enough space" in m ->
                "Phone storage is full. Free some space, then tap Retry in History."
            "unable to resolve host" in m || "no address associated" in m || "timed out" in m || "network" in m ->
                "Network problem. Check your internet connection and try again."
            site == Site.TIKTOK && "/photo/" in m ->
                "This TikTok is a photo slideshow, not a video, so there is no video file to download."
            site == Site.TIKTOK && ("removed" in m || "unavailable" in m || "deleted" in m) ->
                "This TikTok video was removed or is not available in your region."
            site == Site.TIKTOK && "ip address is blocked" in m ->
                "TikTok blocked this connection. Switch between Wi-Fi and mobile data, then try again."
            site == Site.FACEBOOK && ("private" in m || "not available" in m || "unavailable" in m || "login" in m) ->
                "This Facebook video looks private, deleted, or only visible to friends. Only public videos can be downloaded."
            (site == Site.INSTAGRAM || site == Site.FACEBOOK || site == Site.TIKTOK) && blockedWithoutLogin(raw) ->
                "${site.label} did not allow this download. Private posts cannot be downloaded. If the post is public, wait a few minutes or switch between Wi-Fi and mobile data, then tap Retry in History."
            "403" in m && site == Site.YOUTUBE ->
                "Blocked by YouTube (403). Open HB Super App and tap \"Update yt-dlp\", then try again."
            "confirm" in m && "bot" in m ->
                "${site.label} wants to verify you are not a bot. Try again later or tap \"Update yt-dlp\"."
            "403" in m || "429" in m ->
                "${site.label} blocked the request. Tap \"Update yt-dlp\" in the app and try again."
            else -> raw
        }
    }

    private val videoExt = setOf("mp4", "webm", "mkv", "mov", "m4v", "3gp")
    private val imageExt = setOf("jpg", "jpeg", "png", "webp", "heic")
    private val audioExt = setOf("m4a", "mp3", "aac", "opus", "ogg", "wav")
    private val junk = Regex(".*\\.(part|ytdl|temp|tmp|json|vtt|srt|ass|description|txt)$", RegexOption.IGNORE_CASE)

    private fun mimeFor(ext: String): String = when (ext.lowercase()) {
        "mp4", "m4v" -> "video/mp4"
        "webm" -> "video/webm"
        "mkv" -> "video/x-matroska"
        "mov" -> "video/quicktime"
        "3gp" -> "video/3gpp"
        "jpg", "jpeg" -> "image/jpeg"
        "png" -> "image/png"
        "webp" -> "image/webp"
        "heic" -> "image/heic"
        "m4a" -> "audio/mp4"
        "mp3" -> "audio/mpeg"
        "aac" -> "audio/aac"
        "opus", "ogg" -> "audio/ogg"
        "wav" -> "audio/wav"
        else -> "video/mp4"
    }

    /** True if the file really contains a video picture (not just sound). */
    private fun hasVideoTrack(f: File): Boolean {
        val r = MediaMetadataRetriever()
        return try {
            r.setDataSource(f.absolutePath)
            r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_HAS_VIDEO) == "yes"
        } catch (_: Exception) {
            f.length() > 50_000 // cannot read details: trust a file of real size
        } finally {
            try { r.release() } catch (_: Exception) { }
        }
    }

    /** Real, finished, viewable files in the folder: videos with picture, photos (and audio for unknown sites). */
    private fun usableFiles(dir: File, site: Site, audio: Boolean = false): List<File> =
        (dir.listFiles() ?: emptyArray())
            .filter { it.isFile && it.length() > 0 && !junk.matches(it.name) }
            .filter {
                val ext = it.extension.lowercase()
                when {
                    audio -> ext in audioExt
                    ext in imageExt -> true
                    ext in videoExt -> hasVideoTrack(it)
                    ext in audioExt -> site == Site.OTHER
                    else -> false
                }
            }
            .sortedByDescending { it.length() }

    /** Where a finished file was saved, and whether a chosen folder had to be replaced by the default. */
    private class SaveOut(val uri: Uri, val where: String, val fallback: Boolean)

    private fun safeName(f: File): String = f.name.replace(Regex("[\\\\/:*?\"<>|\\r\\n]"), "_").trim()

    /**
     * Saves a finished file. If the user picked a folder (Settings > Save locations) it goes there,
     * otherwise into the default folders. YouTube videos go into a "YouTube" sub folder (can be switched off).
     * MP3 / audio always goes to the audio folder, separate from videos.
     */
    private fun saveFile(f: File, mime: String, site: Site): SaveOut {
        val isAudio = mime.startsWith("audio/")
        val sub = if (!isAudio && site == Site.YOUTUBE && Prefs.youtubeFolder(this)) "YouTube" else null
        val tree = if (isAudio) Prefs.audioTree(this) else Prefs.videoTree(this)
        var fallback = false
        if (tree != null) {
            try {
                val u = SaveStore.save(this, tree, sub, f, mime, safeName(f))
                val label = SaveStore.label(tree, "") + (if (sub != null) "/$sub" else "")
                return SaveOut(u, label, false)
            } catch (_: Exception) {
                fallback = true // folder gone or no access: use the default so the download is never lost
            }
        }
        val base = if (isAudio) Environment.DIRECTORY_MUSIC + "/HB AIO" else Environment.DIRECTORY_DCIM + "/HB AIO"
        val folder = if (sub != null) "$base/$sub" else base
        return SaveOut(saveToGallery(f, mime, folder), folder, fallback)
    }

    /** Saves through MediaStore into [folder] (e.g. DCIM/HB AIO/YouTube) with a proper "date taken". */
    private fun saveToGallery(f: File, mime: String, folder: String): Uri {
        val isAudio = mime.startsWith("audio/")
        val collection = when {
            mime.startsWith("image/") -> MediaStore.Images.Media.EXTERNAL_CONTENT_URI
            isAudio -> MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
            else -> MediaStore.Video.Media.EXTERNAL_CONTENT_URI
        }
        val now = System.currentTimeMillis()
        val fileName = safeName(f)
        val values = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, fileName)
            put(MediaStore.MediaColumns.MIME_TYPE, mime)
            put(MediaStore.MediaColumns.RELATIVE_PATH, folder)
            put(MediaStore.MediaColumns.DATE_ADDED, now / 1000)
            put(MediaStore.MediaColumns.DATE_MODIFIED, now / 1000)
            if (!isAudio) put(MediaStore.MediaColumns.DATE_TAKEN, now)
            put(MediaStore.MediaColumns.IS_PENDING, 1) // hidden until fully written
        }
        val uri = contentResolver.insert(collection, values)
            ?: throw Exception("Could not save to gallery")
        try {
            contentResolver.openOutputStream(uri)!!.use { out ->
                f.inputStream().use { it.copyTo(out) }
            }
            val done = ContentValues().apply {
                put(MediaStore.MediaColumns.IS_PENDING, 0)
                if (!isAudio) put(MediaStore.MediaColumns.DATE_TAKEN, now)
            }
            contentResolver.update(uri, done, null, null)
        } catch (e: Exception) {
            try { contentResolver.delete(uri, null, null) } catch (_: Exception) { }
            throw e
        }
        // Ask the system to index it right now, then make sure the date is "now" (the scan can reset it)
        try {
            contentResolver.query(uri, arrayOf(MediaStore.MediaColumns.DATA), null, null, null)?.use { c ->
                val path = if (c.moveToFirst()) c.getString(0) else null
                if (path != null) {
                    MediaScannerConnection.scanFile(this, arrayOf(path), arrayOf(mime)) { _, u ->
                        try {
                            if (u != null && !isAudio) {
                                contentResolver.update(
                                    u,
                                    ContentValues().apply { put(MediaStore.MediaColumns.DATE_TAKEN, now) },
                                    null, null
                                )
                            }
                        } catch (_: Exception) {
                        }
                    }
                }
            }
        } catch (_: Exception) {
        }
        return uri
    }

    private fun actionIntent(id: Int, action: String, n: Int): PendingIntent =
        PendingIntent.getService(
            this, id * 4 + n,
            Intent(this, DownloadService::class.java).setAction(action).putExtra(EXTRA_ID, id),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

    private fun notifyProgress(id: Int, text: String, pct: Int, indeterminate: Boolean) {
        DownloadTracker.progress(id, text, pct, indeterminate)
        val b = NotificationCompat.Builder(this, CH_PROGRESS)
            .setSmallIcon(R.drawable.ic_stat_hb)
            .setContentTitle("HB Super App")
            .setContentText(text)
            .setContentIntent(openAppIntent())
            .setProgress(100, pct, indeterminate)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
        val ctl = DownloadControl.get(id)
        if (ctl != null) {
            if (ctl.paused) b.addAction(0, "Resume", actionIntent(id, ACTION_RESUME, 1))
            else b.addAction(0, "Pause", actionIntent(id, ACTION_PAUSE, 0))
            b.addAction(0, "Cancel", actionIntent(id, ACTION_CANCEL, 2))
        }
        nm.notify(id, b.build())
    }

    private fun notifyDone(id: Int, uri: Uri, mime: String, name: String, where: String) {
        val view = Intent(Intent.ACTION_VIEW)
            .setDataAndType(uri, mime)
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        val pi = PendingIntent.getActivity(
            this, id, view, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val b = NotificationCompat.Builder(this, CH_DONE)
            .setSmallIcon(R.drawable.ic_stat_hb)
            .setContentTitle("Download complete")
            .setContentText(name)
            .setStyle(NotificationCompat.BigTextStyle().bigText("$name\nSaved in: $where"))
            .setContentIntent(pi)
            .setAutoCancel(true)
        // Share straight from the notification (WhatsApp, Telegram ...)
        val send = Intent(Intent.ACTION_SEND)
            .setType(mime)
            .putExtra(Intent.EXTRA_STREAM, uri)
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        b.addAction(
            0, "Share",
            PendingIntent.getActivity(
                this, 200000 + id, Intent.createChooser(send, "Share"),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
        )
        if (mime.startsWith("audio/")) {
            // MP3: one tap to use it as ringtone / notification / alarm
            val ring = Intent(this, RingtoneActivity::class.java)
                .putExtra(RingtoneActivity.EXTRA_URI, uri.toString())
                .putExtra(RingtoneActivity.EXTRA_TITLE, name)
            b.addAction(
                0, "Set as ringtone",
                PendingIntent.getActivity(
                    this, 100000 + id, ring, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
                )
            )
        }
        nm.notify(id, b.build())
    }

    private fun notifyError(id: Int, msg: String) {
        val n = NotificationCompat.Builder(this, CH_DONE)
            .setSmallIcon(R.drawable.ic_stat_hb)
            .setContentTitle("Download failed")
            .setContentText(msg)
            .setStyle(NotificationCompat.BigTextStyle().bigText(msg))
            .setContentIntent(openAppIntent())
            .setAutoCancel(true)
            .build()
        nm.notify(id, n)
    }
}
