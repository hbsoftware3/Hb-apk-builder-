package com.example.videodownloader

import android.content.ContentUris
import android.content.ContentValues
import android.content.Intent
import android.media.RingtoneManager
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.provider.OpenableColumns
import android.provider.Settings
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity

/**
 * Sets a downloaded MP3 as phone ringtone, notification sound or alarm.
 * Android asks once for "Modify system settings" - the screen opens by itself.
 * The MP3 is copied into the system Ringtones folder first, so it works wherever the file was saved.
 */
class RingtoneActivity : AppCompatActivity() {

    companion object {
        const val EXTRA_URI = "uri"
        const val EXTRA_TITLE = "title"
    }

    private var src: Uri? = null
    private var kind = -1
    private var wentToSettings = false
    private var working = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val u = intent?.getStringExtra(EXTRA_URI)
        if (u == null) {
            finish()
            return
        }
        src = Uri.parse(u)
        if (savedInstanceState != null) {
            kind = savedInstanceState.getInt("kind", -1)
            wentToSettings = savedInstanceState.getBoolean("settings", false)
        }
        if (kind < 0) askKind()
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        outState.putInt("kind", kind)
        outState.putBoolean("settings", wentToSettings)
    }

    override fun onResume() {
        super.onResume()
        if (wentToSettings && !working) {
            wentToSettings = false
            if (Settings.System.canWrite(this)) {
                apply(kind)
            } else {
                Toast.makeText(this, "Permission was not given, so the sound was not changed.", Toast.LENGTH_LONG).show()
                finish()
            }
        }
    }

    private fun askKind() {
        val title = intent?.getStringExtra(EXTRA_TITLE).orEmpty().ifBlank { "Set this sound as" }
        AlertDialog.Builder(this)
            .setTitle(title)
            .setItems(arrayOf("Phone ringtone", "Notification sound", "Alarm sound")) { _, which ->
                kind = which
                if (Settings.System.canWrite(this)) {
                    apply(which)
                } else {
                    Toast.makeText(
                        this, "Allow \"Modify system settings\" for this app, then come back.", Toast.LENGTH_LONG
                    ).show()
                    wentToSettings = true
                    try {
                        startActivity(
                            Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:$packageName"))
                        )
                    } catch (_: Exception) {
                        wentToSettings = false
                        Toast.makeText(this, "Cannot open the permission screen", Toast.LENGTH_LONG).show()
                        finish()
                    }
                }
            }
            .setOnCancelListener { finish() }
            .show()
    }

    private fun apply(which: Int) {
        if (working) return
        working = true
        Thread {
            val msg = try {
                set(which)
            } catch (e: Exception) {
                "Could not set the sound: ${e.message}"
            }
            runOnUiThread {
                Toast.makeText(this, msg, Toast.LENGTH_LONG).show()
                finish()
            }
        }.start()
    }

    private fun displayName(uri: Uri): String? = try {
        contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)
            ?.use { if (it.moveToFirst()) it.getString(0) else null }
    } catch (_: Exception) {
        null
    }

    private fun findExisting(rel: String, name: String): Uri? {
        val base = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
        return try {
            contentResolver.query(
                base,
                arrayOf(MediaStore.MediaColumns._ID),
                "${MediaStore.MediaColumns.DISPLAY_NAME}=? AND ${MediaStore.MediaColumns.RELATIVE_PATH} LIKE ?",
                arrayOf(name, "$rel%"),
                null
            )?.use { if (it.moveToFirst()) ContentUris.withAppendedId(base, it.getLong(0)) else null }
        } catch (_: Exception) {
            null
        }
    }

    /** Returns the message to show. */
    private fun set(which: Int): String {
        val source = src ?: throw Exception("No file")
        val (type, dir, what) = when (which) {
            0 -> Triple(RingtoneManager.TYPE_RINGTONE, Environment.DIRECTORY_RINGTONES, "Phone ringtone")
            1 -> Triple(RingtoneManager.TYPE_NOTIFICATION, Environment.DIRECTORY_NOTIFICATIONS, "Notification sound")
            else -> Triple(RingtoneManager.TYPE_ALARM, Environment.DIRECTORY_ALARMS, "Alarm sound")
        }
        val name = displayName(source) ?: "HB_AIO_${System.currentTimeMillis()}.mp3"
        val mime = contentResolver.getType(source)?.takeIf { it.startsWith("audio/") } ?: "audio/mpeg"
        val rel = "$dir/HB AIO"

        var target = findExisting(rel, name)
        if (target == null) {
            val values = ContentValues().apply {
                put(MediaStore.MediaColumns.DISPLAY_NAME, name)
                put(MediaStore.MediaColumns.MIME_TYPE, mime)
                put(MediaStore.MediaColumns.RELATIVE_PATH, rel)
                put(MediaStore.Audio.Media.TITLE, name.substringBeforeLast('.'))
                put(MediaStore.Audio.Media.IS_RINGTONE, if (which == 0) 1 else 0)
                put(MediaStore.Audio.Media.IS_NOTIFICATION, if (which == 1) 1 else 0)
                put(MediaStore.Audio.Media.IS_ALARM, if (which == 2) 1 else 0)
                put(MediaStore.Audio.Media.IS_MUSIC, 0)
                put(MediaStore.MediaColumns.IS_PENDING, 1)
            }
            val out = contentResolver.insert(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, values)
                ?: throw Exception("Could not create the sound file")
            try {
                contentResolver.openInputStream(source)!!.use { input ->
                    contentResolver.openOutputStream(out)!!.use { o -> input.copyTo(o, 128 * 1024) }
                }
                contentResolver.update(
                    out, ContentValues().apply { put(MediaStore.MediaColumns.IS_PENDING, 0) }, null, null
                )
            } catch (e: Exception) {
                try { contentResolver.delete(out, null, null) } catch (_: Exception) { }
                throw e
            }
            target = out
        }
        val finalUri: Uri = target ?: throw Exception("No sound file")
        RingtoneManager.setActualDefaultRingtoneUri(this, type, finalUri)
        return "$what changed to: ${name.substringBeforeLast('.')}"
    }
}
