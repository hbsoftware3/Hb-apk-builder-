package com.example.videodownloader.tools

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.ImageDecoder
import android.graphics.Matrix
import android.graphics.drawable.Drawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.view.GestureDetector
import android.view.Gravity
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.widget.AppCompatImageView
import androidx.lifecycle.lifecycleScope
import com.example.videodownloader.R
import com.example.videodownloader.ui.BaseActivity
import com.example.videodownloader.ui.Hb
import com.example.videodownloader.util.Fmt
import com.example.videodownloader.util.Launcher
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/** Full-screen image viewer with pinch-to-zoom, pan and double-tap zoom. */
class ImageViewerActivity : BaseActivity() {

    private lateinit var zoom: ZoomableImageView
    private lateinit var title: TextView
    private lateinit var info: TextView
    private var imageUri: Uri? = null

    private val pick = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        uri ?: return@registerForActivityResult
        load(uri)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = FrameLayout(this).apply { setBackgroundColor(android.graphics.Color.BLACK) }

        zoom = ZoomableImageView(this).apply {
            layoutParams = FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
            scaleType = android.widget.ImageView.ScaleType.MATRIX
        }
        root.addView(zoom)

        val top = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(Hb.dp(this@ImageViewerActivity, 10), Hb.dp(this@ImageViewerActivity, 8),
                Hb.dp(this@ImageViewerActivity, 10), Hb.dp(this@ImageViewerActivity, 8))
            setBackgroundColor(0x99000000.toInt())
        }
        top.addView(Hb.iconButton(this, R.drawable.ic_back, android.graphics.Color.WHITE, 40) { finish() })
        title = Hb.text(this, "Image", 15f, android.graphics.Color.WHITE, medium = true).apply {
            setPadding(Hb.dp(this@ImageViewerActivity, 10), 0, 0, 0)
            maxLines = 1
            ellipsize = android.text.TextUtils.TruncateAt.MIDDLE
        }
        top.addView(title, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        top.addView(Hb.iconButton(this, R.drawable.ic_share, android.graphics.Color.WHITE, 40) { share() })
        top.addView(Hb.iconButton(this, R.drawable.ic_more, android.graphics.Color.WHITE, 40) { menu() }.apply {
            (layoutParams as LinearLayout.LayoutParams).marginStart = Hb.dp(this@ImageViewerActivity, 6)
        })
        root.addView(top, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.TOP))

        info = Hb.text(this, "", 11f, 0xCCFFFFFF.toInt()).apply {
            gravity = Gravity.CENTER
            setPadding(Hb.dp(this@ImageViewerActivity, 12), Hb.dp(this@ImageViewerActivity, 6),
                Hb.dp(this@ImageViewerActivity, 12), Hb.dp(this@ImageViewerActivity, 10))
            setBackgroundColor(0x66000000)
        }
        root.addView(info, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM))

        setContentView(root)
        val uri = intent?.data
        if (uri != null) load(uri)
        else {
            title.text = "Image Viewer"
            info.text = "Choose an image to begin"
            pick.launch(arrayOf("image/*"))
        }
    }

    private fun load(uri: Uri) {
        imageUri = uri
        title.text = Fmt.name(this, uri)
        info.text = "Loading…"
        lifecycleScope.launch {
            val bitmap = withContext(Dispatchers.IO) { decode(uri) }
            if (bitmap == null) {
                info.text = "This image could not be opened"
                Hb.alert(this@ImageViewerActivity, "Image", "The file may be damaged or in a format this phone cannot decode.")
                return@launch
            }
            zoom.setBitmap(bitmap)
            info.text = "${bitmap.width} × ${bitmap.height} • ${Fmt.bytes(Fmt.size(this@ImageViewerActivity, uri))}"
        }
    }

    private fun decode(uri: Uri): Bitmap? = try {
        if (Build.VERSION.SDK_INT >= 28) {
            val source = ImageDecoder.createSource(contentResolver, uri)
            ImageDecoder.decodeBitmap(source) { decoder, infoData, _ ->
                decoder.allocator = ImageDecoder.ALLOCATOR_SOFTWARE
                val maxSide = 4096
                if (infoData.size.width > maxSide || infoData.size.height > maxSide) {
                    val scale = maxSide.toFloat() / maxOf(infoData.size.width, infoData.size.height).toFloat()
                    decoder.setTargetSize((infoData.size.width * scale).toInt(), (infoData.size.height * scale).toInt())
                }
            }
        } else {
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
            var sample = 1
            while (bounds.outWidth / sample > 4096 || bounds.outHeight / sample > 4096) sample *= 2
            contentResolver.openInputStream(uri)?.use {
                BitmapFactory.decodeStream(it, null, BitmapFactory.Options().apply { inSampleSize = sample })
            }
        }
    } catch (_: Exception) {
        null
    }

    private fun share() {
        val uri = imageUri ?: return
        Launcher.shareFile(this, uri, Fmt.mime(this, uri))
    }

    private fun menu() {
        val actions = arrayListOf("Share", "Open with another app", "Choose another image")
        androidx.appcompat.app.AlertDialog.Builder(this, R.style.HbDialog)
            .setItems(actions.toTypedArray()) { _, which ->
                when (which) {
                    0 -> share()
                    1 -> imageUri?.let { Launcher.openWith(this, it, Fmt.mime(this, it)) }
                    else -> pick.launch(arrayOf("image/*"))
                }
            }
            .show()
    }

    /** Matrix-based zoom view: pinch, pan and double-tap. Keeps the image inside the view. */
    @SuppressLint("ClickableViewAccessibility")
    private class ZoomableImageView(context: Context) : AppCompatImageView(context) {
        private val base = Matrix()
        private val current = Matrix()
        private var minScale = 1f
        private var maxScale = 4f
        private var lastX = 0f
        private var lastY = 0f
        private var bitmap: Bitmap? = null

        private val scaleDetector = ScaleGestureDetector(context, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
            override fun onScale(detector: ScaleGestureDetector): Boolean {
                val values = FloatArray(9)
                current.getValues(values)
                val currentScale = values[Matrix.MSCALE_X]
                val target = (currentScale * detector.scaleFactor).coerceIn(minScale, maxScale)
                val factor = target / currentScale
                current.postScale(factor, factor, detector.focusX, detector.focusY)
                imageMatrix = current
                return true
            }
        })

        private val gestures = GestureDetector(context, object : GestureDetector.SimpleOnGestureListener() {
            override fun onDown(e: MotionEvent): Boolean = true

            override fun onScroll(e1: MotionEvent?, e2: MotionEvent, dx: Float, dy: Float): Boolean {
                current.postTranslate(-dx, -dy)
                imageMatrix = current
                return true
            }

            override fun onDoubleTap(e: MotionEvent): Boolean {
                val values = FloatArray(9)
                current.getValues(values)
                val scale = values[Matrix.MSCALE_X]
                if (scale > minScale * 1.4f) {
                    current.set(base)
                } else {
                    current.postScale(2.2f, 2.2f, e.x, e.y)
                }
                imageMatrix = current
                return true
            }
        })

        fun setBitmap(bmp: Bitmap) {
            bitmap?.recycle()
            bitmap = bmp
            setImageBitmap(bmp)
            if (width > 0) fit() else post { fit() }
        }

        private fun fit() {
            val bmp = bitmap ?: return
            if (width == 0 || height == 0) return
            val scale = minOf(width.toFloat() / bmp.width, height.toFloat() / bmp.height)
            val dx = (width - bmp.width * scale) / 2f
            val dy = (height - bmp.height * scale) / 2f
            base.reset()
            base.postScale(scale, scale)
            base.postTranslate(dx, dy)
            current.set(base)
            minScale = scale
            maxScale = scale * 4f
            imageMatrix = current
        }

        override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
            super.onSizeChanged(w, h, oldw, oldh)
            fit()
        }

        override fun onDetachedFromWindow() {
            bitmap?.recycle()
            bitmap = null
            super.onDetachedFromWindow()
        }

        @SuppressLint("ClickableViewAccessibility")
        override fun onTouchEvent(event: MotionEvent): Boolean {
            scaleDetector.onTouchEvent(event)
            gestures.onTouchEvent(event)
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    lastX = event.x
                    lastY = event.y
                    parent?.requestDisallowInterceptTouchEvent(true)
                }
                MotionEvent.ACTION_MOVE -> {
                    if (!scaleDetector.isInProgress) {
                        val dx = event.x - lastX
                        val dy = event.y - lastY
                        current.postTranslate(dx, dy)
                        imageMatrix = current
                    }
                    lastX = event.x
                    lastY = event.y
                }
            }
            return true
        }
    }
}
