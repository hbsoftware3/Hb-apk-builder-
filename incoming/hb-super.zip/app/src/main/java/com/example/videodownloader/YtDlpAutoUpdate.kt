package com.example.videodownloader

import android.app.Application
import com.yausername.youtubedl_android.YoutubeDL

/**
 * Keeps yt-dlp up to date without the user doing anything. Websites change all the time and an old
 * yt-dlp is the most common reason a download fails. Runs at most once every 3 days, never while a
 * download is running, and stays silent if it fails (it simply tries again the next time the app opens).
 */
object YtDlpAutoUpdate {
    private const val EVERY_MS = 3L * 24 * 60 * 60 * 1000

    @Volatile
    private var running = false

    /** Call from a background thread. */
    fun runIfDue(app: Application) {
        if (running) return
        if (DownloadTracker.items.value.isNotEmpty()) return
        val now = System.currentTimeMillis()
        if (now - Prefs.lastYtdlpUpdate(app) < EVERY_MS) return
        running = true
        try {
            // YtDlpGate: runs only if no yt-dlp command is running, and a download that starts
            // meanwhile waits until the update is done (so it never meets a half-replaced yt-dlp)
            val ran = YtDlpGate.updateWhenIdle {
                YoutubeDL.getInstance().init(app)
                YoutubeDL.getInstance().updateYoutubeDL(app, YoutubeDL.UpdateChannel.NIGHTLY)
            }
            if (ran) Prefs.setLastYtdlpUpdate(app, now)
        } catch (_: Exception) {
            // no internet or server busy: try again next time
        } finally {
            running = false
        }
    }
}
