package com.example.videodownloader

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.core.content.ContextCompat

/** Invisible activity: takes the shared link(s), starts the background service, and closes. */
class ShareActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Updater.blockIfForced(this)) return // forced update pending: open the app instead
        val text = intent?.getStringExtra(Intent.EXTRA_TEXT).orEmpty()
        val urls = Regex("https?://\\S+").findAll(text).map { it.value }.distinct().take(10).toList()
        val audio = Prefs.audioDefault(this)
        if (urls.isEmpty()) {
            Toast.makeText(this, "No link found", Toast.LENGTH_SHORT).show()
        } else {
            val fresh = urls.filter { !DownloadTracker.isActive(it, audio) }
            if (fresh.isEmpty()) {
                Toast.makeText(this, "Already downloading this link", Toast.LENGTH_SHORT).show()
            } else {
                fresh.forEach { u ->
                    ContextCompat.startForegroundService(
                        this,
                        Intent(this, DownloadService::class.java)
                            .putExtra(DownloadService.EXTRA_URL, u)
                            .putExtra(DownloadService.EXTRA_AUDIO, audio)
                    )
                }
                Toast.makeText(
                    this,
                    when {
                        fresh.size > 1 -> "${fresh.size} downloads started in background"
                        audio -> "Audio download started in background"
                        else -> "Download started in background"
                    },
                    Toast.LENGTH_SHORT
                ).show()
            }
        }
        finish()
    }
}
