package com.example.videodownloader.util

import androidx.annotation.DrawableRes
import com.example.videodownloader.R

enum class Tool(
    val id: String,
    val title: String,
    val subtitle: String,
    @DrawableRes val icon: Int,
    val category: String
) {
    PLAYER("player", "Media Player", "Videos, music and playlists", R.drawable.ic_play, "Media"),
    FILES("files", "File Manager", "Browse, zip and organize files", R.drawable.ic_folder, "Media"),
    CONVERTER("converter", "Converter Studio", "MP3, trim, compress, PDF", R.drawable.ic_convert, "Media"),
    QR_SCAN("qr_scan", "QR Scanner", "Scan codes with the camera", R.drawable.ic_qr, "Utilities"),
    QR_CREATE("qr_create", "QR Generator", "Create and share QR codes", R.drawable.ic_grid, "Utilities"),
    PDF("pdf", "PDF Viewer", "Read PDFs completely offline", R.drawable.ic_pdf, "Utilities"),
    IMAGE("image", "Image Viewer", "Zoom and share photos", R.drawable.ic_image, "Utilities"),
    RINGTONE("ringtone", "Ringtone Maker", "Set any MP3 as a ringtone", R.drawable.ic_ringtone, "Utilities"),
    CLIPBOARD("clipboard", "Clipboard Tool", "Detect and open links", R.drawable.ic_clipboard, "Utilities"),
    STORAGE("storage", "Storage Analyzer", "See what is using your space", R.drawable.ic_storage, "Utilities"),
    SEARCH("search", "File Search", "Find files instantly", R.drawable.ic_search, "Utilities"),
    TEXT("text", "Text Tools", "Count, convert and clean text", R.drawable.ic_text, "Utilities"),
    STATUS("status", "Status Saver", "Save WhatsApp statuses", R.drawable.ic_download, "Social"),
    BROWSER("browser", "HB Browser", "Private browsing built in", R.drawable.ic_browser, "Web")
    ;

    companion object {
        fun from(id: String?): Tool? = entries.firstOrNull { it.id == id }
    }
}
