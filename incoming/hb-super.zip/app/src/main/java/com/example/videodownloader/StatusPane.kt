package com.example.videodownloader

import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.net.Uri
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * Status saver panel: WhatsApp / WhatsApp Business statuses + the ones already saved on the phone.
 * Each status has a download arrow (saves it on the phone); tapping the picture plays it inside the app.
 */
class StatusPane(
    private val act: AppCompatActivity,
    private val box: LinearLayout,
    /** Opens Android's folder picker. legacy = point it at the old folder location. */
    private val askAccess: (WaApp, Boolean) -> Unit,
    /** Asks for "All files access" so the statuses can be read directly (best way). */
    private val askDirect: () -> Unit
) {
    private companion object {
        const val TAG_SAVED = "saved"
    }

    private var current = WaApp.WHATSAPP
    private var savedMode = false
    private var job: Job? = null
    private var items: List<StatusItem> = emptyList()
    private var expanded = false

    private lateinit var info: TextView
    private lateinit var actions: LinearLayout
    private lateinit var grid: LinearLayout
    private var btnSaveAll: Button? = null

    private fun dp(v: Int) = (v * act.resources.displayMetrics.density).toInt()

    private fun styledButton(label: String, primary: Boolean = false): Button = Button(act).apply {
        text = label
        isAllCaps = false
        textSize = 13f
        setTextColor(Color.WHITE)
        background = ContextCompat.getDrawable(
            act, if (primary) R.drawable.bg_btn_primary else R.drawable.bg_btn_secondary
        )
        minHeight = 0
        minimumHeight = 0
        setPadding(dp(16), 0, dp(16), 0)
    }

    fun build() {
        box.removeAllViews()

        val card = LinearLayout(act).apply {
            orientation = LinearLayout.VERTICAL
            background = ContextCompat.getDrawable(act, R.drawable.bg_card)
            setPadding(dp(14), dp(14), dp(14), dp(14))
        }
        card.addView(TextView(act).apply {
            text = "Status saver"
            setTextColor(Color.WHITE)
            textSize = 15f
            typeface = android.graphics.Typeface.DEFAULT_BOLD
        })

        // Chooser: WhatsApp | WhatsApp Business | Saved
        val group = RadioGroup(act).apply { orientation = RadioGroup.HORIZONTAL }
        val choices: List<Pair<String, Any>> =
            WaApp.values().map { (if (it == WaApp.BUSINESS) "Business" else it.label) to (it as Any) } +
                ("Saved" to (TAG_SAVED as Any))
        choices.forEachIndexed { i, (label, choiceTag) ->
            val rb = RadioButton(act).apply {
                id = View.generateViewId()
                text = label
                setTextColor(ContextCompat.getColorStateList(act, R.color.chip_text))
                background = ContextCompat.getDrawable(act, R.drawable.bg_chip)
                buttonDrawable = null
                gravity = Gravity.CENTER
                textSize = 13f
                tag = choiceTag
            }
            group.addView(
                rb,
                LinearLayout.LayoutParams(0, dp(40), 1f).apply { if (i < choices.size - 1) marginEnd = dp(6) }
            )
        }
        card.addView(
            group,
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
                .apply { topMargin = dp(10) }
        )
        // Start on the app that already has access (so the statuses show right away)
        current = WaApp.values().firstOrNull { Prefs.statusTree(act, it.key) != null } ?: WaApp.WHATSAPP
        group.check(group.getChildAt(current.ordinal).id)
        group.setOnCheckedChangeListener { g, checkedId ->
            val tag = g.findViewById<View>(checkedId)?.tag
            if (tag == TAG_SAVED) {
                savedMode = true
            } else {
                savedMode = false
                current = tag as? WaApp ?: return@setOnCheckedChangeListener
            }
            expanded = false
            refresh()
        }

        info = TextView(act).apply {
            setTextColor(0xFF8A93A0.toInt())
            textSize = 12f
        }
        card.addView(
            info,
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
                .apply { topMargin = dp(10) }
        )

        actions = LinearLayout(act).apply { orientation = LinearLayout.VERTICAL }
        card.addView(
            actions,
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
                .apply { topMargin = dp(10) }
        )
        box.addView(card)

        grid = LinearLayout(act).apply { orientation = LinearLayout.VERTICAL }
        box.addView(
            grid,
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
                .apply { topMargin = dp(12) }
        )
        refresh()
    }

    /** Buttons are placed two per row, so long labels never run off the screen. */
    private fun setActions(vararg views: Button) {
        actions.removeAllViews()
        views.toList().chunked(2).forEachIndexed { r, pair ->
            val row = LinearLayout(act).apply { orientation = LinearLayout.HORIZONTAL }
            pair.forEachIndexed { i, b ->
                row.addView(
                    b,
                    LinearLayout.LayoutParams(0, dp(40), 1f).apply { if (i < pair.size - 1) marginEnd = dp(8) }
                )
            }
            actions.addView(
                row,
                LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
                    .apply { if (r > 0) topMargin = dp(8) }
            )
        }
    }

    private fun showAccessNeeded(app: WaApp, note: String? = null) {
        grid.removeAllViews()
        items = emptyList()
        val direct = StatusRepo.hasDirectAccess(act)
        info.text = (note?.let { "$it\n\n" } ?: "") +
            if (!direct)
                "To show ${app.label} statuses, tap \"Allow file access\" and switch it ON for this app, then come back. " +
                    "This is the easiest way and works on all phones.\n\n" +
                    "Or use \"Pick folder\": choose the Media folder of ${app.label}, then tap \"Use this folder\" and \"Allow\"."
            else
                "File access is ON, but no status was found for ${app.label}. Open ${app.label}, look at its Status tab " +
                    "(the statuses must be loaded once), then tap Refresh. " +
                    "If it still shows nothing, use \"Pick folder\" and choose the Media folder."
        val btnRefresh = styledButton("Refresh").apply { setOnClickListener { refresh() } }
        val btnPick = styledButton("Pick folder").apply { setOnClickListener { askAccess(app, false) } }
        val btnOld = styledButton("Old folder").apply { setOnClickListener { askAccess(app, true) } }
        if (!direct) {
            val btnAllow = styledButton("Allow file access", true).apply { setOnClickListener { askDirect() } }
            setActions(btnAllow, btnPick, btnOld, btnRefresh)
        } else {
            setActions(btnRefresh, btnPick, btnOld)
        }
    }

    private fun showMessage(text: String) {
        grid.removeAllViews()
        items = emptyList()
        info.text = text
        setActions(styledButton("Refresh").apply { setOnClickListener { refresh() } })
    }

    /** Reloads the list for the chosen chip. Call when the screen is shown. */
    fun refresh() {
        job?.cancel()
        if (savedMode) {
            info.text = "Loading saved statuses..."
            job = act.lifecycleScope.launch {
                val list = withContext(Dispatchers.IO) { StatusRepo.listSaved(act) }
                if (!savedMode) return@launch
                if (list.isEmpty()) showMessage("Nothing saved yet. Open WhatsApp or Business and tap the download arrow on a status.")
                else showGrid(null, list)
            }
            return
        }

        val app = current
        info.text = "Loading ${app.label} statuses..."
        job = act.lifecycleScope.launch {
            // 1) Direct reading (needs "All files access"): no folder picker, no hidden-folder problems
            val direct = withContext(Dispatchers.IO) {
                if (StatusRepo.hasDirectAccess(act)) StatusRepo.listDirect(app) else null
            }
            if (savedMode || current != app) return@launch // user switched meanwhile
            if (direct != null) {
                if (direct.isEmpty()) {
                    showMessage("No statuses yet. ${app.label} puts a status in this folder only after it has loaded it. Open ${app.label}'s status tab, then tap Refresh.")
                } else {
                    showGrid(app, direct)
                }
                return@launch
            }

            // 2) The folder the user picked once with Android's folder picker
            val tree = Prefs.statusTree(act, app.key)
            if (tree == null) {
                showAccessNeeded(app)
                return@launch
            }
            val list = withContext(Dispatchers.IO) { StatusRepo.list(act, Uri.parse(tree)) }
            if (savedMode || current != app) return@launch
            when {
                list == null -> {
                    val treeUri = Uri.parse(tree)
                    val hasPerm = act.contentResolver.persistedUriPermissions.any { it.uri == treeUri && it.isReadPermission }
                    if (!hasPerm) Prefs.setStatusTree(act, app.key, null)
                    showAccessNeeded(
                        app,
                        if (hasPerm) "Access is fine, but the .Statuses folder was not found inside the folder you picked. Tap \"Pick folder\" again and choose the Media folder (or tap \"Old folder\")."
                        else "Access was lost. Please allow it again."
                    )
                }
                list.isEmpty() ->
                    showMessage("No statuses yet. ${app.label} puts a status in this folder only after it has loaded it. Open ${app.label}'s status tab, then tap Refresh.")
                else -> showGrid(app, list)
            }
        }
    }

    /** Called after the user picked a folder in Android's picker. */
    fun onAccessResult(app: WaApp, uri: Uri) {
        try {
            act.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
        } catch (_: Exception) {
        }
        act.lifecycleScope.launch {
            val ok = withContext(Dispatchers.IO) { StatusRepo.findStatusDir(act, uri) != null }
            if (ok) {
                Prefs.setStatusTree(act, app.key, uri.toString())
                current = app
                refresh()
            } else {
                Toast.makeText(
                    act,
                    "Status folder not found in that folder. Pick the Media folder of ${app.label}.",
                    Toast.LENGTH_LONG
                ).show()
            }
        }
    }

    /** app == null means the "Saved" list (statuses kept on the phone). */
    private fun showGrid(app: WaApp?, list: List<StatusItem>) {
        items = list
        val photos = list.count { !it.isVideo }
        val videos = list.size - photos
        if (app == null) {
            info.text = "${list.size} saved on your phone ($photos photos, $videos videos). Tap one to play it, tap the bin to delete."
            setActions(styledButton("Refresh").apply { setOnClickListener { refresh() } })
            btnSaveAll = null
        } else {
            info.text = "${app.label}: $photos photos, $videos videos. Tap a status to play it, tap the arrow to save it on your phone."
            val all = styledButton("Save all", true).apply { setOnClickListener { saveAll() } }
            btnSaveAll = all
            setActions(all, styledButton("Refresh").apply { setOnClickListener { refresh() } })
        }

        grid.removeAllViews()
        val gap = dp(6)
        val screenW = act.resources.displayMetrics.widthPixels
        val cell = (screenW - dp(18) * 2 - gap * 2) / 3
        // Only the 6 newest at first, so the rest of the app stays close; "Show all" opens the rest
        val limit = 6
        val shown = if (expanded || list.size <= limit) list else list.take(limit)
        shown.chunked(3).forEachIndexed { r, rowItems ->
            val row = LinearLayout(act).apply { orientation = LinearLayout.HORIZONTAL }
            rowItems.forEachIndexed { i, item ->
                row.addView(
                    makeCell(item, list.indexOf(item), cell, app == null),
                    LinearLayout.LayoutParams(cell, cell).apply {
                        if (i < 2) marginEnd = gap
                        bottomMargin = gap
                    }
                )
            }
            grid.addView(row)
        }
        if (list.size > limit) {
            val more = styledButton(if (expanded) "Show less" else "Show all ${list.size}").apply {
                setOnClickListener {
                    expanded = !expanded
                    showGrid(app, list)
                }
            }
            grid.addView(more, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(42)))
        }
    }

    private fun circleButton(iconRes: Int): ImageView = ImageView(act).apply {
        setImageResource(iconRes)
        background = ContextCompat.getDrawable(act, R.drawable.bg_circle)
        setPadding(dp(8), dp(8), dp(8), dp(8))
        elevation = dp(2).toFloat()
    }

    private fun makeCell(item: StatusItem, position: Int, size: Int, isSavedList: Boolean): View {
        val frame = FrameLayout(act).apply { background = ColorDrawable(0xFF0A0F18.toInt()) }

        // Picture: tap = play inside the app
        val img = ImageView(act).apply {
            scaleType = ImageView.ScaleType.CENTER_CROP
            setOnClickListener { openViewer(position, isSavedList) }
        }
        frame.addView(img, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        act.lifecycleScope.launch {
            val bmp = withContext(Dispatchers.IO) { Thumbs.get(act, item, size) }
            if (bmp != null) img.setImageBitmap(bmp)
        }

        // Play sign on videos
        if (item.isVideo) {
            val play = circleButton(R.drawable.ic_play).apply { isClickable = false }
            frame.addView(play, FrameLayout.LayoutParams(dp(40), dp(40), Gravity.CENTER))
        }

        // Round button in the corner: download arrow (save) / check (already saved) / bin (delete in Saved list)
        val corner = circleButton(R.drawable.ic_download)
        fun paint() {
            when {
                isSavedList -> corner.setImageResource(R.drawable.ic_delete)
                Prefs.isStatusSaved(act, item.name) -> {
                    corner.setImageResource(R.drawable.ic_check)
                    corner.isEnabled = false
                }
                else -> {
                    corner.setImageResource(R.drawable.ic_download)
                    corner.isEnabled = true
                }
            }
        }
        paint()
        corner.setOnClickListener {
            corner.alpha = 0.4f
            act.lifecycleScope.launch {
                if (isSavedList) {
                    val ok = withContext(Dispatchers.IO) { StatusRepo.deleteSaved(act, item) }
                    Toast.makeText(act, if (ok) "Deleted" else "Could not delete", Toast.LENGTH_SHORT).show()
                    if (ok) refresh() else corner.alpha = 1f
                } else {
                    val ok = withContext(Dispatchers.IO) { StatusRepo.save(act, item) }
                    Toast.makeText(act, if (ok) "Saved on your phone" else "Could not save", Toast.LENGTH_SHORT).show()
                    corner.alpha = 1f
                    paint()
                }
            }
        }
        frame.addView(corner, FrameLayout.LayoutParams(dp(38), dp(38), Gravity.BOTTOM or Gravity.END).apply {
            marginEnd = dp(6)
            bottomMargin = dp(6)
        })
        return frame
    }

    private fun saveAll() {
        val todo = items.filter { !Prefs.isStatusSaved(act, it.name) }
        if (todo.isEmpty()) {
            Toast.makeText(act, "Everything here is already saved", Toast.LENGTH_SHORT).show()
            return
        }
        btnSaveAll?.isEnabled = false
        btnSaveAll?.text = "Saving..."
        act.lifecycleScope.launch {
            val saved = withContext(Dispatchers.IO) { todo.count { StatusRepo.save(act, it) } }
            Toast.makeText(act, "Saved $saved of ${todo.size}", Toast.LENGTH_LONG).show()
            refresh() // repaints every arrow as a check
        }
    }

    /** Plays the status inside the app. Swipe left/right to go to the next one. */
    private fun openViewer(position: Int, fromSaved: Boolean) {
        act.startActivity(
            Intent(act, StatusViewerActivity::class.java)
                .putStringArrayListExtra(StatusViewerActivity.EXTRA_URIS, ArrayList(items.map { it.uri.toString() }))
                .putStringArrayListExtra(StatusViewerActivity.EXTRA_MIMES, ArrayList(items.map { it.mime }))
                .putStringArrayListExtra(StatusViewerActivity.EXTRA_NAMES, ArrayList(items.map { it.name }))
                .putExtra(StatusViewerActivity.EXTRA_INDEX, position)
                .putExtra(StatusViewerActivity.EXTRA_SAVED, fromSaved)
        )
    }
}
