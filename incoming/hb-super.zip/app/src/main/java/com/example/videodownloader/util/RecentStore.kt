package com.example.videodownloader.util

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

data class RecentMedia(
    val uri: String,
    val name: String,
    val mime: String,
    val at: Long,
    val durationMs: Long,
    val positionMs: Long
)

object RecentStore {
    private const val KEY = "player_recent"
    private const val MAX = 30

    private fun prefs(c: Context) = c.getSharedPreferences("hb_player", Context.MODE_PRIVATE)

    fun all(c: Context): List<RecentMedia> {
        val raw = prefs(c).getString(KEY, null) ?: return emptyList()
        return try {
            val arr = JSONArray(raw)
            (0 until arr.length()).map { i ->
                val o = arr.getJSONObject(i)
                RecentMedia(
                    o.getString("uri"), o.optString("name", "Media"),
                    o.optString("mime", "*/*"), o.optLong("at", 0L),
                    o.optLong("duration", 0L), o.optLong("position", 0L)
                )
            }
        } catch (_: Exception) {
            emptyList()
        }
    }

    fun add(c: Context, item: RecentMedia) {
        val list = (listOf(item) + all(c).filter { it.uri != item.uri }).take(MAX)
        write(c, list)
    }

    fun setPosition(c: Context, uri: String, position: Long) {
        val list = all(c).map { if (it.uri == uri) it.copy(positionMs = position) else it }
        write(c, list)
    }

    fun position(c: Context, uri: String): Long = all(c).firstOrNull { it.uri == uri }?.positionMs ?: 0L

    fun clear(c: Context) {
        prefs(c).edit().remove(KEY).apply()
    }

    private fun write(c: Context, list: List<RecentMedia>) {
        val arr = JSONArray()
        list.forEach {
            arr.put(JSONObject().apply {
                put("uri", it.uri); put("name", it.name); put("mime", it.mime)
                put("at", it.at); put("duration", it.durationMs); put("position", it.positionMs)
            })
        }
        prefs(c).edit().putString(KEY, arr.toString()).apply()
    }
}
