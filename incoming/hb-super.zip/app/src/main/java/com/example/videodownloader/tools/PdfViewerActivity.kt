package com.example.videodownloader.tools

import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.pdf.PdfRenderer
import android.net.Uri
import android.os.Bundle
import android.os.ParcelFileDescriptor
import android.util.LruCache
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.videodownloader.R
import com.example.videodownloader.ui.BaseActivity
import com.example.videodownloader.ui.Hb
import com.example.videodownloader.util.Fmt
import com.example.videodownloader.util.Launcher
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/** Offline PDF reader. Pages are rendered on demand with Android's PdfRenderer; nothing is uploaded. */
class PdfViewerActivity : BaseActivity() {

    private var pfd: ParcelFileDescriptor? = null
    private var renderer: PdfRenderer? = null
    private var uri: Uri? = null
    private val renderLock = Any()
    private lateinit var list: RecyclerView
    private lateinit var empty: LinearLayout
    private lateinit var pageLabel: TextView
    private val cache = object : LruCache<Int, Bitmap>(48 * 1024 * 1024) {
        override fun sizeOf(key: Int, value: Bitmap): Int = value.byteCount
    }

    private val pick = registerForActivityResult(ActivityResultContracts.OpenDocument()) { picked ->
        picked ?: return@registerForActivityResult
        open(picked)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val p = Hb.palette(this)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(p.bg)
        }
        root.addView(Hb.topBar(this, "PDF Viewer", "Offline reader",
            { finish() },
            listOf(R.drawable.ic_share to { uri?.let { Launcher.shareFile(this, it, "application/pdf") } })))

        empty = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(Hb.dp(this@PdfViewerActivity, 20), Hb.dp(this@PdfViewerActivity, 40), Hb.dp(this@PdfViewerActivity, 20), 0)
        }
        empty.addView(Hb.iconCircle(this, R.drawable.ic_pdf, p.blue, p.blueSoft, 64))
        empty.addView(Hb.text(this, "Read a PDF", 17f, p.text, bold = true).apply {
            gravity = Gravity.CENTER
            setPadding(0, Hb.dp(this@PdfViewerActivity, 12), 0, 0)
        })
        empty.addView(Hb.text(this, "Pages are rendered on the phone. Password-protected PDFs are not supported.", 11.5f, p.muted).apply {
            gravity = Gravity.CENTER
            setPadding(0, Hb.dp(this@PdfViewerActivity, 6), 0, Hb.dp(this@PdfViewerActivity, 14))
        })
        empty.addView(Hb.button(this, "Choose a PDF", true, R.drawable.ic_folder) {
            pick.launch(arrayOf("application/pdf"))
        }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, Hb.dp(this@PdfViewerActivity, 48)))

        pageLabel = Hb.text(this, "", 11.5f, p.muted).apply {
            setPadding(Hb.dp(this@PdfViewerActivity, 18), Hb.dp(this@PdfViewerActivity, 6), 0, Hb.dp(this@PdfViewerActivity, 6))
        }
        root.addView(pageLabel)
        list = RecyclerView(this).apply {
            layoutManager = LinearLayoutManager(this@PdfViewerActivity)
            setBackgroundColor(p.bg)
            visibility = View.GONE
            setPadding(0, 0, 0, Hb.dp(this@PdfViewerActivity, 24))
            clipToPadding = false
        }
        root.addView(list, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        root.addView(empty, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        setContentView(root)

        val data = intent?.data
        if (data != null) open(data)
    }

    private fun open(pdf: Uri) {
        closeRenderer()
        uri = pdf
        pageLabel.text = "Opening…"
        lifecycleScope.launch {
            val opened = withContext(Dispatchers.IO) {
                try {
                    val fd = contentResolver.openFileDescriptor(pdf, "r") ?: return@withContext null
                    val r = PdfRenderer(fd)
                    pfd = fd
                    renderer = r
                    r.pageCount
                } catch (_: Exception) {
                    null
                }
            }
            val count = opened
            if (count == null || count == 0) {
                pageLabel.text = ""
                showMessage("Could not open this PDF", "The file may be damaged, encrypted with a password, or not a PDF.")
                return@launch
            }
            empty.visibility = View.GONE
            list.visibility = View.VISIBLE
            pageLabel.text = "$count page${if (count == 1) "" else "s"} • ${Fmt.name(this@PdfViewerActivity, pdf)}"
            list.adapter = PageAdapter(count)
            list.scrollToPosition(0)
        }
    }

    private fun showMessage(title: String, message: String) {
        empty.removeAllViews()
        val p = Hb.palette(this)
        empty.addView(Hb.iconCircle(this, R.drawable.ic_pdf, p.danger, p.surfaceAlt, 64))
        empty.addView(Hb.text(this, title, 17f, p.text, bold = true).apply {
            gravity = Gravity.CENTER
            setPadding(0, Hb.dp(this@PdfViewerActivity, 12), 0, 0)
        })
        empty.addView(Hb.text(this, message, 11.5f, p.muted).apply {
            gravity = Gravity.CENTER
            setPadding(0, Hb.dp(this@PdfViewerActivity, 6), 0, Hb.dp(this@PdfViewerActivity, 14))
        })
        empty.addView(Hb.button(this, "Choose another PDF", true, R.drawable.ic_folder) {
            pick.launch(arrayOf("application/pdf"))
        }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, Hb.dp(this@PdfViewerActivity, 48)))
        empty.visibility = View.VISIBLE
        list.visibility = View.GONE
    }

    private fun renderPage(index: Int): Bitmap? {
        val r = renderer ?: return null
        val targetWidth = (resources.displayMetrics.widthPixels * 1.4f).toInt().coerceIn(720, 1600)
        synchronized(renderLock) {
            try {
                r.openPage(index).use { page ->
                    val height = (targetWidth.toFloat() / page.width.toFloat() * page.height.toFloat()).toInt().coerceAtLeast(1)
                    val bitmap = Bitmap.createBitmap(targetWidth, height, Bitmap.Config.ARGB_8888)
                    bitmap.eraseColor(Color.WHITE)
                    page.render(bitmap, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                    return bitmap
                }
            } catch (_: Exception) {
                return null
            }
        }
    }

    private fun closeRenderer() {
        cache.evictAll()
        synchronized(renderLock) {
            try { renderer?.close() } catch (_: Exception) {}
            try { pfd?.close() } catch (_: Exception) {}
            renderer = null
            pfd = null
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        closeRenderer()
    }

    private inner class PageAdapter(private val count: Int) : RecyclerView.Adapter<PageHolder>() {
        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): PageHolder {
            val wrap = LinearLayout(parent.context).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(Hb.dp(parent.context, 10), Hb.dp(parent.context, 10), Hb.dp(parent.context, 10), Hb.dp(parent.context, 10))
            }
            val image = ImageView(parent.context).apply {
                setBackgroundColor(Color.WHITE)
                adjustViewBounds = true
                scaleType = ImageView.ScaleType.FIT_CENTER
                layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            }
            val number = Hb.text(parent.context, "", 10.5f, Hb.palette(parent.context).muted).apply {
                gravity = Gravity.CENTER
                setPadding(0, Hb.dp(parent.context, 4), 0, 0)
            }
            wrap.addView(image)
            wrap.addView(number)
            return PageHolder(wrap, image, number)
        }

        override fun onBindViewHolder(holder: PageHolder, position: Int) {
            holder.number.text = "Page ${position + 1} of $count"
            holder.image.tag = position
            val cached = cache.get(position)
            if (cached != null) {
                holder.image.setImageBitmap(cached)
                return
            }
            holder.image.setImageBitmap(null)
            if (holder.image.height > 0) holder.image.layoutParams.height = ViewGroup.LayoutParams.WRAP_CONTENT
            lifecycleScope.launch {
                val bmp = withContext(Dispatchers.IO) { renderPage(position) }
                if (holder.image.tag == position && bmp != null) {
                    cache.put(position, bmp)
                    holder.image.setImageBitmap(bmp)
                }
            }
        }

        override fun getItemCount(): Int = count
    }

    private class PageHolder(container: LinearLayout, val image: ImageView, val number: TextView) : RecyclerView.ViewHolder(container)
}
