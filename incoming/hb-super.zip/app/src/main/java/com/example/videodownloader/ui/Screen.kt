package com.example.videodownloader.ui

import android.view.View

interface Screen {
    val root: View
    fun onShow() {}
    fun onHide() {}

    /** The host activity lost focus (an external activity, picker or the share sheet opened). */
    fun onHostPause() {}
    fun onHostResume() {}
    fun onBack(): Boolean = false
    fun refresh() {}
}
