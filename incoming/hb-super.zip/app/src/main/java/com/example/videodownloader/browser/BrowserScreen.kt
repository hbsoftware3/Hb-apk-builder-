package com.example.videodownloader.browser

import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.ValueAnimator
import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.net.Uri
import android.os.Message
import android.text.Editable
import android.text.InputType
import android.text.TextUtils
import android.text.TextWatcher
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.webkit.CookieManager
import android.webkit.GeolocationPermissions
import android.webkit.HttpAuthHandler
import android.webkit.PermissionRequest
import android.webkit.SslErrorHandler
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebStorage
import android.webkit.WebView
import android.webkit.WebViewClient
import android.webkit.WebViewDatabase
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.core.content.ContextCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.core.view.isVisible
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout
import androidx.webkit.WebMessageCompat
import androidx.webkit.WebSettingsCompat
import androidx.webkit.WebViewCompat
import androidx.webkit.WebViewFeature
import com.example.videodownloader.MainActivity
import com.example.videodownloader.DownloadService
import com.example.videodownloader.DownloadTracker
import com.example.videodownloader.Prefs
import com.example.videodownloader.Quality
import com.example.videodownloader.R
import com.example.videodownloader.Site
import com.example.videodownloader.Updater
import com.example.videodownloader.VideoFormats
import com.example.videodownloader.ui.Hb
import com.example.videodownloader.ui.Screen
import com.example.videodownloader.util.Fmt
import com.example.videodownloader.util.Launcher
import org.json.JSONObject
import org.json.JSONTokener
import java.io.ByteArrayInputStream
import java.io.File
import java.util.Collections
import java.util.UUID

class BrowserScreen(private val act: MainActivity) : Screen {

    private data class Tab(
        val id: String,
        val isPrivate: Boolean,
        var url: String = "",
        var title: String = "",
        var showHome: Boolean = true,
        var desktop: Boolean = false,
        var reader: Boolean = false,
        var readerUrl: String? = null,
        var readerLoading: Boolean = false,
        var dark: Boolean = false,
        var lastScroll: Int = 0
    ) {
        var web: WebView? = null
        var swipe: SwipeRefreshLayout? = null
        var thumbnail: Bitmap? = null
        /** Media files this page actually loaded (.mp4/.m3u8/.mpd/.webm), oldest first. */
        val media: MutableSet<String> = Collections.synchronizedSet(LinkedHashSet())
    }

    private data class Shortcut(val name: String, val url: String, val color: Int, val letter: String)

    override val root: View

    private val p get() = Hb.palette(act)
    private val incognito get() = current?.isPrivate == true
    private val cBg get() = if (incognito) INC_BG else p.bg
    private val cSurface get() = if (incognito) INC_SURFACE else p.surface
    private val cAlt get() = if (incognito) INC_SURFACE_ALT else p.surfaceAlt
    private val cText get() = if (incognito) INC_TEXT else p.text
    private val cMuted get() = if (incognito) INC_MUTED else p.muted
    private val cAccent get() = if (incognito) INC_ACCENT else p.blue
    private val cSoft get() = if (incognito) INC_SOFT else p.blueSoft
    private val cBorder get() = if (incognito) INC_BORDER else p.border

    private val tabs = ArrayList<Tab>()
    private var current: Tab? = null

    private lateinit var topArea: LinearLayout
    private lateinit var toolbar: LinearLayout
    private lateinit var addressPill: LinearLayout
    private lateinit var lockIcon: ImageView
    private lateinit var address: EditText
    private lateinit var incognitoChip: TextView
    private lateinit var tabCounter: FrameLayout
    private lateinit var tabCount: TextView
    private lateinit var menuIcon: ImageView
    private lateinit var suggestBox: LinearLayout
    private lateinit var progress: ProgressBar

    private lateinit var contentFrame: FrameLayout
    private lateinit var webHost: FrameLayout
    private lateinit var homeScroll: ScrollView
    private lateinit var homeCol: LinearLayout
    private lateinit var tabsOverlay: FrameLayout
    private lateinit var videoOverlay: FrameLayout
    private lateinit var menuOverlay: FrameLayout
    private lateinit var videoFab: FrameLayout
    private lateinit var mediaBadge: TextView
    private lateinit var videoSheet: FrameLayout
    private lateinit var findBar: LinearLayout
    private lateinit var findInput: EditText
    private lateinit var findStatus: TextView
    private lateinit var exitFull: FrameLayout

    private var pendingFileCallback: ValueCallback<Array<Uri>>? = null
    private var customView: View? = null
    private var customCallback: WebChromeClient.CustomViewCallback? = null
    private var immersive = false
    private var addressFocused = false
    private var toolbarHidden = false
    private var toolbarAnimator: ValueAnimator? = null
    private var lastTouchX = 0f
    private var lastTouchY = 0f
    private var bridgeWindow = 0L
    private var bridgeCount = 0
    private var videoReferer: String? = null

    init {
        topArea = LinearLayout(act).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, Hb.dp(act, TOOLBAR_HEIGHT_DP)
            )
        }
        toolbar = buildToolbar()
        topArea.addView(toolbar, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, Hb.dp(act, TOOLBAR_ROW_DP)
        ))
        progress = Hb.progress(act).apply {
            max = 100
            visibility = View.INVISIBLE
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, Hb.dp(act, 2)
            )
            progressBackgroundTintList = ColorStateList.valueOf(Color.TRANSPARENT)
        }
        topArea.addView(progress, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, Hb.dp(act, 2)
        ))
        suggestBox = LinearLayout(act).apply {
            orientation = LinearLayout.VERTICAL
            visibility = View.GONE
            setPadding(Hb.dp(act, 6), Hb.dp(act, 6), Hb.dp(act, 6), Hb.dp(act, 6))
            elevation = Hb.dp(act, 10).toFloat()
        }
        contentFrame = FrameLayout(act)
        webHost = FrameLayout(act).apply { setBackgroundColor(cBg) }
        homeCol = Hb.column(act, 18).apply { gravity = Gravity.CENTER_HORIZONTAL }
        homeScroll = ScrollView(act).apply {
            isFillViewport = true
            overScrollMode = View.OVER_SCROLL_NEVER
            setBackgroundColor(cBg)
            addView(homeCol)
        }
        tabsOverlay = FrameLayout(act).apply {
            visibility = View.GONE
        }
        videoOverlay = FrameLayout(act).apply {
            setBackgroundColor(Color.BLACK)
            visibility = View.GONE
        }
        menuOverlay = FrameLayout(act).apply {
            visibility = View.GONE
        }
        findBar = buildFindBar()
        exitFull = FrameLayout(act).apply {
            background = Hb.round(act, 22, 0xCC0B1220.toInt())
            addView(Hb.icon(act, R.drawable.ic_close, Color.WHITE, 19),
                FrameLayout.LayoutParams(Hb.dp(act, 19), Hb.dp(act, 19), Gravity.CENTER))
            visibility = View.GONE
            Hb.clickable(this) {
                if (customView != null) customCallback?.onCustomViewHidden() else setImmersive(false)
            }
        }
        videoFab = FrameLayout(act).apply {
            background = Hb.round(act, 26, cAccent)
            elevation = Hb.dp(act, 6).toFloat()
            addView(Hb.icon(act, R.drawable.ic_download, Color.WHITE, 24),
                FrameLayout.LayoutParams(Hb.dp(act, 24), Hb.dp(act, 24), Gravity.CENTER))
            visibility = View.GONE
            contentDescription = "Download video"
            Hb.clickable(this) { showVideoSheet() }
            Hb.pressScale(this)
        }
        mediaBadge = TextView(act).apply {
            setTextColor(Color.WHITE)
            textSize = 9.5f
            gravity = Gravity.CENTER
            background = Hb.round(act, 9, p.danger)
            visibility = View.GONE
        }
        videoFab.addView(mediaBadge, FrameLayout.LayoutParams(Hb.dp(act, 18), Hb.dp(act, 18), Gravity.TOP or Gravity.END))
        videoSheet = FrameLayout(act).apply { visibility = View.GONE }

        contentFrame.addView(webHost, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        contentFrame.addView(homeScroll, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        contentFrame.addView(suggestBox, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.TOP).apply {
            topMargin = Hb.dp(act, 4)
            marginStart = Hb.dp(act, 8)
            marginEnd = Hb.dp(act, 8)
        })
        contentFrame.addView(tabsOverlay, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        contentFrame.addView(videoOverlay, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        contentFrame.addView(findBar, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.TOP).apply {
            topMargin = Hb.dp(act, 8)
            marginStart = Hb.dp(act, 10)
            marginEnd = Hb.dp(act, 10)
        })
        contentFrame.addView(exitFull, FrameLayout.LayoutParams(Hb.dp(act, 42), Hb.dp(act, 42), Gravity.TOP or Gravity.END).apply {
            topMargin = Hb.dp(act, 12)
            marginEnd = Hb.dp(act, 12)
        })
        contentFrame.addView(videoFab, FrameLayout.LayoutParams(Hb.dp(act, 52), Hb.dp(act, 52), Gravity.BOTTOM or Gravity.END).apply {
            marginEnd = Hb.dp(act, 18)
            bottomMargin = Hb.dp(act, 18)
        })
        contentFrame.addView(videoSheet, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        contentFrame.addView(menuOverlay, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

        root = LinearLayout(act).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(cBg)
            addView(topArea, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, Hb.dp(act, TOOLBAR_HEIGHT_DP)))
            addView(contentFrame, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        }

        if (Prefs.privateSessionOpen(act)) {
            // The app was killed while a private tab was open: remove whatever it left behind.
            clearPrivateSessionData()
            Prefs.setPrivateSessionOpen(act, false)
        }
        restoreOrCreate()
    }

    // ------------------------------------------------------------------ UI

    private fun buildToolbar(): LinearLayout = LinearLayout(act).apply {
        orientation = LinearLayout.HORIZONTAL
        gravity = Gravity.CENTER_VERTICAL
        setPadding(Hb.dp(act, 8), Hb.dp(act, 7), Hb.dp(act, 5), Hb.dp(act, 7))

        addressPill = LinearLayout(act).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            background = Hb.round(act, 22, cAlt, cBorder, 1)
            setPadding(Hb.dp(act, 11), 0, Hb.dp(act, 6), 0)
        }
        lockIcon = Hb.icon(act, R.drawable.ic_search, cMuted, 16)
        lockIcon.setOnClickListener { showSiteInfo() }
        addressPill.addView(lockIcon, LinearLayout.LayoutParams(Hb.dp(act, 16), Hb.dp(act, 16)).apply {
            marginEnd = Hb.dp(act, 7)
        })

        address = EditText(act).apply {
            hint = "Search or type a web address"
            setHintTextColor(cMuted)
            setTextColor(cText)
            textSize = 14f
            setSingleLine(true)
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI
            imeOptions = EditorInfo.IME_ACTION_GO
            setBackgroundColor(Color.TRANSPARENT)
            setPadding(0, 0, 0, 0)
            setTextCursorDrawable(null)
            setOnEditorActionListener { _, actionId, _ ->
                if (actionId == EditorInfo.IME_ACTION_GO || actionId == EditorInfo.IME_ACTION_DONE) {
                    commit(address.text.toString())
                    true
                } else false
            }
            addTextChangedListener(object : TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
                override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
                override fun afterTextChanged(s: Editable?) {
                    if (addressFocused) showSuggestions(s?.toString() ?: "")
                }
            })
            setOnFocusChangeListener { _, focused ->
                addressFocused = focused
                if (focused) {
                    resetToolbar()
                    val tab = current
                    setText(if (tab == null || tab.showHome) "" else tab.readerUrl ?: tab.url)
                    post { selectAll() }
                    showSuggestions(text.toString())
                } else {
                    hideSuggestions()
                    syncAddress()
                }
                applyChrome()
            }
        }
        addressPill.addView(address, LinearLayout.LayoutParams(0, Hb.dp(act, 42), 1f))

        incognitoChip = Hb.text(act, "Incognito", 9.5f, cAccent, medium = true).apply {
            gravity = Gravity.CENTER
            setPadding(Hb.dp(act, 7), Hb.dp(act, 3), Hb.dp(act, 7), Hb.dp(act, 3))
            background = Hb.round(act, 20, cSoft)
            visibility = View.GONE
        }
        addressPill.addView(incognitoChip, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT
        ).apply {
            marginStart = Hb.dp(act, 4)
        })
        addView(addressPill, LinearLayout.LayoutParams(0, Hb.dp(act, 44), 1f))

        tabCount = TextView(act).apply {
            text = "1"
            textSize = 12.5f
            setTextColor(cText)
            gravity = Gravity.CENTER
            includeFontPadding = false
        }
        tabCounter = FrameLayout(act).apply {
            background = Hb.round(act, 10, cAlt, cBorder, 1)
            addView(tabCount, FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT, Gravity.CENTER))
            Hb.clickable(this) {
                resetToolbar()
                showTabsOverlay()
            }
        }
        addView(tabCounter, LinearLayout.LayoutParams(Hb.dp(act, 36), Hb.dp(act, 36)).apply {
            marginStart = Hb.dp(act, 6)
        })

        menuIcon = Hb.icon(act, R.drawable.ic_more, cText, 21)
        val menuButton = FrameLayout(act).apply {
            addView(menuIcon, FrameLayout.LayoutParams(Hb.dp(act, 34), Hb.dp(act, 34), Gravity.CENTER))
            Hb.clickable(this) {
                resetToolbar()
                showMenu()
            }
        }
        addView(menuButton, LinearLayout.LayoutParams(Hb.dp(act, 38), Hb.dp(act, 38)).apply {
            marginStart = Hb.dp(act, 2)
        })
    }

    private fun weight(): LinearLayout.LayoutParams =
        LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)

    private fun buildFindBar(): LinearLayout {
        val bar = LinearLayout(act).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            background = Hb.round(act, 16, p.surface, p.border, 1)
            setPadding(Hb.dp(act, 8), Hb.dp(act, 4), Hb.dp(act, 4), Hb.dp(act, 4))
            visibility = View.GONE
            elevation = Hb.dp(act, 4).toFloat()
        }
        findInput = EditText(act).apply {
            hint = "Find in page"
            setHintTextColor(p.muted)
            setTextColor(p.text)
            textSize = 13f
            setSingleLine(true)
            setBackgroundColor(Color.TRANSPARENT)
            imeOptions = EditorInfo.IME_ACTION_SEARCH
            setPadding(Hb.dp(act, 6), 0, Hb.dp(act, 6), 0)
            setOnEditorActionListener { _, actionId, _ ->
                if (actionId == EditorInfo.IME_ACTION_SEARCH) {
                    current?.web?.findNext(true)
                    true
                } else false
            }
            addTextChangedListener(object : TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
                override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
                override fun afterTextChanged(s: Editable?) {
                    val q = s?.toString() ?: ""
                    val web = current?.web ?: return
                    if (q.isEmpty()) web.clearMatches() else web.findAllAsync(q)
                }
            })
        }
        bar.addView(findInput, LinearLayout.LayoutParams(0, Hb.dp(act, 40), 1f))
        findStatus = Hb.text(act, "0/0", 11f, p.muted).apply { setPadding(Hb.dp(act, 6), 0, Hb.dp(act, 6), 0) }
        bar.addView(findStatus)
        bar.addView(Hb.iconButton(act, R.drawable.ic_back, p.text, 34) { current?.web?.findNext(false) }, LinearLayout.LayoutParams(Hb.dp(act, 34), Hb.dp(act, 34)))
        bar.addView(Hb.iconButton(act, R.drawable.ic_forward, p.text, 34) { current?.web?.findNext(true) }, LinearLayout.LayoutParams(Hb.dp(act, 34), Hb.dp(act, 34)).apply { marginStart = Hb.dp(act, 2) })
        bar.addView(Hb.iconButton(act, R.drawable.ic_close, p.text, 34) { hideFind() }, LinearLayout.LayoutParams(Hb.dp(act, 34), Hb.dp(act, 34)).apply { marginStart = Hb.dp(act, 2) })
        return bar
    }

    // ------------------------------------------------------------------ tabs

    private fun restoreOrCreate() {
        val restored = if (Prefs.restoreTabs(act)) BrowserStore.savedTabs(act) else emptyList()
        if (!Prefs.restoreTabs(act)) BrowserStore.clearTabs(act)
        if (restored.isNotEmpty()) {
            restored.take(8).forEach { saved ->
                tabs.add(Tab(UUID.randomUUID().toString(), false, saved.url, saved.title, showHome = false))
            }
            val first = tabs.first()
            selectTab(first)
            Hb.toast(act, "Restored ${tabs.size} tab${if (tabs.size == 1) "" else "s"}")
        } else {
            tabs.add(Tab(UUID.randomUUID().toString(), false))
            selectTab(tabs.first())
        }
    }

    private fun newTab(private: Boolean = false, url: String? = null): Tab {
        val normalized = url?.let { BrowserUrl.normalize(it, Prefs.searchEngine(act)) }
        val tab = Tab(
            id = UUID.randomUUID().toString(),
            isPrivate = private,
            url = normalized ?: "",
            title = "",
            showHome = normalized == null
        )
        tabs.add(tab)
        selectTab(tab)
        saveSession()
        return tab
    }

    private fun selectTab(tab: Tab) {
        if (!tabs.contains(tab)) return
        val previous = current
        if (previous != null && previous !== tab && !previous.showHome) captureThumb(previous)
        current = tab
        if (addressFocused) address.clearFocus()
        val web = ensureWeb(tab)
        webHost.removeAllViews()
        webHost.addView(tab.swipe ?: web, FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT
        ))
        webHost.isVisible = !tab.showHome
        homeScroll.isVisible = tab.showHome
        if (!tab.showHome && web.url.isNullOrBlank() && tab.url.isNotBlank()) web.loadUrl(tab.url)
        if (tab.showHome) refreshHome()
        tabsOverlay.isVisible = false
        hideSuggestions()
        hideFind()
        hideMenu()
        hideVideoSheet()
        tab.lastScroll = 0
        resetToolbar()
        updateChrome()
    }

    private fun closeTab(tab: Tab) {
        destroyWeb(tab)
        tabs.remove(tab)
        if (current === tab) {
            current = tabs.lastOrNull { it.isPrivate == tab.isPrivate } ?: tabs.lastOrNull()
        }
        if (tabs.none { !it.isPrivate }) {
            val home = Tab(UUID.randomUUID().toString(), false)
            tabs.add(home)
            if (current == null || current!!.isPrivate) current = home
        }
        val cur = current ?: tabs.first()
        selectTab(cur)
        if (tab.isPrivate && tabs.none { it.isPrivate } && Prefs.clearPrivateOnExit(act)) {
            clearPrivateSessionData()
            Hb.toast(act, "Private session closed and data cleared")
        }
        saveSession()
        updateChrome()
    }

    private fun closeAllTabs() {
        val toClose = ArrayList(tabs)
        val hadPrivate = toClose.any { it.isPrivate }
        toClose.forEach { destroyWeb(it) }
        tabs.clear()
        val home = Tab(UUID.randomUUID().toString(), false)
        tabs.add(home)
        selectTab(home)
        if (hadPrivate && Prefs.clearPrivateOnExit(act)) clearPrivateSessionData()
        saveSession()
        updateChrome()
    }

    private fun closePrivateTabs(notify: Boolean) {
        val priv = tabs.filter { it.isPrivate }
        if (priv.isEmpty()) return
        priv.forEach { destroyWeb(it); tabs.remove(it) }
        if (current == null || current!!.isPrivate) {
            current = tabs.firstOrNull { !it.isPrivate } ?: Tab(UUID.randomUUID().toString(), false).also { tabs.add(it) }
        }
        clearPrivateSessionData()
        selectTab(current!!)
        saveSession()
        updateChrome()
        if (notify) Hb.toast(act, "Private session closed and data cleared")
    }

    private fun destroyWeb(tab: Tab) {
        tab.swipe?.let { (it.parent as? ViewGroup)?.removeView(it) }
        tab.swipe = null
        val web = tab.web
        tab.web = null
        if (web != null) {
            (web.parent as? ViewGroup)?.removeView(web)
            try {
                web.stopLoading()
                web.loadUrl("about:blank")
                web.destroy()
            } catch (_: Exception) {
            }
        }
        tab.thumbnail?.recycle()
        tab.thumbnail = null
    }

    private fun ensureWeb(tab: Tab): WebView {
        tab.web?.let { return it }
        val web = WebView(act)
        web.setBackgroundColor(p.bg)
        val s = web.settings
        s.javaScriptEnabled = true
        s.domStorageEnabled = true
        s.databaseEnabled = true
        s.allowFileAccess = false
        s.allowContentAccess = false
        s.setGeolocationEnabled(false)
        s.javaScriptCanOpenWindowsAutomatically = false
        s.setSupportMultipleWindows(true)
        s.mediaPlaybackRequiresUserGesture = true
        s.mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
        s.builtInZoomControls = true
        s.displayZoomControls = false
        s.loadWithOverviewMode = true
        s.useWideViewPort = true
        s.textZoom = Prefs.browserTextZoom(act)
        s.userAgentString = if (tab.desktop) DESKTOP_UA else null
        s.cacheMode = if (tab.isPrivate) WebSettings.LOAD_NO_CACHE else WebSettings.LOAD_DEFAULT
        @Suppress("DEPRECATION")
        s.saveFormData = false
        try {
            CookieManager.getInstance().setAcceptThirdPartyCookies(web, false)
        } catch (_: Exception) {
        }
        try {
            if (WebViewFeature.isFeatureSupported(WebViewFeature.ALGORITHMIC_DARKENING)) {
                WebSettingsCompat.setAlgorithmicDarkeningAllowed(web.settings, tab.dark)
            }
        } catch (_: Exception) {
        }

        web.webViewClient = BrowserClient(tab)
        web.webChromeClient = BrowserChrome(tab)
        web.setDownloadListener { url, userAgent, contentDisposition, mimeType, contentLength ->
            promptDownload(tab, url, userAgent, contentDisposition, mimeType, contentLength)
        }
        web.setOnTouchListener { _, event ->
            if (event.actionMasked == MotionEvent.ACTION_DOWN) {
                lastTouchX = event.x
                lastTouchY = event.y
            }
            false
        }
        web.setOnLongClickListener { handleLongPress(tab, web) }
        setupVideoBridge(web, tab)
        web.setFindListener { active, total, _ ->
            if (current === tab) findStatus.text = "$active/$total"
        }
        web.setOnFocusChangeListener { _, hasFocus ->
            if (hasFocus) {
                hideSuggestions()
                if (addressFocused) address.clearFocus()
            }
        }
        web.setOnScrollChangeListener { _, _, scrollY, _, _ ->
            if (current === tab) onWebScroll(scrollY)
        }

        val swipe = SwipeRefreshLayout(act).apply {
            setBackgroundColor(cBg)
            setColorSchemeColors(cAccent)
            setProgressBackgroundColorSchemeColor(cSurface)
            setDistanceToTriggerSync(Hb.dp(act, 110))
            setOnRefreshListener {
                if (!tab.showHome && (tab.web?.progress ?: 0) >= 100) {
                    address.clearFocus()
                    resetToolbar()
                    tab.web?.reload()
                } else {
                    isRefreshing = false
                }
            }
            addView(web, ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
        }
        tab.swipe = swipe
        tab.web = web
        return web
    }

    // ------------------------------------------------------------------ clients

    private inner class BrowserClient(private val tab: Tab) : WebViewClient() {

        override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
            return handleUrl(tab, request.url.toString())
        }

        override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? {
            val blocked = blockedRequest(request)
            // Ad-block still wins; only real page content is remembered for the download sheet
            if (blocked == null) sniffMedia(tab, request.url)
            return blocked
        }

        override fun onPageStarted(view: WebView, url: String, favicon: Bitmap?) {
            if (tab.readerLoading) {
                tab.readerLoading = false
                return
            }
            if (tab.reader && tab.readerUrl != null && url != tab.readerUrl) {
                tab.reader = false
                tab.readerUrl = null
            }
            if (tab.reader) return
            if (url == "about:blank") return
            tab.url = url
            tab.showHome = false
            tab.lastScroll = 0
            tab.media.clear()
            if (current === tab) {
                webHost.isVisible = true
                homeScroll.isVisible = false
                progress.visibility = View.VISIBLE
                progress.progress = 2
                resetToolbar()
                syncAddress()
                updateChrome()
            }
        }

        override fun onPageFinished(view: WebView, url: String) {
            if (tab.readerLoading) tab.readerLoading = false
            if (!tab.reader) {
                val title = view.title?.takeIf { it.isNotBlank() }
                if (title != null) tab.title = title
                if (tab.title.isBlank()) tab.title = BrowserUrl.display(tab.url)
                if (!tab.isPrivate && BrowserUrl.isHttp(tab.url)) {
                    BrowserStore.addHistory(act, tab.url, tab.title)
                }
                saveSession()
            }
            if (!tab.reader && !tab.showHome) injectVideoButtons(view, tab.url)
            tab.swipe?.isRefreshing = false
            if (current === tab) {
                progress.visibility = View.INVISIBLE
                progress.progress = 0
                applyDark(tab)
                updateChrome()
                if (homeScroll.isVisible) refreshHome()
                if (!tab.isPrivate && !tab.showHome) {
                    view.postDelayed({
                        if (tab.web === view && !tab.showHome) captureThumb(tab)
                    }, 500)
                }
            }
        }

        override fun onReceivedError(view: WebView, request: WebResourceRequest, error: android.webkit.WebResourceError) {
            if (!request.isForMainFrame) return
            tab.swipe?.isRefreshing = false
            if (current === tab) {
                progress.visibility = View.INVISIBLE
                progress.progress = 0
            }
            Hb.toast(act, "Could not open this page (${error.errorCode})")
        }

        override fun onReceivedSslError(view: WebView, handler: SslErrorHandler, error: android.net.http.SslError) {
            handler.cancel()
            Hb.toast(act, "Blocked: this site's security certificate is not valid")
        }

        override fun onReceivedHttpAuthRequest(view: WebView, handler: HttpAuthHandler, host: String, realm: String) {
            handler.cancel()
            Hb.toast(act, "$host asked for a password. Sign-in prompts are disabled in HB Browser.")
        }

        override fun doUpdateVisitedHistory(view: WebView, url: String, isReload: Boolean) {
            if (tab.reader) return
            tab.url = url
            if (current === tab) {
                syncAddress()
                updateChrome()
            }
            if (!tab.showHome) injectVideoButtons(view, url)
        }
    }

    private inner class BrowserChrome(private val tab: Tab) : WebChromeClient() {

        override fun onProgressChanged(view: WebView, newProgress: Int) {
            if (current !== tab) return
            progress.visibility = if (newProgress >= 100 || immersive) View.INVISIBLE else View.VISIBLE
            progress.progress = newProgress
            if (newProgress >= 100) tab.swipe?.isRefreshing = false
        }

        override fun onReceivedTitle(view: WebView?, title: String?) {
            if (!title.isNullOrBlank()) {
                tab.title = title
                if (current === tab) updateChrome()
            }
        }

        override fun onShowFileChooser(
            webView: WebView?,
            filePathCallback: ValueCallback<Array<Uri>>?,
            fileChooserParams: FileChooserParams?
        ): Boolean {
            pendingFileCallback?.onReceiveValue(null)
            pendingFileCallback = filePathCallback
            val types = fileChooserParams?.acceptTypes?.takeIf { it.isNotEmpty() } ?: arrayOf("*/*")
            val multiple = fileChooserParams?.mode == FileChooserParams.MODE_OPEN_MULTIPLE
            act.chooseFiles(types, multiple) { uris ->
                pendingFileCallback?.onReceiveValue(uris.toTypedArray())
                pendingFileCallback = null
            }
            return true
        }

        override fun onPermissionRequest(request: PermissionRequest?) {
            request?.deny()
            Hb.toast(act, "Camera and microphone access is blocked for websites")
        }

        override fun onGeolocationPermissionsShowPrompt(origin: String?, callback: GeolocationPermissions.Callback?) {
            callback?.invoke(origin, false, false)
            Hb.toast(act, "Location access is blocked for websites")
        }

        override fun onCreateWindow(view: WebView?, isDialog: Boolean, isUserGesture: Boolean, resultMsg: Message?): Boolean {
            if (!isUserGesture || isDialog) {
                if (!isUserGesture) Hb.toast(act, "Pop-up blocked. Long-press a link to open it in a new tab.")
                return false
            }
            val transport = resultMsg?.obj as? WebView.WebViewTransport ?: return false
            val fresh = newTab(tab.isPrivate)
            fresh.showHome = false
            webHost.isVisible = true
            homeScroll.isVisible = false
            transport.webView = ensureWeb(fresh)
            resultMsg.sendToTarget()
            updateChrome()
            return true
        }

        override fun onShowCustomView(view: View?, callback: CustomViewCallback?) {
            if (view == null) return
            if (customView != null) {
                callback?.onCustomViewHidden()
                return
            }
            customView = view
            customCallback = callback
            (view.parent as? ViewGroup)?.removeView(view)
            videoOverlay.removeAllViews()
            videoOverlay.addView(view, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
            videoOverlay.isVisible = true
            setImmersive(true)
        }

        override fun onHideCustomView() {
            customView?.let { (it.parent as? ViewGroup)?.removeView(it) }
            customView = null
            customCallback = null
            videoOverlay.removeAllViews()
            videoOverlay.isVisible = false
            setImmersive(false)
        }
    }

    // ------------------------------------------------------------------ navigation

    private fun handleUrl(tab: Tab, url: String): Boolean {
        val lower = url.lowercase()
        if (lower.startsWith("http://") || lower.startsWith("https://") || lower == "about:blank") return false
        if (lower.startsWith("intent:") || lower.startsWith("file:") || lower.startsWith("content:") ||
            lower.startsWith("javascript:") || lower.startsWith("data:") || lower.startsWith("blob:")) {
            Hb.toast(act, "Blocked an unsafe link")
            return true
        }
        val scheme = try {
            Uri.parse(url).scheme?.lowercase()
        } catch (_: Exception) {
            null
        }
        if (scheme in EXTERNAL_SCHEMES) {
            Hb.confirm(act, "Open in another app?", "This link wants to open $scheme.\n\n${url.take(180)}", "Open", "Cancel") {
                try {
                    act.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
                } catch (_: Exception) {
                    Hb.toast(act, "No app can handle this link")
                }
            }
        } else {
            Hb.toast(act, "This link type is not supported")
        }
        return true
    }

    private fun commit(input: String) {
        val raw = input.trim()
        if (raw.isEmpty()) return
        val url = BrowserUrl.normalize(raw, Prefs.searchEngine(act))
        val tab = current ?: newTab(false)
        hideSuggestions()
        address.clearFocus()
        hideKeyboard(address)
        loadUrl(tab, url)
    }

    private fun loadUrl(tab: Tab, url: String) {
        if (!BrowserUrl.isHttp(url)) {
            Hb.toast(act, "Only web addresses can open in the browser")
            return
        }
        tab.showHome = false
        tab.reader = false
        tab.readerLoading = false
        tab.readerUrl = null
        tab.url = url
        val web = ensureWeb(tab)
        webHost.isVisible = true
        homeScroll.isVisible = false
        web.loadUrl(url)
        updateChrome()
    }

    private fun loadFromHome(url: String) {
        val tab = current ?: newTab(false)
        loadUrl(tab, url)
    }

    /** The built-in HB start page (search, shortcuts, history, bookmarks). */
    private fun showStartPage(tab: Tab) {
        tab.showHome = true
        webHost.isVisible = false
        homeScroll.isVisible = true
        refreshHome()
        updateChrome()
    }

    /** Opens a link that came from another screen (clipboard tool, QR, reader, ...). */
    fun openUrl(url: String) {
        val normalized = BrowserUrl.normalize(url, Prefs.searchEngine(act))
        val tab = current ?: newTab(false)
        loadUrl(tab, normalized)
    }

    private fun engine(): SearchEngine = SearchEngine.from(Prefs.searchEngine(act))

    // ------------------------------------------------------------------ home

    private fun refreshHome() {
        homeCol.removeAllViews()
        homeCol.gravity = Gravity.CENTER_HORIZONTAL
        homeCol.setBackgroundColor(cBg)
        homeCol.addView(Hb.spacer(act, 18))

        homeCol.addView(FrameLayout(act).apply {
            background = Hb.gradient(act, 22, cAccent, if (incognito) 0xFF4A3A78.toInt() else 0xFF0668E8.toInt())
            addView(Hb.text(act, "HB", 26f, Color.WHITE, bold = true), FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.CENTER))
        }, LinearLayout.LayoutParams(Hb.dp(act, 72), Hb.dp(act, 72)))

        homeCol.addView(Hb.text(act, if (incognito) "Incognito" else "HB Browser", 20f, cText, bold = true).apply {
            gravity = Gravity.CENTER
            setPadding(0, Hb.dp(act, 12), 0, 0)
        })
        homeCol.addView(Hb.text(act,
            if (incognito) "Pages you open here are not saved" else "Search the web, or pick a site below",
            12f, cMuted).apply {
            gravity = Gravity.CENTER
            setPadding(0, Hb.dp(act, 4), 0, 0)
        })

        homeCol.addView(searchBox(), LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, Hb.dp(act, 52)
        ).apply { topMargin = Hb.dp(act, 22) })

        homeCol.addView(engineChips(), LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
        ).apply { topMargin = Hb.dp(act, 12) })

        homeCol.addView(shortcutGrid(), LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
        ).apply { topMargin = Hb.dp(act, 18) })

        val books = BrowserStore.bookmarks(act)
        if (books.isNotEmpty() && !incognito) {
            homeCol.addView(homeHeader("Bookmarks", "Manage") {
                act.startActivity(Intent(act, BrowserBookmarksActivity::class.java))
            })
            homeCol.addView(bookmarkPanel(books.take(4)))
        }

        homeCol.addView(Hb.spacer(act, 18))
        homeCol.addView(privateCard())
        homeCol.addView(Hb.text(act, "HB Browser 1.0 • Private tabs are never restored", 10f, cMuted).apply {
            gravity = Gravity.CENTER
            setPadding(0, Hb.dp(act, 16), 0, Hb.dp(act, 4))
        })
    }

    private fun searchBox(): LinearLayout {
        val box = LinearLayout(act).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            background = Hb.round(act, 26, cAlt, cBorder, 1)
            setPadding(Hb.dp(act, 14), 0, Hb.dp(act, 10), 0)
        }
        box.addView(Hb.icon(act, R.drawable.ic_search, cMuted, 18),
            LinearLayout.LayoutParams(Hb.dp(act, 18), Hb.dp(act, 18)).apply { marginEnd = Hb.dp(act, 10) })
        val input = EditText(act).apply {
            hint = if (incognito) "Search privately" else "Search or type URL"
            setHintTextColor(cMuted)
            setTextColor(cText)
            textSize = 14f
            setSingleLine(true)
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI
            imeOptions = EditorInfo.IME_ACTION_GO
            setBackgroundColor(Color.TRANSPARENT)
            setPadding(0, 0, 0, 0)
            setTextCursorDrawable(null)
        }
        fun go() {
            val q = input.text.toString().trim()
            if (q.isEmpty()) {
                address.requestFocus()
                return
            }
            hideKeyboard(input)
            input.setText("")
            commit(q)
        }
        input.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_GO || actionId == EditorInfo.IME_ACTION_DONE) {
                go()
                true
            } else false
        }
        box.addView(input, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f))
        val goIcon = Hb.icon(act, R.drawable.ic_chevron_right, cAccent, 18)
        goIcon.setOnClickListener { go() }
        box.addView(goIcon, LinearLayout.LayoutParams(Hb.dp(act, 22), Hb.dp(act, 22)))
        return box
    }

    private fun engineChips(): HorizontalScrollView {
        val scroll = HorizontalScrollView(act).apply { isHorizontalScrollBarEnabled = false }
        val row = LinearLayout(act).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val selected = engine()
        SearchEngine.entries.forEach { e ->
            val isSelected = e.id == selected.id
            val chip = Hb.text(act, e.label, 11.5f, if (isSelected) Color.WHITE else cMuted, medium = true).apply {
                gravity = Gravity.CENTER
                setPadding(Hb.dp(act, 13), Hb.dp(act, 7), Hb.dp(act, 13), Hb.dp(act, 7))
                background = if (isSelected) Hb.round(act, 40, cAccent)
                else Hb.round(act, 40, cAlt, cBorder, 1)
                Hb.clickable(this) {
                    Prefs.setSearchEngine(act, e.id)
                    refreshHome()
                    updateChrome()
                }
            }
            row.addView(chip, LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { marginEnd = Hb.dp(act, 7) })
        }
        scroll.addView(row)
        return scroll
    }

    private fun shortcutGrid(): LinearLayout {
        val grid = LinearLayout(act).apply { orientation = LinearLayout.VERTICAL }
        val items = shortcuts()
        var index = 0
        while (index < 8) {
            val row = LinearLayout(act).apply { orientation = LinearLayout.HORIZONTAL }
            repeat(4) {
                val cell = LinearLayout(act).apply {
                    orientation = LinearLayout.VERTICAL
                    gravity = Gravity.CENTER
                    setPadding(0, Hb.dp(act, 8), 0, Hb.dp(act, 8))
                }
                val item = items.getOrNull(index)
                if (item != null) {
                    cell.addView(letterAvatar(item.letter, item.color, 46))
                    cell.addView(Hb.text(act, item.name, 10.5f, cText, medium = true).apply {
                        gravity = Gravity.CENTER
                        maxLines = 1
                        setPadding(0, Hb.dp(act, 6), 0, 0)
                    })
                    Hb.clickable(cell) { loadFromHome(item.url) }
                    Hb.pressScale(cell)
                }
                row.addView(cell, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
                index++
            }
            grid.addView(row, LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
            ))
        }
        return grid
    }

    private fun shortcuts(): List<Shortcut> {
        val out = ArrayList<Shortcut>()
        val seen = HashSet<String>()
        BrowserStore.history(act).forEach { entry ->
            if (!BrowserUrl.isHttp(entry.url) || out.size >= 4) return@forEach
            val host = BrowserUrl.host(entry.url)
            if (host.isBlank() || !seen.add(host)) return@forEach
            val name = hostName(host)
            out.add(Shortcut(name, entry.url, colorFor(host), name.take(1)))
        }
        for (site in QUICK_SITES) {
            if (out.size >= 8) break
            if (seen.add(BrowserUrl.host(site.url))) {
                out.add(Shortcut(site.name, site.url, site.color, site.name.take(1)))
            }
        }
        return out.take(8)
    }

    private fun hostName(host: String): String {
        val clean = host.removePrefix("www.").removePrefix("m.").removePrefix("mobile.")
        val first = clean.substringBefore('.').ifBlank { clean }
        return first.replaceFirstChar { it.titlecase() }
    }

    private fun colorFor(key: String): Int {
        val colors = intArrayOf(
            0xFF4285F4.toInt(), 0xFFE53935.toInt(), 0xFF43A047.toInt(), 0xFFFB8C00.toInt(),
            0xFF8E24AA.toInt(), 0xFF00897B.toInt(), 0xFF5E35B1.toInt(), 0xFFD81B60.toInt()
        )
        return colors[Math.floorMod(key.hashCode(), colors.size)]
    }

    private fun homeHeader(title: String, action: String? = null, onAction: (() -> Unit)? = null): LinearLayout =
        LinearLayout(act).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, Hb.dp(act, 18), 0, Hb.dp(act, 8))
            addView(Hb.text(act, title, 14f, cText, bold = true),
                LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            if (action != null) {
                addView(Hb.text(act, action, 12f, cAccent, medium = true).apply {
                    setPadding(Hb.dp(act, 8), Hb.dp(act, 6), 0, Hb.dp(act, 6))
                    if (onAction != null) Hb.clickable(this, onAction)
                })
            }
        }

    private fun bookmarkPanel(list: List<Bookmark>): LinearLayout {
        val panel = LinearLayout(act).apply {
            orientation = LinearLayout.VERTICAL
            background = Hb.round(act, 16, cSurface, cBorder, 1)
            setPadding(Hb.dp(act, 4), Hb.dp(act, 4), Hb.dp(act, 4), Hb.dp(act, 4))
        }
        list.forEachIndexed { index, b ->
            panel.addView(Hb.row(act, R.drawable.ic_star, b.title.ifBlank { BrowserUrl.display(b.url) },
                BrowserUrl.display(b.url), iconTint = p.warning) {
                loadFromHome(b.url)
            })
            if (index != list.lastIndex) panel.addView(Hb.divider(act, 46))
        }
        return panel
    }

    private fun letterAvatar(letter: String, color: Int, sizeDp: Int = 44): FrameLayout = FrameLayout(act).apply {
        background = Hb.gradient(act, sizeDp / 3f, color, color and 0x00FFFFFF or 0x55000000)
        layoutParams = LinearLayout.LayoutParams(Hb.dp(act, sizeDp), Hb.dp(act, sizeDp))
        addView(Hb.text(act, letter.uppercase().take(1), sizeDp / 2.8f, Color.WHITE, bold = true),
            FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.CENTER))
    }

    private fun privateCard(): LinearLayout {
        val card = LinearLayout(act).apply {
            orientation = LinearLayout.VERTICAL
            background = Hb.round(act, 18, cSurface, cBorder, 1)
            setPadding(Hb.dp(act, 16), Hb.dp(act, 16), Hb.dp(act, 16), Hb.dp(act, 16))
        }
        if (incognito) {
            val head = LinearLayout(act).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
            }
            head.addView(Hb.iconCircle(act, R.drawable.ic_lock, cAccent, cSoft, 40))
            val texts = LinearLayout(act).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(Hb.dp(act, 12), 0, 0, 0)
            }
            texts.addView(Hb.text(act, "You're incognito", 14f, cText, medium = true))
            texts.addView(Hb.text(act, "History, cookies and saved tabs are cleared when this session ends.", 11.5f, cMuted))
            head.addView(texts, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            card.addView(head)
            card.addView(Hb.text(act, "Websites can still see your network address.", 10.5f, cMuted).apply {
                setPadding(0, Hb.dp(act, 10), 0, 0)
            })
            return card
        }

        val head = LinearLayout(act).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        head.addView(Hb.iconCircle(act, R.drawable.ic_lock, cAccent, cSoft, 40))
        val texts = LinearLayout(act).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(Hb.dp(act, 12), 0, 0, 0)
        }
        texts.addView(Hb.text(act, "Private browsing", 14.5f, cText, medium = true))
        texts.addView(Hb.text(act, "No history, no saved tabs. Data clears when you leave the browser.", 11.5f, cMuted))
        head.addView(texts, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        card.addView(head)
        card.addView(Hb.text(act, "New incognito tab", 12.5f, Color.WHITE, medium = true).apply {
            gravity = Gravity.CENTER
            background = Hb.round(act, 12, cAccent)
            Hb.clickable(this) { newTab(true) }
        }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, Hb.dp(act, 44)).apply {
            topMargin = Hb.dp(act, 14)
        })
        return card
    }

    // ------------------------------------------------------------------ tabs overlay

    private fun showTabsOverlay() {
        tabsOverlay.removeAllViews()
        tabsOverlay.setBackgroundColor(cBg)
        val col = LinearLayout(act).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(Hb.dp(act, 16), Hb.dp(act, 18), Hb.dp(act, 16), Hb.dp(act, 14))
        }
        val head = LinearLayout(act).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        head.addView(Hb.text(act, "Tabs", 21f, cText, bold = true))
        head.addView(Hb.text(act, "  ${tabs.size}", 14f, cAccent, medium = true))
        head.addView(View(act), LinearLayout.LayoutParams(0, 1, 1f))
        head.addView(Hb.iconButton(act, R.drawable.ic_close, cText, 38) { tabsOverlay.isVisible = false })
        col.addView(head)

        val actions = LinearLayout(act).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(0, Hb.dp(act, 12), 0, Hb.dp(act, 4))
        }
        actions.addView(tabAction("New tab", R.drawable.ic_browser) { newTab(false) },
            LinearLayout.LayoutParams(0, Hb.dp(act, 42), 1f).apply { marginEnd = Hb.dp(act, 4) })
        actions.addView(tabAction("New incognito tab", R.drawable.ic_lock) { newTab(true) },
            LinearLayout.LayoutParams(0, Hb.dp(act, 42), 1f).apply { marginStart = Hb.dp(act, 4) })
        col.addView(actions)

        val scroll = ScrollView(act).apply { isFillViewport = true }
        val grid = LinearLayout(act).apply { orientation = LinearLayout.VERTICAL }
        tabs.chunked(2).forEach { pair ->
            val row = LinearLayout(act).apply { orientation = LinearLayout.HORIZONTAL }
            pair.forEach { tab ->
                val lp = LinearLayout.LayoutParams(0, Hb.dp(act, 168), 1f)
                lp.marginStart = Hb.dp(act, 3)
                lp.marginEnd = Hb.dp(act, 3)
                lp.topMargin = Hb.dp(act, 3)
                lp.bottomMargin = Hb.dp(act, 3)
                row.addView(tabCard(tab), lp)
            }
            if (pair.size == 1) row.addView(View(act), LinearLayout.LayoutParams(0, 1, 1f))
            grid.addView(row, LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
            ))
        }
        scroll.addView(grid)
        col.addView(scroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))

        if (tabs.any { it.isPrivate }) {
            col.addView(tabAction("Close private tabs", R.drawable.ic_lock) { closePrivateTabs(true) },
                LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, Hb.dp(act, 42)).apply {
                    topMargin = Hb.dp(act, 4)
                })
        }
        col.addView(tabAction("Close all tabs", R.drawable.ic_close) { closeAllTabs() },
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, Hb.dp(act, 42)).apply {
                topMargin = Hb.dp(act, 4)
            })

        tabsOverlay.addView(col, FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT
        ))
        tabsOverlay.isVisible = true
    }

    private fun tabAction(label: String, iconRes: Int, onTap: () -> Unit): LinearLayout =
        LinearLayout(act).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            background = Hb.round(act, 12, cAlt, cBorder, 1)
            addView(Hb.icon(act, iconRes, cAccent, 16),
                LinearLayout.LayoutParams(Hb.dp(act, 16), Hb.dp(act, 16)).apply {
                    marginEnd = Hb.dp(act, 6)
                })
            addView(Hb.text(act, label, 12f, cText, medium = true))
            Hb.clickable(this, onTap)
            Hb.pressScale(this)
        }

    private fun tabCard(tab: Tab): LinearLayout {
        val card = LinearLayout(act).apply {
            orientation = LinearLayout.VERTICAL
            background = Hb.round(act, 14,
                if (tab.isPrivate) cAlt else cSurface,
                if (tab === current) cAccent else cBorder,
                if (tab === current) 2 else 1)
            clipToOutline = true
        }
        val thumb = FrameLayout(act)
        val bmp = tab.thumbnail
        if (bmp != null && !tab.isPrivate && !bmp.isRecycled) {
            val image = ImageView(act).apply {
                scaleType = ImageView.ScaleType.CENTER_CROP
                setImageBitmap(bmp)
            }
            thumb.addView(image, FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT
            ))
        } else {
            thumb.setBackgroundColor(if (tab.isPrivate) cAlt else cBg)
            thumb.addView(letterAvatar(tabLetter(tab), tabColor(tab), 40),
                FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.CENTER
                ))
        }
        val close = FrameLayout(act).apply {
            background = Hb.round(act, 13, 0xCC000000.toInt())
            addView(Hb.icon(act, R.drawable.ic_close, Color.WHITE, 12),
                FrameLayout.LayoutParams(Hb.dp(act, 12), Hb.dp(act, 12), Gravity.CENTER))
            Hb.clickable(this) { closeTab(tab) }
        }
        thumb.addView(close, FrameLayout.LayoutParams(
            Hb.dp(act, 26), Hb.dp(act, 26), Gravity.TOP or Gravity.END
        ).apply {
            topMargin = Hb.dp(act, 6)
            marginEnd = Hb.dp(act, 6)
        })
        card.addView(thumb, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))

        val info = LinearLayout(act).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(Hb.dp(act, 10), Hb.dp(act, 8), Hb.dp(act, 10), Hb.dp(act, 8))
        }
        val dot = FrameLayout(act).apply {
            background = Hb.round(act, 5, tabColor(tab))
            addView(Hb.text(act, tabLetter(tab), 7.5f, Color.WHITE, bold = true),
                FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.CENTER
                ))
        }
        info.addView(dot, LinearLayout.LayoutParams(Hb.dp(act, 18), Hb.dp(act, 18)).apply {
            marginEnd = Hb.dp(act, 7)
        })
        val texts = LinearLayout(act).apply { orientation = LinearLayout.VERTICAL }
        texts.addView(Hb.text(act, tabTitle(tab), 11.5f, cText, medium = true).apply {
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
        })
        texts.addView(Hb.text(act,
            if (tab.isPrivate) "Incognito" else BrowserUrl.host(tab.url).ifBlank { "New tab" },
            9.5f, cMuted).apply { maxLines = 1 })
        info.addView(texts, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        card.addView(info, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
        ))

        Hb.clickable(card) { selectTab(tab) }
        return card
    }

    private fun tabTitle(tab: Tab): String = when {
        tab.showHome -> if (tab.isPrivate) "Incognito" else "New tab"
        tab.title.isNotBlank() -> tab.title
        else -> BrowserUrl.display(tab.url).ifBlank { "Untitled" }
    }

    private fun tabLetter(tab: Tab): String {
        val source = if (tab.showHome) "N" else tab.title.ifBlank { BrowserUrl.host(tab.url) }
        return source.trim().take(1).ifBlank { "H" }
    }

    private fun tabColor(tab: Tab): Int = colorFor(BrowserUrl.host(tab.url).ifBlank { tab.title.ifBlank { "hb" } })

    // ------------------------------------------------------------------ suggestions

    private fun showSuggestions(raw: String) {
        suggestBox.removeAllViews()
        val q = raw.trim()
        if (q.isEmpty() || !address.isFocused) {
            suggestBox.isVisible = false
            return
        }
        val e = engine()
        suggestBox.addView(suggestRow(R.drawable.ic_search, "Search ${e.label} for \"$q\"", null, cAccent) {
            commit(e.searchUrl(q))
        })
        val fromHistory = BrowserStore.searchHistory(act, q).take(4).map { Triple(it.title, it.url, false) }
        val fromBookmarks = BrowserStore.searchBookmarks(act, q).take(4).map { Triple(it.title, it.url, true) }
        (fromHistory + fromBookmarks).distinctBy { it.second }.take(4).forEach { (title, url, isBookmark) ->
            suggestBox.addView(suggestRow(
                if (isBookmark) R.drawable.ic_star else R.drawable.ic_history,
                title.ifBlank { BrowserUrl.display(url) },
                BrowserUrl.display(url),
                if (isBookmark) p.warning else cMuted
            ) {
                commit(url)
            })
        }
        suggestBox.isVisible = true
    }

    private fun suggestRow(iconRes: Int, title: String, sub: String?, tint: Int, onTap: () -> Unit): LinearLayout =
        LinearLayout(act).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(Hb.dp(act, 8), Hb.dp(act, 9), Hb.dp(act, 8), Hb.dp(act, 9))
            addView(Hb.icon(act, iconRes, tint, 18),
                LinearLayout.LayoutParams(Hb.dp(act, 18), Hb.dp(act, 18)).apply {
                    marginEnd = Hb.dp(act, 12)
                })
            val texts = LinearLayout(act).apply { orientation = LinearLayout.VERTICAL }
            texts.addView(Hb.text(act, title, 13f, cText).apply {
                maxLines = 1
                ellipsize = TextUtils.TruncateAt.END
            })
            if (!sub.isNullOrBlank()) {
                texts.addView(Hb.text(act, sub, 10.5f, cMuted).apply {
                    maxLines = 1
                    ellipsize = TextUtils.TruncateAt.END
                })
            }
            addView(texts, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            Hb.clickable(this, onTap)
        }

    private fun hideSuggestions() {
        suggestBox.isVisible = false
    }

    // ------------------------------------------------------------------ chrome state

    private fun applyChrome() {
        root.setBackgroundColor(cBg)
        topArea.setBackgroundColor(cSurface)
        toolbar.setBackgroundColor(cSurface)
        webHost.setBackgroundColor(cBg)
        homeScroll.setBackgroundColor(cBg)
        homeCol.setBackgroundColor(cBg)
        addressPill.background = Hb.round(
            act, 22,
            if (addressFocused) cSurface else cAlt,
            if (addressFocused) cAccent else cBorder,
            if (addressFocused) 2 else 1
        )
        address.setTextColor(cText)
        address.setHintTextColor(cMuted)
        incognitoChip.setTextColor(cAccent)
        incognitoChip.background = Hb.round(act, 20, cSoft)
        tabCounter.background = Hb.round(act, 10, cAlt, cBorder, 1)
        tabCount.setTextColor(cText)
        menuIcon.imageTintList = ColorStateList.valueOf(cText)
        progress.progressTintList = ColorStateList.valueOf(cAccent)
        progress.progressBackgroundTintList = ColorStateList.valueOf(Color.TRANSPARENT)
        suggestBox.background = Hb.round(act, 16, cSurface, cBorder, 1)
        findBar.background = Hb.round(act, 16, cSurface, cBorder, 1)
        findInput.setTextColor(cText)
        findInput.setHintTextColor(cMuted)
        findStatus.setTextColor(cMuted)
    }

    private fun updateChrome() {
        val tab = current ?: return
        incognitoChip.isVisible = tab.isPrivate
        tabCount.text = if (tabs.size > 99) "99+" else tabs.size.toString()
        val secure = !tab.showHome && tab.url.startsWith("https://", true)
        lockIcon.setImageResource(
            when {
                tab.showHome -> R.drawable.ic_search
                secure -> R.drawable.ic_lock
                else -> R.drawable.ic_browser
            }
        )
        applyChrome()
        lockIcon.imageTintList = ColorStateList.valueOf(if (secure) cAccent else cMuted)
        val loading = (tab.web?.progress ?: 100) in 1..99 || progress.progress in 1..99
        progress.visibility = if (!immersive && !tab.showHome && loading) View.VISIBLE else View.INVISIBLE
        updateAddressHint()
        val video = !tab.showHome && (isVideoPage(tab.url) || tab.media.isNotEmpty())
        videoFab.isVisible = video && !immersive
        mediaBadge.isVisible = tab.media.isNotEmpty()
        mediaBadge.text = if (tab.media.size > 99) "99+" else tab.media.size.toString()
        if (!video && videoSheet.isVisible) hideVideoSheet()
        syncAddress()
    }

    private fun syncAddress() {
        if (addressFocused) return
        val tab = current ?: return
        val text = if (tab.showHome) "" else BrowserUrl.host(tab.url)
        if (address.text.toString() != text) address.setText(text)
    }

    private fun updateAddressHint() {
        address.hint = if (current?.isPrivate == true) "Search privately or type a web address" else "Search or type a web address"
    }

    private fun setImmersive(on: Boolean) {
        immersive = on
        topArea.isVisible = !on
        progress.isVisible = false
        exitFull.isVisible = on
        hideSuggestions()
        hideMenu()
        hideFind()
        hideVideoSheet()
        videoFab.isVisible = false
        if (on) {
            address.clearFocus()
        } else {
            resetToolbar()
            updateChrome()
        }
        act.setBottomNavVisible(!on)
        try {
            val controller = WindowCompat.getInsetsController(act.window, act.window.decorView)
            if (on) {
                controller.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
                controller.hide(WindowInsetsCompat.Type.systemBars())
            } else {
                controller.show(WindowInsetsCompat.Type.systemBars())
            }
        } catch (_: Exception) {
            Hb.applySystemBars(act)
        }
    }

    // ------------------------------------------------------------------ toolbar motion

    private fun resetToolbar() {
        if (immersive) return
        toolbarAnimator?.cancel()
        toolbarAnimator = null
        toolbarHidden = false
        topArea.visibility = View.VISIBLE
        topArea.translationY = 0f
        val lp = topArea.layoutParams as? LinearLayout.LayoutParams ?: return
        val full = Hb.dp(act, TOOLBAR_HEIGHT_DP)
        if (lp.height != full) {
            lp.height = full
            topArea.layoutParams = lp
        }
    }

    private fun setToolbarVisible(visible: Boolean) {
        if (immersive || toolbarHidden == !visible) return
        toolbarHidden = !visible
        val full = Hb.dp(act, TOOLBAR_HEIGHT_DP)
        toolbarAnimator?.cancel()
        val start = topArea.height
        topArea.visibility = View.VISIBLE
        val animator = ValueAnimator.ofInt(start, if (visible) full else 0)
        animator.duration = 180
        animator.addUpdateListener { value ->
            val h = value.animatedValue as Int
            val lp = topArea.layoutParams as? LinearLayout.LayoutParams ?: return@addUpdateListener
            lp.height = h
            topArea.layoutParams = lp
            topArea.translationY = -(full - h).toFloat()
        }
        animator.addListener(object : AnimatorListenerAdapter() {
            override fun onAnimationEnd(animation: Animator) {
                val lp = topArea.layoutParams as? LinearLayout.LayoutParams
                if (!visible) {
                    topArea.visibility = View.INVISIBLE
                    topArea.translationY = 0f
                    if (lp != null) {
                        lp.height = 0
                        topArea.layoutParams = lp
                    }
                } else {
                    topArea.visibility = View.VISIBLE
                    topArea.translationY = 0f
                }
            }
        })
        animator.start()
        toolbarAnimator = animator
    }

    private fun onWebScroll(scrollY: Int) {
        val tab = current ?: return
        if (tab.showHome || immersive || addressFocused) return
        val delta = scrollY - tab.lastScroll
        tab.lastScroll = scrollY
        val threshold = Hb.dp(act, 8)
        if (scrollY <= Hb.dp(act, 4)) {
            if (toolbarHidden) setToolbarVisible(true)
            return
        }
        if (delta > threshold && scrollY > Hb.dp(act, 72) && !toolbarHidden) {
            setToolbarVisible(false)
        } else if (delta < -threshold && toolbarHidden) {
            setToolbarVisible(true)
        }
    }

    private fun captureThumb(tab: Tab) {
        if (tab.isPrivate) return
        val web = tab.web ?: return
        if (web.width <= 0 || web.height <= 0) return
        try {
            val width = Hb.dp(act, 150)
            val height = (width.toFloat() * web.height / web.width).toInt()
                .coerceIn(Hb.dp(act, 40), Hb.dp(act, 260))
            val bmp = Bitmap.createBitmap(width, height, Bitmap.Config.RGB_565)
            web.draw(Canvas(bmp))
            val old = tab.thumbnail
            tab.thumbnail = bmp
            old?.recycle()
        } catch (_: Exception) {
        }
    }

    private fun showSiteInfo() {
        val tab = current ?: return
        if (tab.showHome) {
            address.requestFocus()
            return
        }
        val secure = tab.url.startsWith("https://", true)
        Hb.alert(
            act,
            if (secure) "Connection is secure" else "Not secure",
            "${BrowserUrl.host(tab.url)}\n\n${tab.url}\n\n" +
                if (secure) "This page uses HTTPS. Invalid security certificates are blocked."
                else "This page does not use HTTPS. Avoid entering passwords here."
        )
    }

    private fun hideKeyboard(view: View) {
        try {
            (act.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager)
                .hideSoftInputFromWindow(view.windowToken, 0)
        } catch (_: Exception) {
        }
    }

    // ------------------------------------------------------------------ menu actions

    private fun showMenu() {
        val tab = current ?: return
        hideSuggestions()
        address.clearFocus()
        resetToolbar()
        menuOverlay.removeAllViews()
        menuOverlay.setBackgroundColor(0x99000000.toInt())
        menuOverlay.setOnClickListener { hideMenu() }
        menuOverlay.isVisible = true

        val sheet = LinearLayout(act).apply {
            orientation = LinearLayout.VERTICAL
            background = Hb.round(act, 22, cSurface, cBorder, 1)
            setPadding(Hb.dp(act, 8), Hb.dp(act, 6), Hb.dp(act, 8), Hb.dp(act, 12))
            elevation = Hb.dp(act, 18).toFloat()
            setOnClickListener { }
        }
        sheet.addView(View(act).apply {
            background = Hb.round(act, 2, cBorder)
            layoutParams = LinearLayout.LayoutParams(Hb.dp(act, 36), Hb.dp(act, 4)).apply {
                gravity = Gravity.CENTER_HORIZONTAL
                topMargin = Hb.dp(act, 4)
                bottomMargin = Hb.dp(act, 4)
            }
        })

        val bookmarked = !tab.showHome && BrowserStore.isBookmarked(act, tab.url)
        val web = tab.web
        val iconRow = LinearLayout(act).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(0, Hb.dp(act, 4), 0, Hb.dp(act, 6))
        }
        iconRow.addView(menuAction(R.drawable.ic_back, "Back", enabled = web?.canGoBack() == true) {
            if (web?.canGoBack() == true) web.goBack()
            hideMenu()
        }, weight())
        iconRow.addView(menuAction(R.drawable.ic_forward, "Forward", enabled = web?.canGoForward() == true) {
            if (web?.canGoForward() == true) web.goForward()
            hideMenu()
        }, weight())
        iconRow.addView(menuAction(
            R.drawable.ic_star,
            if (bookmarked) "Saved" else "Save",
            enabled = !tab.showHome,
            active = bookmarked
        ) {
            hideMenu()
            toggleBookmark()
        }, weight())
        iconRow.addView(menuAction(R.drawable.ic_download, "Downloads") {
            hideMenu()
            act.startActivity(Intent(act, BrowserDownloadsActivity::class.java))
        }, weight())
        iconRow.addView(menuAction(R.drawable.ic_refresh, "Refresh") {
            hideMenu()
            if (web != null) {
                if (web.progress < 100) web.stopLoading() else web.reload()
            }
        }, weight())
        sheet.addView(iconRow, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
        ))

        sheet.addView(View(act).apply {
            setBackgroundColor(cBorder)
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, Hb.dp(act, 1)
            ).apply {
                marginStart = Hb.dp(act, 10)
                marginEnd = Hb.dp(act, 10)
                bottomMargin = Hb.dp(act, 4)
            }
        })

        val list = LinearLayout(act).apply { orientation = LinearLayout.VERTICAL }
        fun row(iconRes: Int, label: String, checked: Boolean = false, value: String? = null,
                enabled: Boolean = true, onTap: () -> Unit) {
            list.addView(menuRow(iconRes, label, checked, value, enabled) {
                hideMenu()
                onTap()
            }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, Hb.dp(act, 46)))
        }

        row(R.drawable.ic_browser, "New tab") { newTab(false) }
        row(R.drawable.ic_lock, "New incognito tab") { newTab(true) }
        row(R.drawable.ic_history, "History") {
            act.startActivity(Intent(act, BrowserHistoryActivity::class.java))
        }
        row(R.drawable.ic_download, "Downloads") {
            act.startActivity(Intent(act, BrowserDownloadsActivity::class.java))
        }
        row(R.drawable.ic_star, "Bookmarks") {
            act.startActivity(Intent(act, BrowserBookmarksActivity::class.java))
        }
        row(R.drawable.ic_share, "Share",
            enabled = !tab.showHome && BrowserUrl.isHttp(tab.url)) {
            Launcher.shareText(act, tab.url, "Share link")
        }
        row(R.drawable.ic_search, if (findBar.isVisible) "Close find bar" else "Find in page") {
            if (findBar.isVisible) hideFind() else showFind()
        }
        row(R.drawable.ic_grid, "Desktop site", checked = tab.desktop) { toggleDesktop() }
        row(R.drawable.ic_text, "Reader mode", checked = tab.reader,
            enabled = !tab.showHome) { toggleReader() }
        row(R.drawable.ic_dark, "Dark mode", checked = tab.dark) { toggleDark() }
        row(R.drawable.ic_text, "Text size", value = "${Prefs.browserTextZoom(act)}%") {
            textSizeDialog()
        }
        row(R.drawable.ic_search, "Search engine", value = engine().label) { engineDialog() }
        row(R.drawable.ic_home, "Home page", value = BrowserUrl.host(Prefs.browserHome(act))) {
            homeDialog()
        }
        row(R.drawable.ic_fullscreen, if (immersive) "Exit full screen" else "Full screen") {
            setImmersive(!immersive)
        }
        row(R.drawable.ic_lock, "Website permissions") { showPermissionInfo() }
        row(R.drawable.ic_lock, "Private browsing info") { showPrivateInfo() }
        row(R.drawable.ic_delete, "Clear cookies & cache") { clearDataDialog() }
        row(R.drawable.ic_settings, "Settings") { act.openSettings() }

        val scroll = ScrollView(act).apply { isFillViewport = true }
        scroll.addView(list)
        sheet.addView(scroll, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f
        ))

        val height = (act.resources.displayMetrics.heightPixels * 0.72f).toInt()
        menuOverlay.addView(sheet, FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, height, Gravity.BOTTOM
        ))
    }

    private fun hideMenu() {
        menuOverlay.isVisible = false
        menuOverlay.setOnClickListener(null)
        menuOverlay.removeAllViews()
    }

    private fun menuAction(
        iconRes: Int,
        label: String,
        enabled: Boolean = true,
        active: Boolean = false,
        onTap: () -> Unit
    ): LinearLayout = LinearLayout(act).apply {
        orientation = LinearLayout.VERTICAL
        gravity = Gravity.CENTER
        alpha = if (enabled) 1f else 0.4f
        setPadding(0, Hb.dp(act, 6), 0, Hb.dp(act, 6))
        addView(Hb.icon(act, iconRes, if (active) p.warning else cMuted, 21))
        addView(Hb.text(act, label, 9.5f, if (active) p.warning else cMuted, medium = true).apply {
            gravity = Gravity.CENTER
            setPadding(0, Hb.dp(act, 5), 0, 0)
        })
        if (enabled) Hb.clickable(this, onTap)
    }

    private fun menuRow(
        iconRes: Int,
        label: String,
        checked: Boolean = false,
        value: String? = null,
        enabled: Boolean = true,
        onTap: () -> Unit
    ): LinearLayout = LinearLayout(act).apply {
        orientation = LinearLayout.HORIZONTAL
        gravity = Gravity.CENTER_VERTICAL
        setPadding(Hb.dp(act, 10), 0, Hb.dp(act, 12), 0)
        alpha = if (enabled) 1f else 0.45f
        addView(Hb.icon(act, iconRes, cMuted, 20),
            LinearLayout.LayoutParams(Hb.dp(act, 20), Hb.dp(act, 20)).apply {
                marginEnd = Hb.dp(act, 14)
            })
        addView(Hb.text(act, label, 14f, cText),
            LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        if (!value.isNullOrBlank()) {
            addView(Hb.text(act, value, 12f, cMuted).apply {
                maxLines = 1
                ellipsize = TextUtils.TruncateAt.END
                setPadding(Hb.dp(act, 8), 0, 0, 0)
            })
        }
        if (checked) {
            addView(Hb.icon(act, R.drawable.ic_check, cAccent, 18),
                LinearLayout.LayoutParams(Hb.dp(act, 18), Hb.dp(act, 18)).apply {
                    marginStart = Hb.dp(act, 8)
                })
        }
        if (enabled) Hb.clickable(this, onTap)
    }

    private fun toggleDesktop() {
        val tab = current ?: return
        tab.desktop = !tab.desktop
        tab.web?.settings?.userAgentString = if (tab.desktop) DESKTOP_UA else null
        tab.web?.reload()
        Hb.toast(act, if (tab.desktop) "Desktop site requested" else "Mobile site")
        updateChrome()
    }

    private fun toggleDark() {
        val tab = current ?: return
        tab.dark = !tab.dark
        applyDark(tab)
        tab.web?.reload()
        Hb.toast(act, if (tab.dark) "Dark mode on" else "Dark mode off")
    }

    private fun applyDark(tab: Tab) {
        val web = tab.web ?: return
        try {
            if (WebViewFeature.isFeatureSupported(WebViewFeature.ALGORITHMIC_DARKENING)) {
                WebSettingsCompat.setAlgorithmicDarkeningAllowed(web.settings, tab.dark)
                return
            }
        } catch (_: Exception) {
        }
        if (tab.dark) {
            web.evaluateJavascript(DARK_JS, null)
        } else {
            web.evaluateJavascript("(function(){var e=document.getElementById('hb-dark');if(e)e.remove();})()", null)
        }
    }

    private fun textSizeDialog() {
        val values = intArrayOf(80, 100, 120, 150, 180)
        val labels = arrayOf("Small (80%)", "Normal (100%)", "Large (120%)", "Extra large (150%)", "Huge (180%)")
        AlertDialog.Builder(act, R.style.HbDialog)
            .setTitle("Text size")
            .setItems(labels) { _, which ->
                Prefs.setBrowserTextZoom(act, values[which])
                current?.web?.settings?.textZoom = values[which]
                Hb.toast(act, "Text size set to ${values[which]}%")
            }
            .show()
    }

    private fun engineDialog() {
        val engines = SearchEngine.entries
        val labels = engines.map { if (it.id == Prefs.searchEngine(act)) "${it.label} ✓" else it.label }.toTypedArray()
        AlertDialog.Builder(act, R.style.HbDialog)
            .setTitle("Search engine")
            .setItems(labels) { _, which ->
                Prefs.setSearchEngine(act, engines[which].id)
                updateAddressHint()
                refreshHome()
                Hb.toast(act, "Searches now use ${engines[which].label}")
            }
            .show()
    }

    private fun homeDialog() {
        Hb.input(act, "Home page", "https://…", Prefs.browserHome(act)) { value ->
            val url = BrowserUrl.normalize(value, Prefs.searchEngine(act))
            if (!BrowserUrl.isHttp(url)) {
                Hb.toast(act, "Enter a web address")
                return@input
            }
            Prefs.setBrowserHome(act, url)
            Hb.toast(act, "Home page saved")
        }
    }

    private fun showPermissionInfo() {
        Hb.alert(
            act,
            "Website permissions",
            "HB Browser blocks website camera, microphone and location requests. " +
                "File uploads always open Android's own file picker, and downloads ask before they start. " +
                "SSL certificate errors are never bypassed — the page is blocked instead."
        )
    }

    private fun showPrivateInfo() {
        Hb.alert(
            act,
            "Private browsing",
            "Private tabs do not save history or bookmarks, are never restored, and use no cache. " +
                "Android WebView shares one cookie jar for the whole app, so when your private session ends " +
                "HB Browser clears cookies, local storage and form data for the strongest isolation WebView " +
                "offers. This can sign you out of sites in normal tabs. Your private session ends when you " +
                "leave the Browser tab, close the last private tab, or exit the app. If the app is killed " +
                "while a private tab is open, its data is cleared the next time HB Browser starts."
        )
    }

    private fun clearDataDialog() {
        Hb.confirm(
            act,
            "Clear browser data?",
            "This removes cookies, cache, local storage and saved form data. History and bookmarks stay unless you clear them separately.",
            "Clear",
            destructive = true
        ) {
            clearAllBrowserData()
            Hb.toast(act, "Browser data cleared")
        }
    }

    private fun clearAllBrowserData() {
        try {
            CookieManager.getInstance().removeAllCookies(null)
            CookieManager.getInstance().flush()
        } catch (_: Exception) {
        }
        try {
            WebStorage.getInstance().deleteAllData()
        } catch (_: Exception) {
        }
        try {
            val db = WebViewDatabase.getInstance(act)
            db.clearFormData()
            db.clearHttpAuthUsernamePassword()
        } catch (_: Exception) {
        }
        tabs.forEach { tab ->
            tab.web?.clearCache(true)
            tab.web?.clearHistory()
            tab.web?.clearFormData()
        }
        current?.web?.reload()
    }

    private fun clearPrivateSessionData() {
        try {
            CookieManager.getInstance().removeAllCookies(null)
            CookieManager.getInstance().flush()
        } catch (_: Exception) {
        }
        try {
            WebStorage.getInstance().deleteAllData()
        } catch (_: Exception) {
        }
        try {
            WebViewDatabase.getInstance(act).clearFormData()
        } catch (_: Exception) {
        }
        tabs.forEach { it.web?.clearCache(true) }
    }

    private fun showFind() {
        findBar.isVisible = true
        findInput.requestFocus()
        (act.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager)
            .showSoftInput(findInput, InputMethodManager.SHOW_IMPLICIT)
    }

    private fun hideFind() {
        findBar.isVisible = false
        findInput.setText("")
        current?.web?.clearMatches()
    }

    private fun toggleBookmark() {
        val tab = current ?: return
        if (tab.showHome || !BrowserUrl.isHttp(tab.url)) {
            Hb.toast(act, "Open a page first")
            return
        }
        val existing = BrowserStore.bookmarks(act).firstOrNull { it.url == tab.url }
        if (existing != null) {
            Hb.confirm(act, "Remove bookmark?", existing.title.ifBlank { BrowserUrl.display(existing.url) }, "Remove", destructive = true) {
                BrowserStore.removeBookmark(act, existing.id)
                updateChrome()
                if (homeScroll.isVisible) refreshHome()
            }
            return
        }
        val save = {
            BrowserStore.addBookmark(act, tab.url, tab.title.ifBlank { BrowserUrl.display(tab.url) })
            Hb.toast(act, "Bookmark saved")
            updateChrome()
            if (homeScroll.isVisible) refreshHome()
        }
        if (tab.isPrivate) {
            Hb.confirm(act, "Save bookmark?", "This private page will be saved to your bookmarks. Only do this if you want it kept.", "Save") {
                save()
            }
        } else {
            save()
        }
    }

    // ------------------------------------------------------------------ reader

    private fun toggleReader() {
        val tab = current ?: return
        val web = tab.web ?: return
        if (tab.showHome) {
            Hb.toast(act, "Open a page first")
            return
        }
        if (tab.reader) {
            tab.reader = false
            tab.readerLoading = false
            val back = tab.readerUrl ?: tab.url
            tab.readerUrl = null
            web.loadUrl(back)
            updateChrome()
            return
        }
        val js = """
            (function(){
              try {
                var a = document.querySelector('article') || document.querySelector('main') || document.body;
                var text = (a && a.innerText) ? a.innerText : '';
                text = text.replace(/\n{4,}/g, '\n\n\n');
                return JSON.stringify({title: document.title || '', text: text});
              } catch(e) { return JSON.stringify({title:'', text:''}); }
            })()
        """.trimIndent()
        web.evaluateJavascript(js) { raw ->
            if (raw.isNullOrBlank() || raw == "null") {
                Hb.toast(act, "Reader mode is not available on this page")
                return@evaluateJavascript
            }
            try {
                val decoded = JSONTokener(raw).nextValue() as? String ?: raw
                val obj = JSONObject(decoded)
                val text = obj.optString("text")
                if (text.length < 180) {
                    Hb.toast(act, "Reader mode could not find enough text on this page")
                    return@evaluateJavascript
                }
                val title = obj.optString("title").ifBlank { tab.title }
                tab.readerUrl = tab.url
                tab.reader = true
                tab.readerLoading = true
                val html = readerHtml(title, tab.url, text)
                web.loadDataWithBaseURL(BrowserUrl.origin(tab.url), html, "text/html", "UTF-8", null)
                updateChrome()
                Hb.toast(act, "Reader mode on")
            } catch (_: Exception) {
                Hb.toast(act, "Reader mode is not available on this page")
            }
        }
    }

    private fun readerHtml(title: String, url: String, text: String): String {
        val bg = if (p.isDark) "#0B1220" else "#FFFFFF"
        val fg = if (p.isDark) "#E8EEF9" else "#0B1220"
        val muted = if (p.isDark) "#93A1B8" else "#5B6577"
        val accent = if (p.isDark) "#2E9BFF" else "#1476FF"
        val paragraphs = text.split(Regex("\\n{2,}")).take(400).joinToString("") { para ->
            val clean = para.trim()
            if (clean.isEmpty()) "" else "<p>${TextUtils.htmlEncode(clean)}</p>"
        }
        val fontPct = Prefs.readerFont(act)
        return """
            <!DOCTYPE html><html><head><meta charset="utf-8">
            <meta name="viewport" content="width=device-width, initial-scale=1">
            <style>
              body{margin:0;padding:22px 20px 60px;background:$bg;color:$fg;
                font-family:'serif','Noto Serif',Georgia,serif;line-height:1.72;font-size:${fontPct}%;}
              h1{font-family:'sans-serif';font-size:1.55em;line-height:1.25;letter-spacing:-.01em;margin:0 0 10px;}
              .src{font-family:'sans-serif';font-size:.72em;color:$muted;margin-bottom:26px;word-break:break-all;}
              .tag{display:inline-block;font-family:'sans-serif';font-size:.62em;letter-spacing:.14em;
                color:$accent;border:1px solid $accent;border-radius:30px;padding:3px 9px;margin-bottom:16px;}
              p{margin:0 0 1.15em;}
            </style></head><body>
            <div class="tag">READER MODE</div>
            <h1>${TextUtils.htmlEncode(title)}</h1>
            <div class="src">${TextUtils.htmlEncode(url)}</div>
            $paragraphs
            </body></html>
        """.trimIndent()
    }

    // ------------------------------------------------------------------ long press

    private fun handleLongPress(tab: Tab, web: WebView): Boolean {
        val hit = web.hitTestResult
        val url = hit?.extra
        val type = hit?.type ?: WebView.HitTestResult.UNKNOWN_TYPE
        if (url != null && BrowserUrl.isHttp(url)) {
            when (type) {
                WebView.HitTestResult.SRC_ANCHOR_TYPE,
                WebView.HitTestResult.SRC_IMAGE_ANCHOR_TYPE,
                WebView.HitTestResult.IMAGE_TYPE -> {
                    showLinkMenu(tab, url, type == WebView.HitTestResult.IMAGE_TYPE)
                    return true
                }
            }
        }
        // A video element has no hit-test type of its own: ask the page what is under the finger.
        if (type == WebView.HitTestResult.EDIT_TEXT_TYPE) return false
        findVideoAtPoint(web) { target ->
            if (target != null && current === tab) {
                showVideoSheetFor(tab.url, target)
            }
        }
        return false
    }

    /** elementFromPoint + closest('video'): returns the permalink or a plain media URL under the finger. */
    private fun findVideoAtPoint(web: WebView, onResult: (String?) -> Unit) {
        if (!bridgeAllows(web.url ?: "")) {
            onResult(null)
            return
        }
        val density = act.resources.displayMetrics.density
        val x = (lastTouchX / density).toInt()
        val y = (lastTouchY / density).toInt()
        val js = """
            (function(){
              try {
                var PERM = /(\/watch|\/shorts\/|\/reel\/|\/reels\/|\/p\/|\/tv\/|\/video\/|\/videos\/|\/share\/[vr]\/)/i;
                var e = document.elementFromPoint($x, $y);
                var v = e ? e.closest('video') : null;
                if (!v) {
                  var vs = document.querySelectorAll('video');
                  for (var i = 0; i < vs.length; i++) {
                    var r = vs[i].getBoundingClientRect();
                    if ($x >= r.left && $x <= r.right && $y >= r.top && $y <= r.bottom) { v = vs[i]; break; }
                  }
                }
                if (!v) return '';
                var src = v.currentSrc || v.src || '';
                if (/^https?:/i.test(src) && /\.(mp4|m3u8|webm|mpd)(\?|#|$)/i.test(src)) return src;
                var a = v.closest('a[href]');
                while (a) {
                  var h = a.getAttribute('href') || '';
                  if (PERM.test(h)) {
                    var abs = new URL(h, location.href);
                    return (abs.protocol === 'http:' || abs.protocol === 'https:') ? abs.href : '';
                  }
                  a = a.parentElement ? a.parentElement.closest('a[href]') : null;
                }
                return PERM.test(location.href) ? location.href : '';
              } catch(err) { return ''; }
            })()
        """.trimIndent()
        try {
            web.evaluateJavascript(js) { raw ->
                val value = try {
                    val decoded = JSONTokener(raw ?: "").nextValue() as? String
                    decoded?.takeIf { BrowserUrl.isHttp(it) }
                } catch (_: Exception) {
                    null
                }
                onResult(value)
            }
        } catch (_: Exception) {
            onResult(null)
        }
    }

    private fun showLinkMenu(tab: Tab, url: String, isImage: Boolean) {
        val items = ArrayList<Pair<String, () -> Unit>>()
        items.add("Open in new tab" to { newTab(false, url) })
        items.add("Open in incognito tab" to { newTab(true, url) })
        items.add("Open here" to { loadUrl(tab, url) })
        items.add("Copy link" to { Launcher.copy(act, url, "Link copied") })
        items.add("Share link" to { Launcher.shareText(act, url, "Share link") })
        if (isImage) items.add("Open image" to { loadUrl(tab, url) })
        else items.add("Download file" to {
            promptDownload(tab, url, tab.web?.settings?.userAgentString,
                null, BrowserDownloads.guessMime(url), 0)
        })
        if (isVideoPage(url)) {
            items.add("Download video" to { showVideoSheetFor(url, url) })
        }
        AlertDialog.Builder(act, R.style.HbDialog)
            .setTitle(BrowserUrl.host(url))
            .setItems(items.map { it.first }.toTypedArray()) { _, which -> items[which].second() }
            .show()
    }

    // ------------------------------------------------------------------ video download

    /** Called for every request a page makes (background thread). Only plain media files are kept. */
    private fun sniffMedia(tab: Tab, uri: Uri) {
        val scheme = uri.scheme?.lowercase() ?: return
        if (scheme != "http" && scheme != "https") return
        val path = uri.path?.lowercase() ?: return
        if (MEDIA_EXT.none { path.endsWith(it) }) return
        val url = uri.toString()
        if (url.length > 2000) return
        if (tab.media.contains(url)) return
        if (tab.media.size >= 30) return
        tab.media.add(url)
        act.runOnUiThread {
            if (current === tab && !tab.showHome) {
                videoFab.isVisible = !immersive
                mediaBadge.isVisible = true
                mediaBadge.text = if (tab.media.size > 99) "99+" else tab.media.size.toString()
            }
        }
    }

    private fun mediaLabel(url: String): String {
        val name = try {
            Uri.parse(url).lastPathSegment ?: ""
        } catch (_: Exception) {
            ""
        }
        val clean = Uri.decode(name).substringBefore('?').ifBlank { BrowserUrl.host(url) }
        return if (clean.length > 42) clean.take(39) + "..." else clean
    }

    private fun mediaExt(url: String): String =
        MEDIA_EXT.firstOrNull { url.lowercase().substringBefore('?').endsWith(it) }
            ?.removePrefix(".")?.uppercase() ?: "LINK"

    private fun isVideoPage(url: String): Boolean {
        if (!BrowserUrl.isHttp(url)) return false
        val u = url.lowercase()
        return when (Site.detect(url)) {
            Site.YOUTUBE -> "watch?v=" in u || "/shorts/" in u || "youtu.be/" in u ||
                "/live/" in u || "/embed/" in u
            Site.INSTAGRAM -> "/reel/" in u || "/reels/" in u || "/p/" in u || "/tv/" in u
            Site.TIKTOK -> "/video/" in u || "vm.tiktok.com" in u || "vt.tiktok.com" in u
            Site.FACEBOOK -> "/watch" in u || "/reel" in u || "/videos/" in u ||
                "/share/v/" in u || "/share/r/" in u
            Site.X -> "/status/" in u || "/i/status/" in u
            Site.REDDIT -> "/comments/" in u || "v.redd.it" in u
            Site.VIMEO -> Regex("vimeo\\.com/(channels/[^/]+/|groups/[^/]+/videos/)?\\d+").containsMatchIn(u)
            Site.DAILYMOTION -> "/video/" in u || "dai.ly/" in u
            Site.PINTEREST -> "/pin/" in u
            Site.SNAPCHAT -> "/spotlight/" in u || "snapchat.com/p/" in u
            Site.THREADS -> "/post/" in u || "/t/" in u
            Site.TWITCH -> "/videos/" in u || "/clip/" in u || "/collections/" in u || "/schedule" in u
            Site.LIKEE -> "/v/" in u || "likee.video/" in u
            Site.LINKEDIN -> "/posts/" in u || "/feed/update/" in u || "/video/" in u
            Site.OTHER -> false
        }
    }

    /** Channels, profiles and playlists where "Download all" makes sense. */
    private fun isPlaylistPage(url: String): Boolean {
        if (!BrowserUrl.isHttp(url)) return false
        val u = url.lowercase()
        return when (Site.detect(url)) {
            Site.YOUTUBE -> "list=" in u || Regex("youtube\\.com/(@|c/|channel/|user/|playlist)").containsMatchIn(u)
            Site.INSTAGRAM -> Regex("instagram\\.com/[a-z0-9_.]+/?$").containsMatchIn(u)
            Site.TIKTOK -> Regex("tiktok\\.com/@[^/?]+/?$").containsMatchIn(u)
            Site.FACEBOOK -> "/videos" in u || "/reels" in u
            Site.VIMEO -> Regex("vimeo\\.com/(channels|groups|user\\d+|@)").containsMatchIn(u)
            Site.DAILYMOTION -> Regex("dailymotion\\.com/[a-z0-9_.-]+/?$").containsMatchIn(u)
            Site.TWITCH -> "/videos" in u
            else -> false
        }
    }

    private fun bridgeHosts(): Set<String> = setOf(
        "https://youtube.com", "https://*.youtube.com",
        "https://youtu.be", "https://*.youtu.be",
        "https://instagram.com", "https://*.instagram.com",
        "https://facebook.com", "https://*.facebook.com",
        "https://fb.watch", "https://*.fb.watch",
        "https://tiktok.com", "https://*.tiktok.com",
        "https://x.com", "https://*.x.com",
        "https://twitter.com", "https://*.twitter.com",
        "https://reddit.com", "https://*.reddit.com",
        "https://vimeo.com", "https://*.vimeo.com",
        "https://dailymotion.com", "https://*.dailymotion.com",
        "https://pinterest.com", "https://*.pinterest.com",
        "https://snapchat.com", "https://*.snapchat.com",
        "https://threads.net", "https://*.threads.net",
        "https://threads.com", "https://*.threads.com",
        "https://twitch.tv", "https://*.twitch.tv",
        "https://likee.video", "https://*.likee.video",
        "https://linkedin.com", "https://*.linkedin.com"
    )

    private fun bridgeAllows(url: String): Boolean {
        val host = BrowserUrl.host(url).lowercase()
        if (host == "youtu.be" || host == "fb.watch") return true
        return BRIDGE_SITES.any { host == it || host.endsWith(".$it") }
    }

    private fun allowBridgeMessage(): Boolean {
        val now = System.currentTimeMillis()
        if (now - bridgeWindow > 2000L) {
            bridgeWindow = now
            bridgeCount = 0
        }
        bridgeCount++
        return bridgeCount <= 4
    }

    private fun setupVideoBridge(web: WebView, tab: Tab) {
        try {
            if (!WebViewFeature.isFeatureSupported(WebViewFeature.WEB_MESSAGE_LISTENER)) return
            WebViewCompat.addWebMessageListener(
                web,
                BRIDGE,
                bridgeHosts()
            ) { _, message: WebMessageCompat, origin: Uri, isMainFrame: Boolean, _ ->
                if (!isMainFrame) return@addWebMessageListener
                if (origin.scheme != "https") return@addWebMessageListener
                val raw = message.data ?: return@addWebMessageListener
                if (raw.length > 4000 || !allowBridgeMessage()) return@addWebMessageListener
                try {
                    val obj = JSONObject(raw)
                    if (obj.optString("type") != "video") return@addWebMessageListener
                    val url = obj.optString("url")
                    val referer = obj.optString("referer").ifBlank { tab.url }
                    if (!BrowserUrl.isHttp(url)) return@addWebMessageListener
                    act.runOnUiThread {
                        if (current === tab && !tab.showHome) showVideoSheetFor(referer, url)
                    }
                } catch (_: Exception) {
                }
            }
        } catch (_: Exception) {
        }
    }

    private fun injectVideoButtons(web: WebView, url: String) {
        if (!bridgeAllows(url)) return
        try {
            web.evaluateJavascript(VIDEO_JS, null)
        } catch (_: Exception) {
        }
    }

    private fun showVideoSheet() {
        val tab = current ?: return
        if (tab.showHome) return
        if (!isVideoPage(tab.url) && tab.media.isEmpty()) return
        showVideoSheetFor(tab.url, tab.url)
    }

    private fun showVideoSheetFor(pageUrl: String, targetUrl: String) {
        if (!BrowserUrl.isHttp(targetUrl)) return
        hideSuggestions()
        address.clearFocus()
        videoReferer = pageUrl
        videoSheet.removeAllViews()
        videoSheet.setBackgroundColor(0x99000000.toInt())
        videoSheet.setOnClickListener { hideVideoSheet() }
        videoSheet.isVisible = true

        val sheet = LinearLayout(act).apply {
            orientation = LinearLayout.VERTICAL
            background = Hb.round(act, 22, cSurface, cBorder, 1)
            setPadding(Hb.dp(act, 16), Hb.dp(act, 10), Hb.dp(act, 16), Hb.dp(act, 16))
            setOnClickListener { }
            elevation = Hb.dp(act, 18).toFloat()
        }
        sheet.addView(View(act).apply {
            background = Hb.round(act, 2, cBorder)
            layoutParams = LinearLayout.LayoutParams(Hb.dp(act, 36), Hb.dp(act, 4)).apply {
                gravity = Gravity.CENTER_HORIZONTAL
                topMargin = Hb.dp(act, 4)
                bottomMargin = Hb.dp(act, 8)
            }
        })
        sheet.addView(Hb.text(act, if (isVideoPage(targetUrl)) "Download video" else "Download", 17f, cText, bold = true))
        sheet.addView(Hb.text(act, "${Site.detect(pageUrl).label} • ${BrowserUrl.host(pageUrl)}", 11.5f, cMuted).apply {
            setPadding(0, Hb.dp(act, 3), 0, Hb.dp(act, 10))
        })
        val found = current?.media?.let { m -> synchronized(m) { m.toList() } }.orEmpty()
        if (isVideoPage(targetUrl)) {
            sheet.addView(videoOption(R.drawable.ic_download, "Video", "Choose quality before download", "Video") {
                startVideoDownload(targetUrl, false, pickQuality = true)
            })
            sheet.addView(videoOption(R.drawable.ic_music, "Audio only", "MP3 sound track", "MP3") {
                startVideoDownload(targetUrl, true)
            })
            if (isPlaylistPage(pageUrl)) {
                sheet.addView(videoOption(R.drawable.ic_folder, "Download all", "Every video on this page", "Playlist") {
                    startVideoDownload(pageUrl, false, playlist = true)
                })
            }
        } else {
            sheet.addView(videoOption(R.drawable.ic_download, "Download file", mediaLabel(targetUrl), mediaExt(targetUrl)) {
                startVideoDownload(targetUrl, false)
            })
        }
        sheet.addView(videoOption(R.drawable.ic_link, "Copy link", "Copy this video address", null) {
            Launcher.copy(act, targetUrl, "Link copied")
            hideVideoSheet()
        })
        if (found.isNotEmpty()) {
            sheet.addView(Hb.text(act, "Video files found on this page", 11.5f, cMuted).apply {
                setPadding(Hb.dp(act, 4), Hb.dp(act, 4), 0, Hb.dp(act, 6))
            })
            found.filter { it != targetUrl }.take(5).forEach { link ->
                sheet.addView(videoOption(R.drawable.ic_link, mediaLabel(link), BrowserUrl.host(link), mediaExt(link)) {
                    startVideoDownload(link, false)
                })
            }
        }
        videoSheet.addView(sheet, FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT,
            Gravity.BOTTOM
        ))
    }

    private fun videoOption(
        iconRes: Int,
        title: String,
        sub: String,
        badge: String?,
        onTap: () -> Unit
    ): LinearLayout = LinearLayout(act).apply {
        orientation = LinearLayout.HORIZONTAL
        gravity = Gravity.CENTER_VERTICAL
        background = Hb.round(act, 14, cAlt, cBorder, 1)
        setPadding(Hb.dp(act, 12), Hb.dp(act, 11), Hb.dp(act, 12), Hb.dp(act, 11))
        layoutParams = LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
        ).apply { bottomMargin = Hb.dp(act, 8) }
        addView(Hb.iconCircle(act, iconRes, cAccent, cSoft, 38))
        val texts = LinearLayout(act).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(Hb.dp(act, 12), 0, 0, 0)
        }
        texts.addView(Hb.text(act, title, 14f, cText, medium = true))
        texts.addView(Hb.text(act, sub, 11f, cMuted).apply {
            setPadding(0, Hb.dp(act, 2), 0, 0)
        })
        addView(texts, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        if (badge != null) {
            addView(Hb.text(act, badge, 10f, cAccent, medium = true).apply {
                setPadding(Hb.dp(act, 8), Hb.dp(act, 4), Hb.dp(act, 8), Hb.dp(act, 4))
                background = Hb.round(act, 20, cSoft)
            })
        }
        Hb.clickable(this, onTap)
        Hb.pressScale(this)
    }

    private fun startVideoDownload(
        url: String,
        audio: Boolean,
        pickQuality: Boolean = false,
        playlist: Boolean = false
    ) {
        if (!BrowserUrl.isHttp(url)) {
            Hb.toast(act, "This link cannot be downloaded")
            return
        }
        if (Updater.blockIfForced(act)) return
        if (DownloadTracker.isActive(url, audio)) {
            Hb.toast(act, "Already downloading this link")
            hideVideoSheet()
            return
        }
        val tab = current
        val referer = videoReferer ?: tab?.url?.takeIf { BrowserUrl.isHttp(it) }
        hideVideoSheet()
        if (tab?.isPrivate == true && Prefs.browserLoginDownloads(act)) {
            // A private tab's cookies are meant to disappear; ask before they leave the app.
            Hb.confirm(
                act,
                "Use private tab login?",
                "This private tab's cookies will be sent with the download so it can open this video. The cookie file is deleted as soon as the download ends.",
                "Download",
                "Cancel"
            ) {
                beginVideoDownload(url, audio, referer, pickQuality, playlist)
            }
        } else {
            beginVideoDownload(url, audio, referer, pickQuality, playlist)
        }
    }

    private fun beginVideoDownload(
        url: String,
        audio: Boolean,
        referer: String?,
        pickQuality: Boolean,
        playlist: Boolean
    ) {
        if (!pickQuality || audio || playlist) {
            launchVideoDownload(url, audio, referer, null, playlist)
            return
        }
        // Ask yt-dlp which heights this video really has; a picker of fake qualities helps nobody.
        val ua = current?.web?.settings?.userAgentString
        val cookies = writeCookiesFile(url)
        Hb.toast(act, "Checking available quality...")
        Thread {
            val heights = VideoFormats.heights(act, url, referer, ua, cookies)
            act.runOnUiThread {
                if (heights.isEmpty()) {
                    try {
                        if (cookies != null) File(cookies).delete()
                    } catch (_: Exception) {
                    }
                    launchVideoDownload(url, audio, referer, null, playlist)
                    return@runOnUiThread
                }
                val options = heights.sortedDescending()
                val labels = options.map { Quality.label(it) }.toTypedArray()
                val dialog = AlertDialog.Builder(act, R.style.HbDialog)
                    .setTitle("Video quality")
                    .setItems(labels) { _, which ->
                        launchVideoDownload(url, audio, referer, options[which], playlist)
                    }
                    .setOnCancelListener {
                        try {
                            if (cookies != null) File(cookies).delete()
                        } catch (_: Exception) {
                        }
                    }
                    .create()
                dialog.setOnDismissListener {
                    try {
                        if (cookies != null) File(cookies).delete()
                    } catch (_: Exception) {
                    }
                }
                dialog.show()
            }
        }.start()
    }

    private fun launchVideoDownload(
        url: String,
        audio: Boolean,
        referer: String?,
        height: Int?,
        playlist: Boolean
    ) {
        val ua = current?.web?.settings?.userAgentString
        val cookies = writeCookiesFile(url)
        try {
            ContextCompat.startForegroundService(
                act,
                Intent(act, DownloadService::class.java)
                    .putExtra(DownloadService.EXTRA_URL, url)
                    .putExtra(DownloadService.EXTRA_AUDIO, audio)
                    .putExtra(DownloadService.EXTRA_REFERER, referer)
                    .putExtra(DownloadService.EXTRA_UA, ua)
                    .putExtra(DownloadService.EXTRA_COOKIES, cookies)
                    .putExtra(DownloadService.EXTRA_HEIGHT, height ?: 0)
                    .putExtra(DownloadService.EXTRA_PLAYLIST, playlist)
            )
            Hb.toast(act, when {
                playlist -> "Downloading all videos on this page"
                audio -> "Audio download started"
                else -> "Video download started"
            })
        } catch (_: Exception) {
            try {
                if (cookies != null) File(cookies).delete()
            } catch (_: Exception) {
            }
            Hb.toast(act, "Could not start the download")
        }
    }

    /**
     * Writes the cookies WebView has for [url] into a Netscape cookies.txt inside cacheDir.
     * Only called when the "Use browser login for downloads" setting is on; never logged.
     */
    private fun writeCookiesFile(url: String): String? {
        if (!Prefs.browserLoginDownloads(act)) return null
        return try {
            val cookie = CookieManager.getInstance().getCookie(url)
            if (cookie.isNullOrBlank()) return null
            val host = Uri.parse(url).host ?: return null
            val sb = StringBuilder("# Netscape HTTP Cookie File\n")
            cookie.split(';').forEach { part ->
                val p = part.trim()
                val eq = p.indexOf('=')
                if (eq <= 1) return@forEach
                val name = p.substring(0, eq).trim().replace("\t", "").replace("\n", "")
                val value = p.substring(eq + 1).trim().replace("\t", "").replace("\n", "")
                if (name.isEmpty() || name.startsWith("#")) return@forEach
                sb.append(host).append('\t').append("TRUE").append('\t').append('/').append('\t')
                    .append("TRUE").append('\t').append("0").append('\t')
                    .append(name).append('\t').append(value).append('\n')
            }
            if (sb.lines().size <= 1) return null
            val dir = File(act.cacheDir, "dl_cookies").apply { mkdirs() }
            val f = File(dir, "c_" + UUID.randomUUID().toString().take(8) + ".txt")
            f.writeText(sb.toString())
            f.absolutePath
        } catch (_: Exception) {
            null
        }
    }

    private fun hideVideoSheet() {
        videoSheet.isVisible = false
        videoSheet.setOnClickListener(null)
        videoSheet.removeAllViews()
        videoReferer = null
    }

    // ------------------------------------------------------------------ downloads

    private fun promptDownload(tab: Tab, url: String, userAgent: String?, disposition: String?, mime: String?, length: Long) {
        if (Updater.blockIfForced(act)) return
        if (url.startsWith("blob:") || url.startsWith("data:")) {
            Hb.toast(act, "This file is created inside the page and cannot be downloaded by the browser")
            return
        }
        if (!BrowserUrl.isHttp(url)) {
            Hb.toast(act, "Only web links can be downloaded")
            return
        }
        if (BrowserDownloads.isDownloading(act, url)) {
            Hb.toast(act, "This file is already downloading")
            return
        }
        val name = BrowserDownloads.guessName(url, disposition, mime)
        val host = BrowserUrl.host(url)
        val size = if (length > 0) Fmt.bytes(length) else "Size unknown"
        Hb.confirm(act, "Download this file?", "$name\nFrom $host\n$size", "Download", "Cancel") {
            val id = BrowserDownloads.enqueue(
                act, url, userAgent, CookieManager.getInstance().getCookie(url), tab.url,
                mime, name, Prefs.wifiOnly(act), disposition
            )
            if (id != null) {
                Hb.toast(act, "Download started — open Downloads to see progress")
            }
        }
    }

    // ------------------------------------------------------------------ screen API

    override fun onShow() {
        refreshHome()
        current?.web?.onResume()
        BrowserDownloads.autoSaveCompleted(act)
        if (immersive) setImmersive(true) else resetToolbar()
        updateChrome()
    }

    override fun onHide() {
        saveSession()
        current?.web?.onPause()
        hideMenu()
        hideVideoSheet()
        hideSuggestions()
        if (immersive) setImmersive(false)
        if (tabs.any { it.isPrivate } && Prefs.clearPrivateOnExit(act)) {
            closePrivateTabs(false)
            Hb.toast(act, "Private session ended — data cleared")
        }
    }

    override fun onHostPause() {
        // An external activity, file picker or share sheet took focus. Keep the page and its
        // private tabs alive; private data is still wiped when the tab is closed or the app exits.
        saveSession()
        current?.web?.onPause()
        BrowserDownloads.autoSaveCompleted(act)
    }

    override fun onHostResume() {
        current?.web?.onResume()
        if (immersive) setImmersive(true)
    }

    override fun onBack(): Boolean {
        if (menuOverlay.isVisible) {
            hideMenu()
            return true
        }
        if (videoSheet.isVisible) {
            hideVideoSheet()
            return true
        }
        if (tabsOverlay.isVisible) {
            tabsOverlay.isVisible = false
            return true
        }
        if (suggestBox.isVisible) {
            hideSuggestions()
            address.clearFocus()
            return true
        }
        if (findBar.isVisible) {
            hideFind()
            return true
        }
        if (videoOverlay.isVisible) {
            customCallback?.onCustomViewHidden()
            return true
        }
        if (immersive) {
            setImmersive(false)
            return true
        }
        if (address.isFocused) {
            address.clearFocus()
            return true
        }
        val tab = current ?: return false
        if (tab.reader) {
            toggleReader()
            return true
        }
        val web = tab.web
        if (web != null && web.canGoBack()) {
            web.goBack()
            return true
        }
        if (!tab.showHome) {
            tab.showHome = true
            webHost.isVisible = false
            homeScroll.isVisible = true
            refreshHome()
            updateChrome()
            return true
        }
        return false
    }

    override fun refresh() {
        if (homeScroll.isVisible) refreshHome()
        BrowserDownloads.autoSaveCompleted(act)
        updateChrome()
    }

    fun dispose() {
        saveSession()
        toolbarAnimator?.cancel()
        hideMenu()
        hideVideoSheet()
        val hadPrivate = tabs.any { it.isPrivate }
        tabs.forEach { destroyWeb(it) }
        tabs.clear()
        if (hadPrivate && Prefs.clearPrivateOnExit(act)) clearPrivateSessionData()
        Prefs.setPrivateSessionOpen(act, false)
        act.setBottomNavVisible(true)
    }

    private fun saveSession() {
        // Leave a marker while a private tab is open so a crash cannot leave its cookies behind.
        Prefs.setPrivateSessionOpen(act, tabs.any { it.isPrivate })
        if (!Prefs.restoreTabs(act)) return
        val saved = tabs.filter { !it.isPrivate && BrowserUrl.isHttp(it.url) }.map { SavedTab(it.url, it.title) }
        BrowserStore.saveTabs(act, saved)
    }

    private companion object {
        const val DESKTOP_UA =
            "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36"

        const val TOOLBAR_ROW_DP = 58
        const val TOOLBAR_HEIGHT_DP = 60

        val INC_BG = 0xFF17141E.toInt()
        val INC_SURFACE = 0xFF221E2C.toInt()
        val INC_SURFACE_ALT = 0xFF2E283C.toInt()
        val INC_BORDER = 0xFF433A58.toInt()
        val INC_TEXT = 0xFFF2EEFF.toInt()
        val INC_MUTED = 0xFFA79FBC.toInt()
        val INC_ACCENT = 0xFF9C7BFF.toInt()
        val INC_SOFT = 0x2E9C7BFF

        val EXTERNAL_SCHEMES = setOf("tel", "mailto", "sms", "smsto", "market", "whatsapp", "geo", "maps")

        val MEDIA_EXT = listOf(".mp4", ".m3u8", ".mpd", ".webm")

        /** Hosts whose pages may talk to the video bridge (the only origins accepted by the listener). */
        val BRIDGE_SITES = setOf(
            "youtube.com", "youtu.be", "youtube-nocookie.com",
            "instagram.com", "facebook.com", "fb.watch", "tiktok.com",
            "x.com", "twitter.com", "reddit.com", "vimeo.com", "dailymotion.com",
            "pinterest.com", "pin.it", "snapchat.com", "threads.net", "threads.com",
            "twitch.tv", "likee.video", "linkedin.com"
        )

        const val BRIDGE = "HBVideoBridge"

        val VIDEO_JS = """
            (function(){
              if (window.__hbVideoHook) { try { window.__hbVideoHook.refresh(); } catch(e) {} return; }
              var PERM = /(\/watch|\/shorts\/|\/reel\/|\/reels\/|\/p\/|\/tv\/|\/video\/|\/videos\/|\/share\/[vr]\/)/i;
              function abs(u){
                try { var x = new URL(u, location.href); return (x.protocol === 'http:' || x.protocol === 'https:') ? x.href : ''; }
                catch(e) { return ''; }
              }
              function direct(u){
                if (!u || /^blob:|^data:/i.test(u)) return '';
                if (!/^https?:/i.test(u)) return '';
                return /\.(mp4|m3u8|webm|mpd)(\?|#|$)/i.test(u) ? u : '';
              }
              function permalink(el){
                try {
                  var a = el.closest('a[href]');
                  while (a) {
                    var h = a.getAttribute('href') || '';
                    if (PERM.test(h)) return abs(h);
                    a = a.parentElement ? a.parentElement.closest('a[href]') : null;
                  }
                  if (PERM.test(location.href)) return location.href;
                } catch(e) {}
                return '';
              }
              function post(url){
                try {
                  if (!url || !window.HBVideoBridge || !window.HBVideoBridge.postMessage) return;
                  window.HBVideoBridge.postMessage(JSON.stringify({
                    type: 'video', url: url, referer: location.href, title: document.title || ''
                  }));
                } catch(e) {}
              }
              function attach(v){
                try {
                  if (v.__hbBtn) return;
                  var host = v.parentElement;
                  if (!host) return;
                  if (getComputedStyle(host).position === 'static') host.style.position = 'relative';
                  var b = document.createElement('button');
                  b.type = 'button';
                  b.textContent = '\u2193';
                  b.setAttribute('aria-label', 'Download video');
                  b.style.cssText = 'position:absolute;right:10px;top:10px;z-index:2147483000;width:34px;height:34px;' +
                    'border-radius:50%;border:0;background:rgba(20,118,255,.95);color:#fff;font-size:18px;' +
                    'line-height:34px;padding:0;cursor:pointer;box-shadow:0 2px 8px rgba(0,0,0,.35);';
                  b.addEventListener('click', function(ev){
                    ev.preventDefault(); ev.stopPropagation();
                    post(permalink(v) || direct(v.currentSrc || v.src || ''));
                  }, true);
                  host.appendChild(b);
                  v.__hbBtn = b;
                } catch(e) {}
              }
              function refresh(){
                try {
                  var vs = document.querySelectorAll('video');
                  for (var i = 0; i < vs.length; i++) attach(vs[i]);
                } catch(e) {}
              }
              var timer = 0;
              function soon(){
                if (timer) return;
                timer = setTimeout(function(){ timer = 0; refresh(); }, 350);
              }
              try { new MutationObserver(soon).observe(document.documentElement, { childList: true, subtree: true }); } catch(e) {}
              window.__hbVideoHook = { refresh: refresh };
              refresh();
              setTimeout(refresh, 1200);
              setTimeout(refresh, 3000);
            })()
        """.trimIndent()

        data class QuickSite(val name: String, val url: String, val color: Int)

        val QUICK_SITES = listOf(
            QuickSite("YouTube", "https://m.youtube.com", 0xFFE53935.toInt()),
            QuickSite("Google", "https://www.google.com", 0xFF4285F4.toInt()),
            QuickSite("Facebook", "https://m.facebook.com", 0xFF1877F2.toInt()),
            QuickSite("WhatsApp", "https://web.whatsapp.com", 0xFF25D366.toInt()),
            QuickSite("Instagram", "https://www.instagram.com", 0xFFE1306C.toInt()),
            QuickSite("Wikipedia", "https://www.wikipedia.org", 0xFF636466.toInt()),
            QuickSite("TikTok", "https://www.tiktok.com", 0xFF010101.toInt()),
            QuickSite("X", "https://x.com", 0xFF111111.toInt()),
            QuickSite("Reddit", "https://www.reddit.com", 0xFFFF4500.toInt()),
            QuickSite("Vimeo", "https://vimeo.com", 0xFF1AB7EA.toInt()),
            QuickSite("Dailymotion", "https://www.dailymotion.com", 0xFF00AAFF.toInt()),
            QuickSite("Pinterest", "https://www.pinterest.com", 0xFFE60023.toInt()),
            QuickSite("Snapchat", "https://www.snapchat.com", 0xFFF5C518.toInt()),
            QuickSite("Threads", "https://www.threads.net", 0xFF101010.toInt()),
            QuickSite("Twitch", "https://www.twitch.tv", 0xFF9146FF.toInt()),
            QuickSite("Likee", "https://likee.video", 0xFFFF0066.toInt()),
            QuickSite("LinkedIn", "https://www.linkedin.com", 0xFF0A66C2.toInt()),
            QuickSite("GitHub", "https://github.com", 0xFF24292E.toInt()),
            QuickSite("ChatGPT", "https://chat.openai.com", 0xFF10A37F.toInt()),
            QuickSite("Daraz", "https://www.daraz.pk", 0xFFF57224.toInt()),
            QuickSite("BBC", "https://www.bbc.com", 0xFFBB1919.toInt())
        )

        val DARK_JS = """
            (function(){
              try{
                if(document.getElementById('hb-dark')) return;
                var s=document.createElement('style');
                s.id='hb-dark';
                s.innerHTML='html{background:#0b1220 !important;filter:invert(1) hue-rotate(180deg) !important}img,video,picture,canvas,svg{filter:invert(1) hue-rotate(180deg) !important}';
                (document.head||document.documentElement).appendChild(s);
              }catch(e){}
            })()
        """.trimIndent()

        val AD_HOSTS = listOf(
            "doubleclick.net", "googlesyndication.com", "googleadservices.com",
            "adservice.google.com", "google-analytics.com",
            "adsystem.com", "amazon-adsystem.com", "taboola.com", "outbrain.com", "criteo.com",
            "scorecardresearch.com", "adnxs.com", "quantserve.com", "moatads.com",
            "rubiconproject.com", "pubmatic.com", "openx.net", "casalemedia.com",
            "smartadserver.com", "yieldmo.com", "media.net", "sharethrough.com",
            "teads.tv", "33across.com", "indexww.com", "sovrn.com", "lijit.com",
            "zergnet.com", "revcontent.com", "mgid.com", "popads.net",
            "propellerads.com", "adsterra.com", "exoclick.com", "juicyads.com",
            "trafficjunky.net", "serving-sys.com", "flashtalking.com", "innovid.com",
            "spotxchange.com", "tremorvideo.com", "advertising.com", "adform.net",
            "adsrvr.org", "bidswitch.net", "contextweb.com", "gumgum.com", "yieldlab.net"
        )
    }

    // ------------------------------------------------------------------ ad blocking

    @SuppressLint("WebViewClientOnReceivedSslError")
    private fun blockedRequest(request: WebResourceRequest): WebResourceResponse? {
        if (!Prefs.adBlock(act)) return null
        if (request.isForMainFrame) return null
        val scheme = request.url.scheme?.lowercase() ?: return null
        if (scheme != "http" && scheme != "https") return null
        val host = request.url.host?.lowercase() ?: return null
        val blocked = AD_HOSTS.any { host == it || host.endsWith(".$it") }
        if (!blocked) return null
        return try {
            WebResourceResponse("text/plain", "utf-8", ByteArrayInputStream(ByteArray(0)))
        } catch (_: Exception) {
            null
        }
    }
}
