package com.example.videodownloader

import android.content.Context
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import java.io.File

/**
 * Everything the app update needs, kept out of the screens so closing the app loses nothing.
 *
 * The job (link, checksum, how far it came) lives in SharedPreferences and the APK file itself lives
 * in filesDir, so the next time the app opens it can continue the download where it stopped or go
 * straight to "Install" when the file is already complete.
 */
object UpdateStore {

    const val IDLE = 0
    const val DOWNLOADING = 1
    /** The APK is fully downloaded and verified: tapping Install is enough, no download needed. */
    const val READY = 2
    /** The APK was handed to Android's installer and we are waiting for its answer. */
    const val INSTALLING = 3
    const val FAILED = 4

    /** Anything smaller than this is not a real APK. */
    private const val MIN_APK_BYTES = 100_000L

    fun dir(c: Context): File = File(c.filesDir, "app_update")

    private fun sp(c: Context) = c.getSharedPreferences("hb_update", Context.MODE_PRIVATE)

    fun status(c: Context): Int = sp(c).getInt("status", IDLE)
    fun code(c: Context): Int = sp(c).getInt("code", 0)
    fun name(c: Context): String = sp(c).getString("name", "").orEmpty()
    fun url(c: Context): String = sp(c).getString("url", "").orEmpty()
    fun sha(c: Context): String = sp(c).getString("sha", "").orEmpty()
    fun notes(c: Context): String = sp(c).getString("notes", "").orEmpty()
    fun error(c: Context): String = sp(c).getString("err", "").orEmpty()
    fun done(c: Context): Long = sp(c).getLong("done", 0L)
    fun total(c: Context): Long = sp(c).getLong("total", 0L)
    fun apkLength(c: Context): Long = sp(c).getLong("apk_len", 0L)
    fun savedAt(c: Context): Long = sp(c).getLong("saved_at", 0L)

    fun apk(c: Context): File = File(dir(c), "HB_AIO_${code(c)}.apk")
    fun part(c: Context): File = File(dir(c), "HB_AIO_${code(c)}.apk.part")

    /** The remembered update-v1.json, or null when nothing was ever stored. */
    fun info(c: Context): Updater.Info? {
        val u = url(c)
        if (u.isBlank() || code(c) <= 0) return null
        return Updater.Info(code(c), name(c), u, notes(c), 0, sha(c))
    }

    /**
     * Starts (or re-claims) the job for this version. A different version means the old files and the
     * old byte count are useless, so they are dropped; asking again for the same version keeps the
     * half file so the download continues instead of starting over.
     */
    fun begin(c: Context, i: Updater.Info) {
        if (code(c) != i.code) {
            deleteFiles(c)
            dir(c).mkdirs()
        }
        sp(c).edit()
            .putInt("status", DOWNLOADING)
            .putInt("code", i.code)
            .putString("name", i.name)
            .putString("url", i.apkUrl)
            .putString("sha", i.sha256)
            .putString("notes", i.notes)
            .putString("err", "")
            .putLong("apk_len", 0L)
            .putLong("saved_at", System.currentTimeMillis())
            .apply()
    }

    fun setStatus(c: Context, s: Int, err: String = "") {
        sp(c).edit().putInt("status", s).putString("err", err).apply()
    }

    fun setProgress(c: Context, done: Long, total: Long) {
        sp(c).edit().putLong("done", done).putLong("total", total).putLong("saved_at", System.currentTimeMillis()).apply()
    }

    /** Marks the finished file as ready to install, remembering its size so a truncated copy is caught. */
    fun markReady(c: Context, f: File) {
        sp(c).edit()
            .putInt("status", READY)
            .putString("err", "")
            .putLong("apk_len", f.length())
            .putLong("done", f.length())
            .putLong("total", f.length())
            .putLong("saved_at", System.currentTimeMillis())
            .apply()
    }

    /** The downloaded APK, only when it is really there and unharmed. */
    fun readyApk(c: Context): File? {
        if (status(c) != READY && status(c) != INSTALLING) return null
        val f = apk(c)
        if (!f.isFile || f.length() < MIN_APK_BYTES || f.length() != apkLength(c)) {
            setStatus(c, IDLE) // the file is gone (storage cleared): the download has to start again
            return null
        }
        return f
    }

    fun isDone(c: Context): Boolean = status(c) == READY || status(c) == INSTALLING

    fun clear(c: Context) {
        sp(c).edit().clear().apply()
        deleteFiles(c)
    }

    private fun deleteFiles(c: Context) {
        apk(c).delete()
        part(c).delete()
    }

    /**
     * Removes leftovers: the APK of a version the phone already has, and files of another version than
     * the current job. An installed update must not keep eating storage, and the finished APK of an
     * update that was abandoned a month ago is no use either.
     */
    fun prune(c: Context) {
        // older versions put the APK in the cache folder, where Android could delete it at any time
        File(c.cacheDir, "app_update").deleteRecursively()
        if (code(c) <= Updater.currentCode(c)) {
            clear(c)
            return
        }
        if (status(c) == DOWNLOADING && System.currentTimeMillis() - savedAt(c) > 30L * 24 * 3600_000) {
            clear(c)
            return
        }
        val keep = apk(c).takeIf { it.isFile }?.name
        val keepPart = part(c).takeIf { it.isFile }?.name
        (dir(c).listFiles() ?: emptyArray()).forEach { f ->
            if (f.name != keep && f.name != keepPart) f.delete()
        }
        if (keep == null && keepPart == null) clear(c)
    }

    fun touchSaved(c: Context) {
        sp(c).edit().putLong("saved_at", System.currentTimeMillis()).apply()
    }

    fun sha256Of(f: File): String {
        val md = java.security.MessageDigest.getInstance("SHA-256")
        f.inputStream().use { inp ->
            val buf = ByteArray(64 * 1024)
            while (true) {
                val n = inp.read(buf)
                if (n < 0) break
                md.update(buf, 0, n)
            }
        }
        return md.digest().joinToString("") { "%02x".format(it) }
    }

    /** true when the file is a real APK and matches the checksum from update-v1.json (when there is one). */
    fun checksumOk(c: Context, f: File): Boolean =
        f.length() >= MIN_APK_BYTES &&
            (sha(c).isBlank() || sha256Of(f).equals(sha(c).trim(), ignoreCase = true))
}

/** Live update state for the open screen (the persisted copy is in [UpdateStore]). */
object UpdateTracker {
    data class Ui(val status: Int, val text: String, val pct: Int)

    private val _ui = MutableStateFlow(Ui(UpdateStore.IDLE, "", 0))
    val ui: StateFlow<Ui> = _ui

    fun set(status: Int, text: String, pct: Int) {
        _ui.value = Ui(status, text, pct)
    }
}
