package com.example.videodownloader

import android.content.Context
import java.io.File

/**
 * Converts a finished video on this phone into H.264/AAC (plays smoothly on every phone), using the
 * ffmpeg that comes with youtubedl-android. It works on the file that is already downloaded, so
 * nothing is downloaded a second time.
 *
 * Returns the new file, or null when it did not work (no ffmpeg, no libx264, error ...). The caller
 * then simply keeps the original file, so a failed conversion never loses a download.
 */
object Transcoder {

    private const val MAX_MINUTES = 45L

    fun toH264(c: Context, src: File, ctl: DlControl): File? {
        val ffmpeg = File(c.applicationInfo.nativeLibraryDir, "libffmpeg.so")
        if (!ffmpeg.exists()) return null

        val out = File(src.parentFile, "converted_${System.currentTimeMillis()}.mp4")
        // same places youtubedl-android itself uses to run ffmpeg
        val packages = File(c.noBackupFilesDir, "youtubedl-android/packages")
        val libPath = listOf("python", "ffmpeg", "aria2c")
            .joinToString(":") { File(packages, "$it/usr/lib").absolutePath }

        val pb = ProcessBuilder(
            ffmpeg.absolutePath, "-y", "-nostdin", "-loglevel", "error",
            "-i", src.absolutePath,
            "-c:v", "libx264", "-preset", "veryfast", "-crf", "24", "-pix_fmt", "yuv420p",
            "-c:a", "aac", "-b:a", "128k", "-movflags", "+faststart",
            out.absolutePath
        ).redirectErrorStream(true)
        pb.environment()["LD_LIBRARY_PATH"] = libPath
        pb.environment()["TMPDIR"] = c.cacheDir.absolutePath

        val p = pb.start()
        // read and drop ffmpeg's messages so it never blocks on a full pipe
        val drain = Thread {
            try {
                val buf = ByteArray(8192)
                while (p.inputStream.read(buf) >= 0) { /* discard */ }
            } catch (_: Exception) {
            }
        }
        drain.isDaemon = true
        drain.start()

        var ok = false
        try {
            val deadline = System.currentTimeMillis() + MAX_MINUTES * 60_000L
            while (p.isAlive) {
                if (ctl.cancelled) {
                    p.destroy()
                    throw UserCancelled()
                }
                if (System.currentTimeMillis() > deadline) {
                    p.destroy()
                    return null
                }
                Thread.sleep(300)
            }
            ok = p.exitValue() == 0 && out.exists() && out.length() > 10_000L
            return if (ok) out else null
        } catch (_: InterruptedException) {
            p.destroy()
            return null
        } finally {
            if (!ok) out.delete()
        }
    }
}
