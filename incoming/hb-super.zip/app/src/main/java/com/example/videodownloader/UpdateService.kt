package com.example.videodownloader

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import java.io.File
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Downloads the new APK outside of every screen.
 *
 * Closing the app, switching to another one or the phone sleeping does not stop it: the download runs
 * here with a foreground notification, it picks up a half file where it stopped (HTTP Range), and the
 * finished file is kept in filesDir with its checksum. The next time the app opens there is nothing to
 * ask about: Install is offered straight away.
 */
class UpdateService : Service() {

    companion object {
        const val ACTION_START = "com.example.videodownloader.UPDATE_START"
        const val ACTION_CANCEL = "com.example.videodownloader.UPDATE_CANCEL"

        private const val CH_RUN = "update_progress"
        private const val CH_READY = "update_done"
        private const val NOTI = 9001
        private const val MAX_TRIES = 8

        /** true while this process has the job running here (the app and the service are one process). */
        @Volatile
        private var running = false
        fun isRunning(): Boolean = running

        fun startDownload(c: Context) {
            val i = Intent(c, UpdateService::class.java).setAction(ACTION_START)
            try {
                if (Build.VERSION.SDK_INT >= 26) c.startForegroundService(i) else c.startService(i)
            } catch (_: Exception) {
                // Some phones block background starts: the app resumes the job the next time it opens.
            }
        }

        fun cancel(c: Context) {
            try {
                c.startService(Intent(c, UpdateService::class.java).setAction(ACTION_CANCEL))
            } catch (_: Exception) {
            }
        }

        fun ensureChannels(c: Context) {
            val nm = c.getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(
                NotificationChannel(CH_RUN, "App update", NotificationManager.IMPORTANCE_LOW)
            )
            nm.createNotificationChannel(
                NotificationChannel(CH_READY, "Update ready", NotificationManager.IMPORTANCE_DEFAULT)
            )
        }

        /** The notification a user taps when the downloaded update is ready (or Android wants the tap). */
        fun showTapToInstall(c: Context) {
            ensureChannels(c)
            val n = NotificationCompat.Builder(c, CH_READY)
                .setSmallIcon(R.drawable.ic_stat_hb)
                .setContentTitle("Update ready to install")
                .setContentText("Version ${UpdateStore.name(c)} is downloaded. Tap to install.")
                .setStyle(NotificationCompat.BigTextStyle().bigText(
                    "Version ${UpdateStore.name(c)} is downloaded.\nTap to install."
                ))
                .setContentIntent(tapIntent(c))
                .setAutoCancel(true)
                .addAction(0, "Install", tapIntent(c))
                .build()
            try { c.getSystemService(NotificationManager::class.java).notify(NOTI, n) } catch (_: Exception) { }
        }

        fun hideNotification(c: Context) {
            try { c.getSystemService(NotificationManager::class.java).cancel(NOTI) } catch (_: Exception) { }
        }

        private fun tapIntent(c: Context): PendingIntent {
            val i = Intent(c, InstallUpdateActivity::class.java)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
            return PendingIntent.getActivity(
                c, 9001, i, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
        }
    }

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val cancelled = AtomicBoolean(false)
    private lateinit var nm: NotificationManager

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        nm = getSystemService(NotificationManager::class.java)
        ensureChannels(this)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_CANCEL) {
            cancelled.set(true)
            if (UpdateStore.status(this) == UpdateStore.DOWNLOADING) {
                UpdateStore.setStatus(this, UpdateStore.IDLE)
                UpdateStore.part(this).delete()
                UpdateStore.setProgress(this, 0L, UpdateStore.total(this))
                publish(UpdateStore.IDLE, "Update download cancelled.", 0)
            }
            stopEverything()
            return START_NOT_STICKY
        }

        // A finished download is not this service's job any more: the notification waits for the tap.
        if (UpdateStore.readyApk(this) != null) {
            publish(UpdateStore.READY, "Tap to install.", 100)
            stopEverything()
            return START_NOT_STICKY
        }
        if (UpdateStore.info(this) == null) {
            stopEverything()
            return START_NOT_STICKY
        }

        goForeground(textForProgress(), pctNow())
        if (running) return START_STICKY // this same job is already downloading

        running = true
        cancelled.set(false)
        UpdateStore.setStatus(this, UpdateStore.DOWNLOADING)
        publish(UpdateStore.DOWNLOADING, "Downloading update... 0%", 0)
        scope.launch {
            try {
                val apk = download()
                UpdateStore.markReady(this@UpdateService, apk)
                if (!cancelled.get()) publish(UpdateStore.READY, "Tap to install.", 100)
            } catch (e: Exception) {
                if (!cancelled.get()) {
                    val why = friendly(e)
                    UpdateStore.setStatus(this@UpdateService, UpdateStore.FAILED, why)
                    publish(UpdateStore.FAILED, why, pctNow())
                }
            } finally {
                running = false
                stopEverything()
            }
        }
        // START_STICKY: if the phone kills the app process, Android brings this service back and the
        // job restarts from the half file without the user opening the app.
        return START_STICKY
    }

    override fun onDestroy() {
        scope.cancel()
        super.onDestroy()
    }

    private fun stopEverything() {
        ServiceCompat.stopForeground(this, ServiceCompat.STOP_FOREGROUND_DETACH)
        stopSelf()
    }

    private fun pctNow(): Int = with(UpdateStore) {
        val t = total(this@UpdateService)
        if (t > 0) (done(this@UpdateService) * 100 / t).toInt().coerceIn(0, 100) else 0
    }

    private fun textForProgress(): String {
        val d = UpdateStore.done(this)
        val t = UpdateStore.total(this)
        return if (t > 0)
            "Downloading update... ${pctNow()}%  |  ${HistoryStore.fmtSize(d)} / ${HistoryStore.fmtSize(t)}"
        else "Downloading update... ${HistoryStore.fmtSize(d)}"
    }

    private fun installIntent(): PendingIntent = tapIntent(this)

    private fun goForeground(text: String, pct: Int) {
        try {
            ServiceCompat.startForeground(
                this, NOTI, progressNotification(text, pct),
                ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC
            )
        } catch (_: Exception) {
            // Android 14+ can refuse a background start: the file keeps downloading for now and the
            // app resumes it on the next open.
        }
    }

    private fun progressNotification(text: String, pct: Int): android.app.Notification =
        NotificationCompat.Builder(this, CH_RUN)
            .setSmallIcon(R.drawable.ic_stat_hb)
            .setContentTitle("Updating HB Super App")
            .setContentText(text)
            .setProgress(100, pct, false)
            .setContentIntent(installIntent())
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .addAction(0, "Cancel", cancelIntent())
            .build()

    private fun cancelIntent(): PendingIntent = PendingIntent.getService(
        this, 9002, Intent(this, UpdateService::class.java).setAction(ACTION_CANCEL),
        PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
    )

    /** Writes the state down (for a screen that opens later), updates the flow and the notification. */
    private fun publish(status: Int, text: String, pct: Int) {
        UpdateTracker.set(status, text, pct)
        when (status) {
            UpdateStore.READY -> showTapToInstall(this)
            UpdateStore.FAILED -> notifyNow(failedNotification(text))
            else -> notifyNow(progressNotification(text, pct))
        }
    }

    private fun notifyNow(n: android.app.Notification) {
        try { nm.notify(NOTI, n) } catch (_: Exception) { }
    }

    private fun failedNotification(text: String): android.app.Notification =
        NotificationCompat.Builder(this, CH_READY)
            .setSmallIcon(R.drawable.ic_stat_hb)
            .setContentTitle("Update download stopped")
            .setContentText(text)
            .setStyle(NotificationCompat.BigTextStyle().bigText(text))
            .setContentIntent(installIntent())
            .setAutoCancel(true)
            .build()

    /** Tries the whole download, resuming the half file after every problem, until it is complete. */
    private fun download(): File {
        var lastErr: Exception? = null
        for (round in 1..MAX_TRIES) {
            if (cancelled.get()) throw InterruptedException("Cancelled")
            try {
                return attempt()
            } catch (e: Exception) {
                if (cancelled.get()) throw e
                lastErr = e
                if (round < MAX_TRIES) {
                    val keep = UpdateStore.part(this).takeIf { it.isFile }?.length() ?: 0L
                    publish(
                        UpdateStore.DOWNLOADING,
                        "Retrying the update download (${round + 1}/$MAX_TRIES)... " +
                            HistoryStore.fmtSize(keep) + " already got",
                        pctNow()
                    )
                    waitForNetwork(4_000L * round)
                }
            }
        }
        throw (lastErr ?: Exception("Download failed"))
    }

    /** One HTTP try. A half file is continued with Range when the server supports it. */
    private fun attempt(): File {
        val url = UpdateStore.url(this)
        val part = UpdateStore.part(this)
        val apk = UpdateStore.apk(this)
        var from = if (part.isFile) part.length() else 0L

        val con = URL(url).openConnection() as HttpURLConnection
        con.connectTimeout = 20000
        con.readTimeout = 60000
        con.instanceFollowRedirects = true
        if (from > 0) con.setRequestProperty("Range", "bytes=$from-")
        try {
            val res = con.responseCode
            if (res != 200 && res != 206) error("Download failed ($res)")
            if (res == 200 && from > 0) {
                from = 0L // the server cannot continue the half file: start it again
                part.delete()
            }
            val rest = con.contentLengthLong
            val total = if (rest > 0) from + rest else 0L
            UpdateStore.setProgress(this, from, total)

            var done = from
            var lastUi = 0L
            var lastBytesForSpeed = from
            var speed = ""
            con.inputStream.use { inp ->
                FileOutputStream(part, from > 0).use { o ->
                    val buf = ByteArray(128 * 1024)
                    while (true) {
                        if (cancelled.get()) throw InterruptedException("Cancelled")
                        val n = inp.read(buf)
                        if (n < 0) break
                        o.write(buf, 0, n)
                        done += n
                        val now = System.currentTimeMillis()
                        if (now - lastUi > 700) {
                            val perSec = (done - lastBytesForSpeed) * 1000 / (now - lastUi).coerceAtLeast(1)
                            speed = "  |  ${HistoryStore.fmtSize(perSec)}/s"
                            lastBytesForSpeed = done
                            lastUi = now
                            UpdateStore.setProgress(this, done, total)
                            val pct = if (total > 0) (done * 100 / total).toInt().coerceIn(0, 99) else 0
                            val sizeText = if (total > 0)
                                "  |  ${HistoryStore.fmtSize(done)} / ${HistoryStore.fmtSize(total)}" else ""
                            publish(
                                UpdateStore.DOWNLOADING,
                                "Downloading update... $pct%$sizeText$speed",
                                pct
                            )
                        }
                    }
                    o.flush()
                }
            }
        } finally {
            con.disconnect()
        }

        if (cancelled.get()) throw InterruptedException("Cancelled")
        val got = part.length()
        if (got < 100_000) error("Downloaded file is not an APK")
        val total = UpdateStore.total(this)
        if (total > 0 && got != total) error("Download stopped at ${HistoryStore.fmtSize(got)} of ${HistoryStore.fmtSize(total)}")

        // update-v1.json can carry the SHA-256 of the APK: a damaged or swapped file is refused, and the
        // half file is thrown away so the next try does not resume a broken piece.
        if (!UpdateStore.checksumOk(this, part)) {
            part.delete()
            UpdateStore.setProgress(this, 0L, 0L)
            throw Exception("Update file is damaged (checksum does not match). Please try again.")
        }
        apk.delete()
        if (!part.renameTo(apk)) {
            part.copyTo(apk, overwrite = true)
            part.delete()
        }
        return apk
    }

    /** Without internet the download waits (up to 15 minutes) instead of failing, then continues. */
    private fun waitForNetwork(backoffMs: Long) {
        if (!sleep(backoffMs)) return
        val until = System.currentTimeMillis() + 15 * 60_000L
        var saidWaiting = false
        while (!hasInternet()) {
            if (cancelled.get() || System.currentTimeMillis() > until) return
            if (!saidWaiting) {
                publish(UpdateStore.DOWNLOADING, "No internet. Waiting... it continues by itself.", pctNow())
                saidWaiting = true
            }
            if (!sleep(3000)) return
        }
    }

    private fun sleep(ms: Long): Boolean = try {
        Thread.sleep(ms)
        true
    } catch (_: InterruptedException) {
        false
    }

    private fun hasInternet(): Boolean = try {
        val cm = getSystemService(ConnectivityManager::class.java)
        val caps = cm.getNetworkCapabilities(cm.activeNetwork)
        caps != null && caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
    } catch (_: Exception) {
        true
    }

    private fun friendly(e: Exception): String {
        val m = e.message.orEmpty().lowercase()
        return when {
            "cancelled" in m -> "Update download cancelled."
            "no space" in m || "enospc" in m -> "Phone storage is full. Free some space, then tap Update again."
            "unable to resolve host" in m || "no address associated" in m || "network" in m ||
                "timed out" in m || "connection" in m ->
                "Network problem while downloading the update. It continues when the app is opened again."
            m.isBlank() -> "Update download stopped."
            else -> e.message.orEmpty()
        }
    }
}
