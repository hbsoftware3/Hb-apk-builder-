package com.example.videodownloader

import java.net.HttpURLConnection
import java.net.URL

/** Every website the app knows special tricks for. */
enum class Site(val label: String) {
    YOUTUBE("YouTube"),
    INSTAGRAM("Instagram"),
    FACEBOOK("Facebook"),
    TIKTOK("TikTok"),
    X("X"),
    REDDIT("Reddit"),
    VIMEO("Vimeo"),
    DAILYMOTION("Dailymotion"),
    PINTEREST("Pinterest"),
    SNAPCHAT("Snapchat"),
    THREADS("Threads"),
    TWITCH("Twitch"),
    LIKEE("Likee"),
    LINKEDIN("LinkedIn"),
    OTHER("Other");

    companion object {
        fun detect(url: String): Site {
            val raw = url.lowercase()
            val host = try { URL(url).host?.lowercase() ?: "" } catch (_: Exception) { "" }
            val probe = host.ifBlank { raw }
            fun any(vararg names: String): Boolean =
                if (host.isNotBlank()) names.any { host == it || host.endsWith(".$it") }
                else names.any { it in raw }
            return when {
                any("youtu.be", "youtube.com", "youtube-nocookie.com") -> YOUTUBE
                any("instagram.com", "instagr.am") -> INSTAGRAM
                any("facebook.com", "fb.watch", "fb.com", "fb.me") -> FACEBOOK
                any("tiktok.com") -> TIKTOK
                any("x.com", "twitter.com", "t.co") -> X
                any("reddit.com", "redd.it") -> REDDIT
                any("vimeo.com") -> VIMEO
                any("dailymotion.com", "dai.ly") -> DAILYMOTION
                "pinterest." in probe || any("pin.it") -> PINTEREST
                any("snapchat.com") -> SNAPCHAT
                any("threads.net", "threads.com") -> THREADS
                any("twitch.tv") -> TWITCH
                "likee." in probe -> LIKEE
                any("linkedin.com", "lnkd.in") -> LINKEDIN
                else -> OTHER
            }
        }
    }
}

object UrlTools {
    const val MOBILE_UA =
        "Mozilla/5.0 (Linux; Android 13; Pixel 7) AppleWebKit/537.36 " +
            "(KHTML, like Gecko) Chrome/124.0.0.0 Mobile Safari/537.36"
    const val DESKTOP_UA =
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 " +
            "(KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36"

    /** Remove trailing punctuation that often sticks to a copied link. */
    fun clean(url: String): String = url.trim().trimEnd('.', ',', ')', ']', '"', '\'')

    private fun needsRedirectResolve(url: String): Boolean {
        val u = url.lowercase()
        return "vm.tiktok.com" in u || "vt.tiktok.com" in u || "tiktok.com/t/" in u ||
            "fb.watch" in u || "fb.me" in u || "facebook.com/share/" in u || "/l.php" in u
    }

    /** Follow short/share links (vm.tiktok.com, fb.watch, facebook.com/share/...) to the real address. */
    fun resolve(url: String): String {
        if (!needsRedirectResolve(url)) return url
        return try {
            var current = url
            repeat(6) {
                val c = URL(current).openConnection() as HttpURLConnection
                c.instanceFollowRedirects = false
                c.connectTimeout = 8000
                c.readTimeout = 8000
                c.requestMethod = "GET"
                c.setRequestProperty("User-Agent", MOBILE_UA)
                c.setRequestProperty("Accept-Language", "en-US,en;q=0.9")
                val code = c.responseCode
                val loc = c.getHeaderField("Location")
                c.disconnect()
                if (code in 300..399 && !loc.isNullOrBlank()) {
                    current = if (loc.startsWith("http")) loc else URL(URL(current), loc).toString()
                } else {
                    return stripTracking(current)
                }
            }
            stripTracking(current)
        } catch (_: Exception) {
            url
        }
    }

    /** TikTok adds long tracking queries after the video id. They are not needed. */
    fun stripTracking(url: String): String {
        val u = url.lowercase()
        return if ("tiktok.com" in u && "/video/" in u) url.substringBefore('?') else url
    }

    /** Facebook has many host names; yt-dlp is happiest with www.facebook.com. */
    fun facebookDesktop(url: String): String =
        url.replace(Regex("https?://(m|mbasic|web|touch|l)\\.facebook\\.com", RegexOption.IGNORE_CASE), "https://www.facebook.com")

    fun facebookMobile(url: String): String =
        url.replace(Regex("https?://(www|web|touch|mbasic)\\.facebook\\.com", RegexOption.IGNORE_CASE), "https://m.facebook.com")
}
