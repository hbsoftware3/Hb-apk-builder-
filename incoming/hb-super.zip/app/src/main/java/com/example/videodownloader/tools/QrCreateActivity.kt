package com.example.videodownloader.tools

import android.content.ContentValues
import android.graphics.Bitmap
import android.graphics.Color
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.view.Gravity
import android.view.ViewGroup
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import com.example.videodownloader.R
import com.example.videodownloader.ui.BaseActivity
import com.example.videodownloader.ui.Hb
import com.example.videodownloader.util.Launcher
import com.google.zxing.BarcodeFormat
import com.google.zxing.EncodeHintType
import com.google.zxing.qrcode.QRCodeWriter
import com.google.zxing.qrcode.decoder.ErrorCorrectionLevel
import java.io.File
import java.io.FileOutputStream

/** Creates QR codes from text or a link, saves them to Pictures/HB AIO and shares them. */
class QrCreateActivity : BaseActivity() {

    private var bitmap: Bitmap? = null
    private lateinit var preview: ImageView
    private lateinit var previewWrap: LinearLayout
    private lateinit var hint: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val p = Hb.palette(this)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(p.bg)
        }
        root.addView(Hb.topBar(this, "QR Generator", "Text, links, Wi-Fi and more", { finish() }))

        val scroll = ScrollView(this).apply { isFillViewport = true }
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(Hb.dp(this@QrCreateActivity, 18), Hb.dp(this@QrCreateActivity, 6),
                Hb.dp(this@QrCreateActivity, 18), Hb.dp(this@QrCreateActivity, 30))
        }

        val input = EditText(this).apply {
            hint = "Type or paste text / URL"
            setHintTextColor(p.muted)
            setTextColor(p.text)
            textSize = 15f
            minLines = 3
            gravity = Gravity.TOP
            setPadding(Hb.dp(this@QrCreateActivity, 14), Hb.dp(this@QrCreateActivity, 12),
                Hb.dp(this@QrCreateActivity, 14), Hb.dp(this@QrCreateActivity, 12))
            background = Hb.round(this@QrCreateActivity, 16, p.surfaceAlt, p.border, 1)
            addTextChangedListener(object : android.text.TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
                override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {
                    update(s?.toString().orEmpty())
                }
                override fun afterTextChanged(s: android.text.Editable?) {}
            })
        }
        col.addView(input, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        hint = Hb.text(this, "The code updates while you type.", 10.5f, p.muted).apply {
            setPadding(Hb.dp(this@QrCreateActivity, 4), Hb.dp(this@QrCreateActivity, 6), 0, 0)
        }
        col.addView(hint)

        previewWrap = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(Hb.dp(this@QrCreateActivity, 16), Hb.dp(this@QrCreateActivity, 18),
                Hb.dp(this@QrCreateActivity, 16), Hb.dp(this@QrCreateActivity, 18))
            background = Hb.round(this@QrCreateActivity, 20, Color.WHITE)
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                topMargin = Hb.dp(this@QrCreateActivity, 16)
            }
        }
        preview = ImageView(this).apply {
            adjustViewBounds = true
            scaleType = ImageView.ScaleType.FIT_CENTER
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, Hb.dp(this@QrCreateActivity, 260))
        }
        previewWrap.addView(preview)
        val emptyLabel = Hb.text(this, "Your QR code will appear here", 12f, Color.parseColor("#5B6577"))
        previewWrap.addView(emptyLabel)
        col.addView(previewWrap)

        val actions = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(0, Hb.dp(this@QrCreateActivity, 14), 0, 0)
        }
        actions.addView(Hb.button(this, "Save to Photos", true, R.drawable.ic_download) { save() },
            LinearLayout.LayoutParams(0, Hb.dp(this@QrCreateActivity, 48), 1f).apply { marginEnd = Hb.dp(this@QrCreateActivity, 8) })
        actions.addView(Hb.button(this, "Share", false, R.drawable.ic_share) { share() },
            LinearLayout.LayoutParams(0, Hb.dp(this@QrCreateActivity, 48), 1f))
        col.addView(actions)

        col.addView(Hb.text(this, "Saved images go to Pictures/HB AIO. The code is generated on the device; no text leaves the app.", 10.5f, p.muted).apply {
            setPadding(Hb.dp(this@QrCreateActivity, 4), Hb.dp(this@QrCreateActivity, 12), 0, 0)
        })

        scroll.addView(col)
        root.addView(scroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        setContentView(root)
    }

    private fun update(text: String) {
        val clean = text.trim()
        if (clean.isEmpty()) {
            bitmap = null
            preview.setImageDrawable(null)
            hint.text = "The code updates while you type."
            return
        }
        if (clean.length > 1500) {
            hint.text = "Text is too long for a QR code. Keep it under 1500 characters."
            return
        }
        try {
            val size = 900
            val hints = mapOf(
                EncodeHintType.ERROR_CORRECTION to ErrorCorrectionLevel.M,
                EncodeHintType.MARGIN to 1,
                EncodeHintType.CHARACTER_SET to "UTF-8"
            )
            val matrix = QRCodeWriter().encode(clean, BarcodeFormat.QR_CODE, size, size, hints)
            val bmp = Bitmap.createBitmap(matrix.width, matrix.height, Bitmap.Config.ARGB_8888)
            for (x in 0 until matrix.width) {
                for (y in 0 until matrix.height) {
                    bmp.setPixel(x, y, if (matrix.get(x, y)) Color.BLACK else Color.WHITE)
                }
            }
            bitmap = bmp
            preview.setImageBitmap(bmp)
            hint.text = "${clean.length} characters • error correction M"
        } catch (e: Exception) {
            hint.text = "Could not create this code: ${e.message ?: "too much data"}"
        }
    }

    private fun save() {
        val bmp = bitmap ?: run {
            Hb.toast(this, "Type something first")
            return
        }
        val name = "HB_QR_${System.currentTimeMillis()}.png"
        val values = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, name)
            put(MediaStore.MediaColumns.MIME_TYPE, "image/png")
            put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/HB AIO")
            put(MediaStore.MediaColumns.IS_PENDING, 1)
        }
        val uri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
        if (uri == null) {
            Hb.toast(this, "Could not save the image")
            return
        }
        try {
            contentResolver.openOutputStream(uri)?.use { o -> bmp.compress(Bitmap.CompressFormat.PNG, 100, o) }
            contentResolver.update(uri, ContentValues().apply { put(MediaStore.MediaColumns.IS_PENDING, 0) }, null, null)
            Hb.toast(this, "Saved to Pictures/HB AIO")
        } catch (e: Exception) {
            runCatching { contentResolver.delete(uri, null, null) }
            Hb.toast(this, "Could not save the image")
        }
    }

    private fun share() {
        val bmp = bitmap ?: run {
            Hb.toast(this, "Type something first")
            return
        }
        try {
            val file = File(cacheDir, "qr_share.png")
            FileOutputStream(file).use { o -> bmp.compress(Bitmap.CompressFormat.PNG, 100, o) }
            Launcher.shareFile(this, file, "image/png")
        } catch (_: Exception) {
            Hb.toast(this, "Could not prepare the image")
        }
    }
}
