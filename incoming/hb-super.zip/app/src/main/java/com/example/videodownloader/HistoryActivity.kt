package com.example.videodownloader

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import android.text.Editable
import android.text.TextWatcher
import android.text.format.DateFormat
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.ListView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class HistoryActivity : AppCompatActivity() {

    private lateinit var list: ListView
    private lateinit var empty: TextView
    private lateinit var tvTotal: TextView
    private lateinit var tabVideo: Button
    private lateinit var tabAudio: Button
    private lateinit var btnRetryAll: Button
    private var all: List<HistoryItem> = emptyList()
    private var items: List<HistoryItem> = emptyList()

    /** true = the MP3 list, false = the video / photo list (two separate histories). */
    private var audioMode = false

    /** File sizes read from the phone for older entries that were saved without a size. */
    private val sizes = HashMap<Long, Long>()

    /** Entries whose file is no longer on the phone (deleted in the gallery / file manager). */
    private val gone = HashSet<Long>()

    /** Text typed in the search box (title or link). */
    private var query = ""
    private fun sizeOf(h: HistoryItem): Long = if (h.size > 0) h.size else sizes[h.id] ?: 0L

    private val adapter = object : BaseAdapter() {
        override fun getCount() = items.size
        override fun getItem(position: Int) = items[position]
        override fun getItemId(position: Int) = items[position].id
        override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
            val row = convertView ?: layoutInflater.inflate(R.layout.item_history, parent, false)
            val h = items[position]
            row.findViewById<TextView>(R.id.hTitle).text = h.title
            val whenText = DateFormat.format("dd MMM yyyy, hh:mm a", h.time).toString()
            val sz = if (h.ok) sizeOf(h) else 0L
            val parts = listOfNotNull(
                whenText,
                h.quality.takeIf { it.isNotEmpty() },
                HistoryStore.fmtSize(sz).takeIf { sz > 0 }
            )
            row.findViewById<TextView>(R.id.hSub).text = parts.joinToString("   |   ")
            val st = row.findViewById<TextView>(R.id.hStatus)
            if (h.ok && gone.contains(h.id)) {
                st.text = "File deleted or moved"
                st.setTextColor(0xFFFFB74D.toInt())
            } else {
                st.text = if (h.ok) "Completed" + (if (h.message.isNotBlank()) "  |  ${h.message}" else "") else "Failed"
                st.setTextColor(if (h.ok) 0xFF7FD1FF.toInt() else 0xFFFF6B6B.toInt())
            }
            return row
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_history)
        audioMode = intent.getBooleanExtra(EXTRA_AUDIO, false)
        list = findViewById(R.id.list)
        empty = findViewById(R.id.empty)
        tvTotal = findViewById(R.id.tvTotal)
        tabVideo = findViewById(R.id.tabVideo)
        tabAudio = findViewById(R.id.tabAudio)
        btnRetryAll = findViewById(R.id.btnRetryAll)
        btnRetryAll.setOnClickListener { retryAllFailed() }
        findViewById<EditText>(R.id.etSearch).addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: Editable?) {
                query = s?.toString().orEmpty().trim()
                applyFilter()
            }
        })
        tabVideo.setOnClickListener { selectTab(false) }
        tabAudio.setOnClickListener { selectTab(true) }
        list.adapter = adapter

        list.setOnItemClickListener { _, _, pos, _ ->
            val h = items[pos]
            when {
                h.ok && gone.contains(h.id) -> showMissing(h)
                h.ok && h.uri != null && isAudio(h) -> showAudioChoice(h)
                h.ok && h.uri != null -> openVideo(h)
                else -> showFailed(h)
            }
        }
        list.setOnItemLongClickListener { _, _, pos, _ ->
            showOptions(items[pos])
            true
        }
        findViewById<Button>(R.id.btnClear).setOnClickListener {
            if (items.isEmpty()) return@setOnClickListener
            AlertDialog.Builder(this)
                .setTitle("Clear history?")
                .setMessage("This removes the list only. Your downloaded files stay on the phone.")
                .setPositiveButton("Clear") { _, _ ->
                    HistoryStore.removeWhere(this) { HistoryStore.isAudioItem(it) == audioMode }
                    refresh()
                }
                .setNegativeButton("Cancel", null)
                .show()
        }
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    private fun selectTab(audio: Boolean) {
        audioMode = audio
        applyFilter() // the list is already loaded, only the tab changes
    }

    private fun refresh() {
        all = HistoryStore.all(this)
        applyFilter()
        checkFiles()
    }

    /** Shows the entries of the chosen tab that match the search text. */
    private fun applyFilter() {
        items = all.filter {
            HistoryStore.isAudioItem(it) == audioMode &&
                (query.isEmpty() || it.title.contains(query, true) || it.url.contains(query, true))
        }
        adapter.notifyDataSetChanged()
        empty.text = when {
            query.isNotEmpty() -> "Nothing found"
            audioMode -> "No audio downloads yet"
            else -> "No video downloads yet"
        }
        empty.visibility = if (items.isEmpty()) View.VISIBLE else View.GONE
        updateTotal()
        val failedCount = items.count { !it.ok && it.url.isNotBlank() }
        btnRetryAll.text = "Retry All Failed ($failedCount)"
        btnRetryAll.isEnabled = failedCount > 0
        btnRetryAll.alpha = if (failedCount > 0) 1f else 0.55f
    }

    /**
     * Retry every failed item in the currently selected Video or Audio tab (and current search filter).
     * The service already limits concurrency and ignores links that are currently downloading.
     */
    private fun retryAllFailed() {
        val failed = items.filter { !it.ok && it.url.isNotBlank() }
        if (failed.isEmpty()) {
            Toast.makeText(this, "No failed downloads to retry", Toast.LENGTH_SHORT).show()
            return
        }
        AlertDialog.Builder(this)
            .setTitle("Retry all failed downloads?")
            .setMessage("${failed.size} failed ${if (audioMode) "audio" else "video"} download(s) will be added to the download queue.")
            .setPositiveButton("Retry all") { _, _ ->
                var started = 0
                failed.forEach { h ->
                    try {
                        ContextCompat.startForegroundService(
                            this,
                            Intent(this, DownloadService::class.java)
                                .putExtra(DownloadService.EXTRA_URL, h.url)
                                .putExtra(DownloadService.EXTRA_AUDIO, HistoryStore.isAudioItem(h))
                        )
                        started++
                    } catch (_: Exception) {
                        // Continue trying the remaining entries if one service start fails.
                    }
                }
                Toast.makeText(this, "Retry requested for $started download(s)", Toast.LENGTH_LONG).show()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    /**
     * Asks the phone (in the background) about every finished file: is it still there, and how big is it.
     * Older entries were saved without a size, this fills it in. Only a clearly missing file is marked
     * as deleted; if the phone cannot tell, nothing is marked.
     */
    private fun checkFiles() {
        val check = all.filter { it.ok && it.uri != null }
        if (check.isEmpty()) return
        lifecycleScope.launch {
            val found = withContext(Dispatchers.IO) { check.associate { it.id to querySize(it.uri!!) } }
            check.forEach { h ->
                val r = found[h.id] ?: 0L
                if (r < 0) gone.add(h.id) else {
                    gone.remove(h.id)
                    if (h.size <= 0) sizes[h.id] = r
                }
            }
            adapter.notifyDataSetChanged()
            updateTotal()
        }
    }

    /** File size in bytes, 0 = the phone did not say, -1 = the file is not there any more. */
    private fun querySize(uri: String): Long = try {
        contentResolver.query(Uri.parse(uri), arrayOf(OpenableColumns.SIZE), null, null, null)?.use {
            if (!it.moveToFirst()) -1L else if (it.isNull(0)) 0L else it.getLong(0)
        } ?: 0L
    } catch (e: Exception) {
        0L
    }

    /** Tabs show how many files each list has; the line below shows the sizes. */
    private fun updateTotal() {
        val vid = all.filter { it.ok && !HistoryStore.isAudioItem(it) }
        val aud = all.filter { it.ok && HistoryStore.isAudioItem(it) }
        tabVideo.text = "Video (${vid.size})"
        tabAudio.text = "Audio (${aud.size})"
        tabVideo.setBackgroundResource(if (audioMode) R.drawable.bg_btn_secondary else R.drawable.bg_btn_primary)
        tabAudio.setBackgroundResource(if (audioMode) R.drawable.bg_btn_primary else R.drawable.bg_btn_secondary)
        val vidSize = vid.sumOf { sizeOf(it) }
        val audSize = aud.sumOf { sizeOf(it) }
        val here = if (audioMode) audSize else vidSize
        val count = if (audioMode) aud.size else vid.size
        tvTotal.text = "${if (audioMode) "Audio" else "Video"}: $count ${if (count == 1) "file" else "files"}" +
            "   |   Size: ${HistoryStore.fmtSize(here)}\n" +
            "Everything together: ${HistoryStore.fmtSize(vidSize + audSize)}"
    }

    private fun isAudio(h: HistoryItem) = h.mime?.startsWith("audio/") == true

    /** Tap on an MP3: play it, or use it as ringtone / notification / alarm. */
    private fun showAudioChoice(h: HistoryItem) {
        AlertDialog.Builder(this)
            .setTitle(h.title)
            .setItems(arrayOf("Play", "Set as ringtone / notification / alarm")) { _, which ->
                if (which == 0) openVideo(h) else setRingtone(h)
            }
            .setNegativeButton("Close", null)
            .show()
    }

    private fun setRingtone(h: HistoryItem) {
        val u = h.uri ?: return
        startActivity(
            Intent(this, RingtoneActivity::class.java)
                .putExtra(RingtoneActivity.EXTRA_URI, u)
                .putExtra(RingtoneActivity.EXTRA_TITLE, h.title)
        )
    }

    private fun openVideo(h: HistoryItem) {
        try {
            val i = Intent(Intent.ACTION_VIEW)
                .setDataAndType(Uri.parse(h.uri), h.mime ?: "video/mp4")
                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            startActivity(i)
        } catch (e: Exception) {
            Toast.makeText(this, "File not found (it may have been deleted or moved)", Toast.LENGTH_LONG).show()
        }
    }

    /** Sends the downloaded file to another app (WhatsApp, Telegram, Bluetooth ...). */
    private fun shareFile(h: HistoryItem) {
        val u = h.uri ?: return
        try {
            val send = Intent(Intent.ACTION_SEND)
                .setType(h.mime ?: "video/mp4")
                .putExtra(Intent.EXTRA_STREAM, Uri.parse(u))
                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            startActivity(Intent.createChooser(send, "Share"))
        } catch (e: Exception) {
            Toast.makeText(this, "Could not share (the file may have been deleted or moved)", Toast.LENGTH_LONG).show()
        }
    }

    private fun showFailed(h: HistoryItem) {
        AlertDialog.Builder(this)
            .setTitle("Download failed")
            .setMessage(h.message.ifBlank { "Unknown error" })
            .setPositiveButton("Retry") { _, _ ->
                ContextCompat.startForegroundService(
                    this,
                    Intent(this, DownloadService::class.java)
                        .putExtra(DownloadService.EXTRA_URL, h.url)
                        .putExtra(DownloadService.EXTRA_AUDIO, h.quality.startsWith("Audio"))
                )
                Toast.makeText(this, "Download started in background", Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton("Close", null)
            .show()
    }

    /** The file was deleted or moved: offer to download it again. */
    private fun showMissing(h: HistoryItem) {
        AlertDialog.Builder(this)
            .setTitle("File not found")
            .setMessage("This file was deleted or moved. Download it again?")
            .setPositiveButton("Download again") { _, _ -> downloadAgain(h) }
            .setNegativeButton("Close", null)
            .show()
    }

    private fun downloadAgain(h: HistoryItem) {
        ContextCompat.startForegroundService(
            this,
            Intent(this, DownloadService::class.java)
                .putExtra(DownloadService.EXTRA_URL, h.url)
                .putExtra(DownloadService.EXTRA_AUDIO, HistoryStore.isAudioItem(h))
        )
        Toast.makeText(this, "Download started in background", Toast.LENGTH_SHORT).show()
    }

    private fun copyLink(h: HistoryItem) {
        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        cm.setPrimaryClip(ClipData.newPlainText("link", h.url))
        Toast.makeText(this, "Link copied", Toast.LENGTH_SHORT).show()
    }

    private fun showOptions(h: HistoryItem) {
        val hasFile = h.ok && h.uri != null && !gone.contains(h.id)
        val options = mutableListOf<String>()
        if (hasFile) options += "Share"
        if (hasFile && isAudio(h)) options += "Set as ringtone / notification / alarm"
        options += "Copy link"
        if (h.ok) options += "Download again"
        options += "Remove from history"
        if (hasFile) options += "Delete file too"
        AlertDialog.Builder(this)
            .setTitle(h.title)
            .setItems(options.toTypedArray()) { _, which ->
                when (options[which]) {
                    "Share" -> shareFile(h)
                    "Set as ringtone / notification / alarm" -> setRingtone(h)
                    "Copy link" -> copyLink(h)
                    "Download again" -> downloadAgain(h)
                    "Delete file too" -> confirmDeleteFile(h)
                    else -> {
                        HistoryStore.remove(this, h.id)
                        refresh()
                    }
                }
            }
            .show()
    }

    /** Deleting the real file cannot be undone, so ask first. */
    private fun confirmDeleteFile(h: HistoryItem) {
        AlertDialog.Builder(this)
            .setTitle("Delete file?")
            .setMessage("\"${h.title}\" will be deleted from your phone. This cannot be undone.")
            .setPositiveButton("Delete") { _, _ ->
                if (!SaveStore.delete(this, Uri.parse(h.uri))) {
                    Toast.makeText(this, "Could not delete the file (maybe it is already gone)", Toast.LENGTH_SHORT).show()
                }
                HistoryStore.remove(this, h.id)
                refresh()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    companion object {
        const val EXTRA_AUDIO = "audio"
    }
}
