package com.example.videodownloader

import android.content.Context
import android.media.MediaScannerConnection
import android.net.Uri
import android.os.Environment
import android.provider.DocumentsContract
import java.io.File

/**
 * Saves a finished download into a folder the user picked (Android's folder picker, "tree" address),
 * and helps to show / delete such files. When no folder is picked the app uses its default folders
 * (DCIM/HB AIO for videos and photos, Music/HB AIO for MP3) through MediaStore.
 */
object SaveStore {

    /** Does the app still have write access to the picked folder? (Android can take it away.) */
    fun hasAccess(c: Context, tree: String?): Boolean {
        if (tree == null) return true
        val u = Uri.parse(tree)
        return c.contentResolver.persistedUriPermissions.any { it.uri == u && it.isWritePermission }
    }

    /** Readable path of a picked folder, e.g. "Internal storage/Movies/HB". */
    fun label(tree: String?, whenDefault: String): String {
        if (tree == null) return whenDefault
        return try {
            val id = DocumentsContract.getTreeDocumentId(Uri.parse(tree))
            val i = id.indexOf(':')
            val vol = if (i < 0) id else id.substring(0, i)
            val rel = if (i < 0) "" else id.substring(i + 1)
            val root = if (vol == "primary") "Internal storage" else "SD card"
            if (rel.isEmpty()) root else "$root/$rel"
        } catch (_: Exception) {
            whenDefault
        }
    }

    private fun treeRoot(tree: Uri): Uri =
        DocumentsContract.buildDocumentUriUsingTree(tree, DocumentsContract.getTreeDocumentId(tree))

    private fun findChildDir(c: Context, tree: Uri, parent: Uri, name: String): Uri? {
        val kids = DocumentsContract.buildChildDocumentsUriUsingTree(tree, DocumentsContract.getDocumentId(parent))
        c.contentResolver.query(
            kids,
            arrayOf(
                DocumentsContract.Document.COLUMN_DOCUMENT_ID,
                DocumentsContract.Document.COLUMN_DISPLAY_NAME,
                DocumentsContract.Document.COLUMN_MIME_TYPE
            ),
            null, null, null
        )?.use { cur ->
            while (cur.moveToNext()) {
                val isDir = cur.getString(2) == DocumentsContract.Document.MIME_TYPE_DIR
                if (isDir && cur.getString(1).orEmpty().equals(name, ignoreCase = true)) {
                    return DocumentsContract.buildDocumentUriUsingTree(tree, cur.getString(0))
                }
            }
        }
        return null
    }

    private fun dirFor(c: Context, tree: Uri, sub: String?): Uri {
        val root = treeRoot(tree)
        if (sub.isNullOrBlank()) return root
        return findChildDir(c, tree, root, sub)
            ?: DocumentsContract.createDocument(
                c.contentResolver, root, DocumentsContract.Document.MIME_TYPE_DIR, sub
            )
            ?: throw Exception("Could not create folder $sub")
    }

    /** Copies [f] into the picked folder (inside the sub folder, if given). Returns the new file's address. */
    fun save(c: Context, treeStr: String, sub: String?, f: File, mime: String, name: String): Uri {
        val tree = Uri.parse(treeStr)
        if (!hasAccess(c, treeStr)) throw Exception("Folder access was lost")
        val dir = dirFor(c, tree, sub)
        val out = DocumentsContract.createDocument(c.contentResolver, dir, mime, name)
            ?: throw Exception("Could not create the file")
        try {
            c.contentResolver.openOutputStream(out, "w")!!.use { o ->
                f.inputStream().use { it.copyTo(o, 256 * 1024) }
            }
        } catch (e: Exception) {
            try { DocumentsContract.deleteDocument(c.contentResolver, out) } catch (_: Exception) { }
            throw e
        }
        scan(c, out, mime)
        return out
    }

    /** "primary:Movies/HB/a.mp4" -> "/storage/emulated/0/Movies/HB/a.mp4" */
    private fun docIdToPath(docId: String): String? {
        val i = docId.indexOf(':')
        if (i < 0) return null
        val vol = docId.substring(0, i)
        val rel = docId.substring(i + 1)
        val base = if (vol == "primary") Environment.getExternalStorageDirectory().absolutePath else "/storage/$vol"
        return "$base/$rel"
    }

    /** Tells the gallery / music player about the new file so it shows up at once. */
    private fun scan(c: Context, uri: Uri, mime: String) {
        try {
            val path = docIdToPath(DocumentsContract.getDocumentId(uri)) ?: return
            MediaScannerConnection.scanFile(c, arrayOf(path), arrayOf(mime), null)
        } catch (_: Exception) {
        }
    }

    /** Deletes a downloaded file, wherever it was saved (gallery or picked folder). */
    fun delete(c: Context, uri: Uri): Boolean = try {
        if (DocumentsContract.isDocumentUri(c, uri)) DocumentsContract.deleteDocument(c.contentResolver, uri)
        else c.contentResolver.delete(uri, null, null) > 0
    } catch (_: Exception) {
        false
    }
}
