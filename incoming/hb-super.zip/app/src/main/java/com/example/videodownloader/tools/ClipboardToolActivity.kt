package com.example.videodownloader.tools

import android.content.ClipboardManager
import android.content.Context
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import com.example.videodownloader.R
import com.example.videodownloader.ui.BaseActivity
import com.example.videodownloader.ui.Hb
import com.example.videodownloader.util.Launcher

/** Reads the clipboard only while this screen is open; detects links, emails and phone numbers. */
class ClipboardToolActivity : BaseActivity() {

    private lateinit var body: LinearLayout
    private lateinit var refreshed: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val p = Hb.palette(this)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(p.bg)
        }
        root.addView(Hb.topBar(this, "Clipboard Tool", "Detect and use copied links", { finish() }))
        refreshed = Hb.text(this, "", 10.5f, p.muted).apply {
            setPadding(Hb.dp(this@ClipboardToolActivity, 20), 0, 0, Hb.dp(this@ClipboardToolActivity, 6))
        }
        root.addView(refreshed)
        val scroll = ScrollView(this).apply { isFillViewport = true }
        body = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(Hb.dp(this@ClipboardToolActivity, 16), 0, Hb.dp(this@ClipboardToolActivity, 16), Hb.dp(this@ClipboardToolActivity, 30))
        }
        scroll.addView(body)
        root.addView(scroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        setContentView(root)
        read()
    }

    override fun onResume() {
        super.onResume()
        if (::body.isInitialized) read()
    }

    private fun read() {
        body.removeAllViews()
        val p = Hb.palette(this)
        val text = try {
            val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            cm.primaryClip?.takeIf { it.itemCount > 0 }?.getItemAt(0)?.coerceToText(this)?.toString().orEmpty()
        } catch (_: Exception) {
            ""
        }
        refreshed.text = "Last checked: ${java.text.SimpleDateFormat("HH:mm:ss", java.util.Locale.getDefault()).format(java.util.Date())}"

        if (text.isBlank()) {
            body.addView(Hb.empty(this, R.drawable.ic_clipboard, "Clipboard is empty", "Copy a link or some text, then come back"))
            body.addView(Hb.button(this, "Check again", false, R.drawable.ic_refresh) { read() })
            return
        }

        val links = Regex("https?://[^\\s]+").findAll(text)
            .map { it.value.trimEnd('.', ',', ')', ']', '"') }
            .distinct()
            .toList()
        val emails = Regex("[\\w.+-]+@[\\w-]+\\.[\\w.]+").findAll(text).map { it.value }.distinct().toList()
        val phones = Regex("\\+?\\d[\\d\\s-]{7,}\\d").findAll(text).map { it.value.trim() }.distinct().toList()

        val card = Hb.card(this, 16)
        card.addView(Hb.text(this, "Clipboard text", 12f, p.blue, bold = true))
        val preview = Hb.text(this, text.take(1200), 14f, p.text).apply {
            setPadding(0, Hb.dp(this@ClipboardToolActivity, 6), 0, 0)
            setTextIsSelectable(true)
        }
        card.addView(preview)
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(0, Hb.dp(this@ClipboardToolActivity, 10), 0, 0)
        }
        row.addView(Hb.button(this, "Copy", true, R.drawable.ic_copy) {
            Launcher.copy(this@ClipboardToolActivity, text, "Copied")
        }, LinearLayout.LayoutParams(0, Hb.dp(this@ClipboardToolActivity, 46), 1f).apply { marginEnd = Hb.dp(this@ClipboardToolActivity, 8) })
        row.addView(Hb.button(this, "Share", false, R.drawable.ic_share) {
            Launcher.shareText(this@ClipboardToolActivity, text)
        }, LinearLayout.LayoutParams(0, Hb.dp(this@ClipboardToolActivity, 46), 1f))
        card.addView(row)
        body.addView(card)

        if (links.isNotEmpty()) {
            body.addView(Hb.section(this, "Links found"))
            val list = Hb.card(this, 6)
            links.forEachIndexed { index, link ->
                list.addView(Hb.row(this, R.drawable.ic_link, link, "Open in HB Browser") {
                    Launcher.openUrl(this, link)
                }.apply {
                    setOnLongClickListener {
                        Launcher.copy(this@ClipboardToolActivity, link, "Link copied")
                        true
                    }
                })
                if (index != links.lastIndex) list.addView(Hb.divider(this, 4))
            }
            body.addView(list)
            body.addView(Hb.button(this, "Copy all links", false, R.drawable.ic_copy) {
                Launcher.copy(this, links.joinToString("\n"), "${links.size} links copied")
            }.apply {
                (layoutParams as LinearLayout.LayoutParams).topMargin = Hb.dp(this@ClipboardToolActivity, 8)
            })
        }

        if (emails.isNotEmpty() || phones.isNotEmpty()) {
            body.addView(Hb.section(this, "Contacts"))
            val list = Hb.card(this, 6)
            emails.forEach { email ->
                list.addView(Hb.row(this, R.drawable.ic_text, email, "Email") { Launcher.copy(this, email, "Email copied") })
            }
            phones.forEach { phone ->
                list.addView(Hb.row(this, R.drawable.ic_text, phone, "Phone number") { Launcher.copy(this, phone, "Number copied") })
            }
            body.addView(list)
        }

        body.addView(Hb.button(this, "Check again", false, R.drawable.ic_refresh) { read() }.apply {
            (layoutParams as LinearLayout.LayoutParams).topMargin = Hb.dp(this@ClipboardToolActivity, 14)
        })
        body.addView(Hb.text(this, "The clipboard is read only on this screen. The app does not monitor the clipboard in the background.", 10.5f, p.muted).apply {
            setPadding(Hb.dp(this@ClipboardToolActivity, 4), Hb.dp(this@ClipboardToolActivity, 10), 0, 0)
        })
    }
}
