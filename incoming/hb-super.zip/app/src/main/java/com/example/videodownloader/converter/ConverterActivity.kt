package com.example.videodownloader.converter

import android.content.ContentValues
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ImageDecoder
import android.graphics.pdf.PdfDocument
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.lifecycle.lifecycleScope
import com.example.videodownloader.R
import com.example.videodownloader.ui.BaseActivity
import com.example.videodownloader.ui.Hb
import com.example.videodownloader.util.Fmt
import com.example.videodownloader.util.Launcher
import com.example.videodownloader.tools.PdfViewerActivity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.util.Locale

/**
 * Converter Studio. Every conversion is a real FFmpeg process (the binary that ships with
 * youtubedl-android) working on a local copy of the picked file; progress comes from FFmpeg's own
 * -progress stream, and Cancel really destroys the process. Images -> PDF uses Android's PdfDocument.
 */
class ConverterActivity : BaseActivity() {

    private enum class Op { MP3, AUDIO, TRIM, COMPRESS, IMAGE, GIF }

    private data class Result(val uri: Uri, val name: String, val where: String, val mime: String)

    private lateinit var root: LinearLayout
    private lateinit var progressCard: LinearLayout
    private lateinit var progressBar: android.widget.ProgressBar
    private lateinit var progressLabel: TextView
    private lateinit var progressTitle: TextView
    private lateinit var resultCard: LinearLayout

    private var pendingOp: Op? = null
    private var job: Job? = null
    private var process: Process? = null
    @Volatile private var cancelled = false
    private var result: Result? = null

    private val single = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        uri ?: return@registerForActivityResult
        val op = pendingOp ?: return@registerForActivityResult
        when (op) {
            Op.MP3 -> startMp3(uri)
            Op.AUDIO -> askAudioFormat(uri)
            Op.TRIM -> askTrim(uri)
            Op.COMPRESS -> askCompress(uri)
            Op.IMAGE -> askImageFormat(uri)
            Op.GIF -> askGif(uri)
        }
    }

    private val images = registerForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        if (uris.isNullOrEmpty()) return@registerForActivityResult
        lifecycleScope.launch {
            result = withContext(Dispatchers.IO) { imagesToPdf(uris) }
            renderResult()
        }
    }

    private val saveFolder = registerForActivityResult(ActivityResultContracts.OpenDocumentTree()) { tree ->
        tree ?: return@registerForActivityResult
        val r = result ?: return@registerForActivityResult
        lifecycleScope.launch {
            val ok = withContext(Dispatchers.IO) {
                try {
                    val dir = androidx.documentfile.provider.DocumentFile.fromTreeUri(this@ConverterActivity, tree)
                        ?: return@withContext false
                    val doc = dir.createFile(r.mime, r.name) ?: return@withContext false
                    contentResolver.openInputStream(r.uri)?.use { input ->
                        contentResolver.openOutputStream(doc.uri)?.use { o -> input.copyTo(o, 128 * 1024) }
                    }
                    true
                } catch (_: Exception) {
                    false
                }
            }
            Hb.toast(this@ConverterActivity, if (ok) "Saved a copy to the chosen folder" else "Could not save the copy")
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val p = Hb.palette(this)
        val shell = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(p.bg)
        }
        shell.addView(Hb.topBar(this, "Converter Studio", "MP3, trim, compress, PDF", { finish() }))
        val scroll = ScrollView(this).apply { isFillViewport = true }
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(Hb.dp(this@ConverterActivity, 16), 0, Hb.dp(this@ConverterActivity, 16), Hb.dp(this@ConverterActivity, 30))
        }
        scroll.addView(root)
        shell.addView(scroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        setContentView(shell)

        progressCard = buildProgress()
        resultCard = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; visibility = View.GONE }

        render()
    }

    private fun render() {
        root.removeAllViews()
        val p = Hb.palette(this)
        root.addView(progressCard)
        root.addView(resultCard)

        val hero = Hb.card(this, 18)
        hero.addView(Hb.text(this, "Convert on your phone", 18f, p.text, bold = true))
        hero.addView(Hb.text(this, "Files stay on the device. The app works on a local copy and saves the result to your media library.", 11.5f, p.muted).apply {
            setPadding(0, Hb.dp(this@ConverterActivity, 4), 0, 0)
        })
        root.addView(hero, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
            topMargin = Hb.dp(this@ConverterActivity, 4)
        })

        root.addView(Hb.section(this, "Video"))
        root.addView(optionRow(R.drawable.ic_music, "Video to MP3", "Extract the soundtrack as MP3") { pick(Op.MP3, arrayOf("video/*")) })
        root.addView(optionRow(R.drawable.ic_convert, "Trim video", "Keep only the part you choose") { pick(Op.TRIM, arrayOf("video/*")) })
        root.addView(optionRow(R.drawable.ic_zip, "Compress video", "Smaller H.264 file, three strengths") { pick(Op.COMPRESS, arrayOf("video/*")) })
        root.addView(optionRow(R.drawable.ic_image, "Video to GIF", "Animated GIF at 10 fps") { pick(Op.GIF, arrayOf("video/*")) })

        root.addView(Hb.section(this, "Audio"))
        root.addView(optionRow(R.drawable.ic_convert, "Convert audio", "MP3, M4A or WAV") { pick(Op.AUDIO, arrayOf("audio/*")) })
        root.addView(optionRow(R.drawable.ic_play, "Trim audio", "Cut a ringtone or clip") { pick(Op.TRIM, arrayOf("audio/*")) })

        root.addView(Hb.section(this, "Images & PDF"))
        root.addView(optionRow(R.drawable.ic_image, "Convert or compress image", "JPG, PNG or WEBP with quality control") { pick(Op.IMAGE, arrayOf("image/*")) })
        root.addView(optionRow(R.drawable.ic_pdf, "Images to PDF", "One page per image") {
            images.launch(arrayOf("image/*"))
        })
        root.addView(optionRow(R.drawable.ic_pdf, "Open a PDF", "Read it in the offline viewer") {
            startActivity(android.content.Intent(this, PdfViewerActivity::class.java))
        })

        val note = Hb.card(this, 14).apply {
            (layoutParams as LinearLayout.LayoutParams).topMargin = Hb.dp(this@ConverterActivity, 18)
        }
        note.addView(Hb.text(this, "Output", 14.5f, p.text, medium = true))
        note.addView(Hb.text(this, "Converted files go to Music/HB Converter, Movies/HB Converter, Pictures/HB Converter or Downloads/HB Converter. Only formats this build can really produce are offered.", 11.5f, p.muted).apply {
            setPadding(0, Hb.dp(this@ConverterActivity, 3), 0, 0)
        })
        root.addView(note)
    }

    private fun optionRow(icon: Int, title: String, sub: String, onTap: () -> Unit): LinearLayout {
        val p = Hb.palette(this)
        return LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            background = Hb.ripple(this@ConverterActivity, Hb.round(this@ConverterActivity, 16, p.surface, p.border, 1))
            setPadding(Hb.dp(this@ConverterActivity, 12), Hb.dp(this@ConverterActivity, 12),
                Hb.dp(this@ConverterActivity, 12), Hb.dp(this@ConverterActivity, 12))
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                bottomMargin = Hb.dp(this@ConverterActivity, 8)
            }
            addView(Hb.iconCircle(this@ConverterActivity, icon, p.blue, p.blueSoft, 42))
            addView(LinearLayout(this@ConverterActivity).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(Hb.dp(this@ConverterActivity, 12), 0, 0, 0)
                addView(Hb.text(this@ConverterActivity, title, 14.5f, p.text, medium = true))
                addView(Hb.text(this@ConverterActivity, sub, 11f, p.muted).apply {
                    setPadding(0, Hb.dp(this@ConverterActivity, 3), 0, 0)
                })
            }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            addView(Hb.icon(this@ConverterActivity, R.drawable.ic_chevron_right, p.muted, 18))
            Hb.clickable(this, onTap)
            Hb.pressScale(this)
        }
    }

    private fun pick(op: Op, mimes: Array<String>) {
        if (job?.isActive == true) {
            Hb.toast(this, "A conversion is already running")
            return
        }
        pendingOp = op
        single.launch(mimes)
    }

    // ------------------------------------------------------------- options

    private fun askAudioFormat(input: Uri) {
        val formats = arrayOf("MP3 (best compatibility)", "M4A / AAC", "WAV (uncompressed)")
        AlertDialog.Builder(this, R.style.HbDialog)
            .setTitle("Convert audio to")
            .setItems(formats) { _, which ->
                when (which) {
                    0 -> run(input, "mp3", "audio/mpeg", listOf("-vn", "-c:a", "libmp3lame", "-q:a", "2"))
                    1 -> run(input, "m4a", "audio/mp4", listOf("-vn", "-c:a", "aac", "-b:a", "192k"))
                    else -> run(input, "wav", "audio/wav", listOf("-vn", "-c:a", "pcm_s16le"))
                }
            }
            .show()
    }

    private fun askImageFormat(input: Uri) {
        val p = Hb.palette(this)
        val wrap = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(Hb.dp(this@ConverterActivity, 20), Hb.dp(this@ConverterActivity, 8), Hb.dp(this@ConverterActivity, 20), 0)
        }
        var format = 0
        var quality = 80
        wrap.addView(Hb.text(this, "Format", 12f, p.muted))
        val formats = listOf("JPG", "PNG", "WEBP")
        val chips = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val chipViews = ArrayList<TextView>()
        formats.forEachIndexed { index, label ->
            val chip = Hb.chip(this, label, index == 0).apply {
                setOnClickListener {
                    format = index
                    chipViews.forEachIndexed { i, v -> v.background = if (i == index) Hb.round(this@ConverterActivity, 40, p.blue) else Hb.round(this@ConverterActivity, 40, p.surfaceAlt, p.border, 1) }
                }
                (layoutParams as? LinearLayout.LayoutParams)?.marginEnd = Hb.dp(this@ConverterActivity, 8)
            }
            chipViews.add(chip)
            chips.addView(chip, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                marginEnd = Hb.dp(this@ConverterActivity, 8)
            })
        }
        wrap.addView(chips)
        wrap.addView(Hb.text(this, "Quality", 12f, p.muted).apply { setPadding(0, Hb.dp(this@ConverterActivity, 14), 0, 4) })
        val qualityText = Hb.text(this, "80%", 14f, p.text, medium = true)
        wrap.addView(qualityText)
        wrap.addView(android.widget.SeekBar(this).apply {
            max = 100
            progress = quality
            setOnSeekBarChangeListener(object : android.widget.SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(bar: android.widget.SeekBar?, value: Int, fromUser: Boolean) {
                    quality = value.coerceIn(20, 100)
                    qualityText.text = "$quality%"
                }
                override fun onStartTrackingTouch(bar: android.widget.SeekBar?) {}
                override fun onStopTrackingTouch(bar: android.widget.SeekBar?) {}
            })
        })
        AlertDialog.Builder(this, R.style.HbDialog)
            .setTitle("Image output")
            .setView(wrap)
            .setPositiveButton("Convert") { _, _ ->
                val mime = when (format) { 0 -> "image/jpeg"; 1 -> "image/png"; else -> "image/webp" }
                val ext = when (format) { 0 -> "jpg"; 1 -> "png"; else -> "webp" }
                convertImage(input, mime, ext, quality)
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun askCompress(input: Uri) {
        val levels = arrayOf("Light (better quality)", "Standard (balanced)", "Strong (smallest)")
        AlertDialog.Builder(this, R.style.HbDialog)
            .setTitle("Compression strength")
            .setItems(levels) { _, which ->
                val crf = when (which) { 0 -> "20"; 1 -> "24"; else -> "30" }
                run(input, "mp4", "video/mp4", listOf(
                    "-c:v", "libx264", "-preset", "veryfast", "-crf", crf,
                    "-c:a", "aac", "-b:a", "128k", "-movflags", "+faststart"
                ), suffix = "_compressed")
            }
            .show()
    }

    private fun askTrim(input: Uri) {
        val p = Hb.palette(this)
        val wrap = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(Hb.dp(this@ConverterActivity, 20), Hb.dp(this@ConverterActivity, 8), Hb.dp(this@ConverterActivity, 20), 0)
        }
        fun field(hint: String, value: String): EditText = EditText(this).apply {
            this.hint = hint
            setText(value)
            setTextColor(p.text)
            setHintTextColor(p.muted)
            background = Hb.round(this@ConverterActivity, 12, p.surfaceAlt, p.border, 1)
            setPadding(Hb.dp(this@ConverterActivity, 12), Hb.dp(this@ConverterActivity, 9), Hb.dp(this@ConverterActivity, 12), Hb.dp(this@ConverterActivity, 9))
            inputType = android.text.InputType.TYPE_CLASS_NUMBER or android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL
        }
        val start = field("Start (seconds)", "0")
        val end = field("End (seconds)", "")
        wrap.addView(Hb.text(this, "Start (seconds)", 11.5f, p.muted))
        wrap.addView(start)
        wrap.addView(Hb.text(this, "End (seconds, blank = end of file)", 11.5f, p.muted).apply { setPadding(0, Hb.dp(this@ConverterActivity, 10), 0, 0) })
        wrap.addView(end)
        wrap.addView(Hb.text(this, "The app re-encodes the clip so the cut is accurate.", 10.5f, p.muted).apply {
            setPadding(0, Hb.dp(this@ConverterActivity, 8), 0, 0)
        })
        val dialog = AlertDialog.Builder(this, R.style.HbDialog)
            .setTitle("Trim")
            .setView(wrap)
            .setPositiveButton("Trim", null)
            .setNegativeButton("Cancel", null)
            .create()
        dialog.setOnShowListener {
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setTextColor(p.blue)
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                val s = start.text.toString().toDoubleOrNull() ?: 0.0
                val e = end.text.toString().toDoubleOrNull()
                if (s < 0 || (e != null && e <= s)) {
                    Hb.toast(this, "End must be greater than start")
                    return@setOnClickListener
                }
                dialog.dismiss()
                val isAudio = Fmt.mime(this, input).startsWith("audio/")
                val startArgs = if (s > 0) listOf("-ss", String.format(Locale.US, "%.3f", s)) else emptyList()
                val lengthArgs = if (e != null) listOf("-t", String.format(Locale.US, "%.3f", e - s)) else emptyList()
                if (isAudio) {
                    run(input, "mp3", "audio/mpeg",
                        lengthArgs + listOf("-vn", "-c:a", "libmp3lame", "-q:a", "2"),
                        startArgs, "_trimmed")
                } else {
                    run(input, "mp4", "video/mp4",
                        lengthArgs + listOf("-c:v", "libx264", "-preset", "veryfast", "-crf", "23",
                            "-c:a", "aac", "-b:a", "128k", "-movflags", "+faststart"),
                        startArgs, "_trimmed")
                }
            }
        }
        dialog.show()
    }

    private fun askGif(input: Uri) {
        AlertDialog.Builder(this, R.style.HbDialog)
            .setTitle("GIF length")
            .setItems(arrayOf("First 10 seconds", "Whole video")) { _, which ->
                val length = if (which == 0) listOf("-t", "10") else emptyList()
                run(input, "gif", "image/gif",
                    length + listOf("-vf", "fps=10,scale=480:-1:flags=lanczos", "-loop", "0"),
                    suffix = "_short")
            }
            .show()
    }

    // ------------------------------------------------------------ ffmpeg

    private fun startMp3(input: Uri) {
        run(input, "mp3", "audio/mpeg", listOf("-vn", "-c:a", "libmp3lame", "-q:a", "2"))
    }

    /**
     * [beforeInput] is placed before -i (fast seek), [codecArgs] after -i. Progress reporting and the
     * output path are added by [startJob].
     */
    private fun run(
        input: Uri,
        outExt: String,
        outMime: String,
        codecArgs: List<String>,
        beforeInput: List<String> = emptyList(),
        suffix: String = "_converted"
    ) {
        startJob(input, "Converting…", beforeInput, codecArgs, outExt, outMime, suffix)
    }

    private fun buildFfmpegArgs(input: File, out: File, beforeInput: List<String>, codecArgs: List<String>): List<String> {
        val args = ArrayList<String>()
        args.add(ffmpegPath())
        args.addAll(listOf("-y", "-nostdin", "-hide_banner", "-loglevel", "error"))
        args.addAll(beforeInput)
        args.add("-i")
        args.add(input.absolutePath)
        args.addAll(codecArgs)
        args.addAll(listOf("-progress", "pipe:1", "-nostats"))
        args.add(out.absolutePath)
        return args
    }

    private fun ffmpegPath(): String {
        val bundled = File(applicationInfo.nativeLibraryDir, "libffmpeg.so")
        if (bundled.exists()) return bundled.absolutePath
        return "ffmpeg"
    }

    private fun startJob(
        input: Uri,
        title: String,
        beforeInput: List<String>,
        codecArgs: List<String>,
        outExt: String,
        outMime: String,
        suffix: String
    ) {
        if (job?.isActive == true) {
            Hb.toast(this, "A conversion is already running")
            return
        }
        cancelled = false
        result = null
        renderResult()
        progressCard.visibility = View.VISIBLE
        progressTitle.text = title
        progressLabel.text = "Preparing the file…"
        progressBar.progress = 0
        job = lifecycleScope.launch {
            val outcome = withContext(Dispatchers.IO) {
                var tempIn: File? = null
                var tempOut: File? = null
                try {
                    tempIn = copyToTemp(input, "input")
                    val base = Fmt.base(Fmt.name(this@ConverterActivity, input))
                    tempOut = File(cacheDir, "conv_${System.currentTimeMillis()}.$outExt")
                    val duration = mediaDuration(tempIn)
                    executeFfmpeg(buildFfmpegArgs(tempIn, tempOut, beforeInput, codecArgs), tempOut, duration)
                    if (cancelled) return@withContext "Cancelled"
                    if (!tempOut.exists() || tempOut.length() < 100) return@withContext "The converter produced no output"
                    val name = Fmt.safeName(base) + suffix + "." + outExt
                    val published = publish(tempOut, name, outMime)
                    if (published == null) return@withContext "Could not save the result"
                    result = Result(published.first, name, published.second, outMime)
                    null
                } catch (e: Exception) {
                    if (cancelled) "Cancelled" else "Conversion failed: ${e.message ?: "unknown error"}"
                } finally {
                    tempIn?.delete()
                    tempOut?.delete()
                }
            }
            progressCard.visibility = View.GONE
            if (outcome != null) {
                if (outcome != "Cancelled") Hb.alert(this@ConverterActivity, "Conversion", outcome)
            } else {
                renderResult()
            }
        }
    }

    private fun executeFfmpeg(args: List<String>, out: File, durationMs: Long) {
        val pb = ProcessBuilder(args).redirectErrorStream(false)
        val packages = File(noBackupFilesDir, "youtubedl-android/packages")
        val libPath = listOf("python", "ffmpeg", "aria2c")
            .joinToString(":") { File(packages, "$it/usr/lib").absolutePath }
        pb.environment()["LD_LIBRARY_PATH"] = libPath
        pb.environment()["TMPDIR"] = cacheDir.absolutePath
        val p = pb.start()
        process = p
        val errorText = StringBuilder()
        val errorThread = Thread {
            try {
                p.errorStream.bufferedReader().forEachLine { line ->
                    if (errorText.length < 4000) errorText.append(line).append('\n')
                }
            } catch (_: Exception) {
            }
        }
        errorThread.isDaemon = true
        errorThread.start()

        try {
            p.inputStream.bufferedReader().forEachLine { line ->
                if (cancelled) return@forEachLine
                val us = when {
                    line.startsWith("out_time_us=") -> line.substringAfter('=').toLongOrNull()
                    line.startsWith("out_time_ms=") -> line.substringAfter('=').toLongOrNull()
                    else -> null
                }
                if (us != null && durationMs > 0) {
                    val pct = ((us / 1000.0) / durationMs.toDouble() * 100.0).toInt().coerceIn(0, 99)
                    runOnUiThread {
                        progressBar.progress = pct
                        progressLabel.text = "$pct% • ${Fmt.bytes(out.length())} written"
                    }
                }
            }
            p.waitFor()
        } finally {
            process = null
        }
        if (cancelled) throw Exception("Cancelled")
        if (p.exitValue() != 0) {
            val last = errorText.lines().lastOrNull { it.isNotBlank() } ?: "FFmpeg stopped with code ${p.exitValue()}"
            throw Exception(last.take(180))
        }
    }

    private fun mediaDuration(file: File): Long {
        return try {
            val r = MediaMetadataRetriever()
            r.setDataSource(file.absolutePath)
            val ms = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
            r.release()
            ms
        } catch (_: Exception) {
            0L
        }
    }

    // --------------------------------------------------------- image / PDF

    private fun convertImage(input: Uri, mime: String, ext: String, quality: Int) {
        if (job?.isActive == true) {
            Hb.toast(this, "A conversion is already running")
            return
        }
        cancelled = false
        result = null
        renderResult()
        progressCard.visibility = View.VISIBLE
        progressTitle.text = "Converting image…"
        progressLabel.text = "Decoding…"
        progressBar.progress = 20
        job = lifecycleScope.launch {
            val outcome = withContext(Dispatchers.IO) {
                try {
                    val bitmap = decode(input)
                    val out = File(cacheDir, "img_${System.currentTimeMillis()}.$ext")
                    val format = when (ext) {
                        "png" -> Bitmap.CompressFormat.PNG
                        "webp" -> if (Build.VERSION.SDK_INT >= 30) Bitmap.CompressFormat.WEBP_LOSSY else Bitmap.CompressFormat.WEBP
                        else -> Bitmap.CompressFormat.JPEG
                    }
                    FileOutputStream(out).use { o -> bitmap.compress(format, quality, o) }
                    bitmap.recycle()
                    val name = Fmt.safeName(Fmt.base(Fmt.name(this@ConverterActivity, input))) + "_hb.$ext"
                    val published = publish(out, name, mime)
                    out.delete()
                    if (published == null) "Could not save the image" else {
                        result = Result(published.first, name, published.second, mime)
                        null
                    }
                } catch (e: Exception) {
                    "Image conversion failed: ${e.message ?: "error"}"
                }
            }
            progressCard.visibility = View.GONE
            if (outcome != null) Hb.alert(this@ConverterActivity, "Image", outcome) else renderResult()
        }
    }

    private fun decode(uri: Uri): Bitmap {
        return if (Build.VERSION.SDK_INT >= 28) {
            val source = ImageDecoder.createSource(contentResolver, uri)
            ImageDecoder.decodeBitmap(source) { decoder, info, _ ->
                decoder.allocator = ImageDecoder.ALLOCATOR_SOFTWARE
                val maxSide = 4096
                val w = info.size.width
                val h = info.size.height
                if (w > maxSide || h > maxSide) {
                    val scale = maxSide.toFloat() / maxOf(w, h).toFloat()
                    decoder.setTargetSize((w * scale).toInt(), (h * scale).toInt())
                }
            }
        } else {
            val opts = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) }
            var sample = 1
            while (opts.outWidth / sample > 4096 || opts.outHeight / sample > 4096) sample *= 2
            val real = BitmapFactory.Options().apply { inSampleSize = sample }
            contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, real) }
                ?: throw Exception("Could not read the image")
        }
    }

    private fun imagesToPdf(uris: List<Uri>): Result? {
        return try {
            val doc = PdfDocument()
            val pageW = 1240
            val pageH = 1754
            uris.forEachIndexed { index, uri ->
                val bitmap = decode(uri)
                val page = doc.startPage(PdfDocument.PageInfo.Builder(pageW, pageH, index + 1).create())
                val canvas: Canvas = page.canvas
                canvas.drawColor(Color.WHITE)
                val margin = 48f
                val availW = pageW - margin * 2
                val availH = pageH - margin * 2
                val scale = minOf(availW / bitmap.width, availH / bitmap.height)
                val w = bitmap.width * scale
                val h = bitmap.height * scale
                canvas.drawBitmap(bitmap, null, android.graphics.RectF((pageW - w) / 2f, (pageH - h) / 2f, (pageW + w) / 2f, (pageH + h) / 2f), null)
                doc.finishPage(page)
                bitmap.recycle()
            }
            val out = File(cacheDir, "hb_${System.currentTimeMillis()}.pdf")
            FileOutputStream(out).use { doc.writeTo(it) }
            doc.close()
            val name = "HB_Images_${System.currentTimeMillis()}.pdf"
            val published = publish(out, name, "application/pdf")
            out.delete()
            if (published == null) null else Result(published.first, name, published.second, "application/pdf")
        } catch (e: Exception) {
            runOnUiThread { Hb.alert(this, "Images to PDF", "Could not create the PDF: ${e.message ?: "error"}") }
            null
        }
    }

    // ------------------------------------------------------------ helpers

    private fun copyToTemp(uri: Uri, tag: String): File {
        val out = File(cacheDir, "${tag}_${System.currentTimeMillis()}")
        contentResolver.openInputStream(uri)?.use { input ->
            FileOutputStream(out).use { o -> input.copyTo(o, 256 * 1024) }
        } ?: throw Exception("Could not read the selected file")
        return out
    }

    private fun publish(file: File, name: String, mime: String): Pair<Uri, String>? {
        val (collection, relative) = when {
            mime.startsWith("audio/") -> MediaStore.Audio.Media.EXTERNAL_CONTENT_URI to Environment.DIRECTORY_MUSIC + "/HB Converter"
            mime.startsWith("video/") -> MediaStore.Video.Media.EXTERNAL_CONTENT_URI to Environment.DIRECTORY_MOVIES + "/HB Converter"
            mime.startsWith("image/") && mime != "image/gif" -> MediaStore.Images.Media.EXTERNAL_CONTENT_URI to Environment.DIRECTORY_PICTURES + "/HB Converter"
            else -> MediaStore.Downloads.EXTERNAL_CONTENT_URI to Environment.DIRECTORY_DOWNLOADS + "/HB Converter"
        }
        val values = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, name)
            put(MediaStore.MediaColumns.MIME_TYPE, mime)
            put(MediaStore.MediaColumns.RELATIVE_PATH, relative)
            put(MediaStore.MediaColumns.IS_PENDING, 1)
        }
        val uri = contentResolver.insert(collection, values) ?: return null
        return try {
            contentResolver.openOutputStream(uri)?.use { o ->
                file.inputStream().use { it.copyTo(o, 256 * 1024) }
            } ?: throw Exception("No output stream")
            contentResolver.update(uri, ContentValues().apply { put(MediaStore.MediaColumns.IS_PENDING, 0) }, null, null)
            uri to "$relative/$name"
        } catch (e: Exception) {
            runCatching { contentResolver.delete(uri, null, null) }
            null
        }
    }

    private fun renderResult() {
        resultCard.removeAllViews()
        val r = result ?: run {
            resultCard.visibility = View.GONE
            return
        }
        val p = Hb.palette(this)
        resultCard.visibility = View.VISIBLE
        val card = Hb.card(this, 16).apply {
            setBackgroundColor(p.surface)
            (layoutParams as LinearLayout.LayoutParams).topMargin = Hb.dp(this@ConverterActivity, 6)
            (layoutParams as LinearLayout.LayoutParams).bottomMargin = Hb.dp(this@ConverterActivity, 10)
        }
        card.addView(Hb.text(this, "Ready", 16f, p.success, bold = true))
        card.addView(Hb.text(this, r.name, 14f, p.text, medium = true).apply {
            setPadding(0, Hb.dp(this@ConverterActivity, 4), 0, 0)
        })
        card.addView(Hb.text(this, r.where, 10.5f, p.muted))
        val buttons = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(0, Hb.dp(this@ConverterActivity, 10), 0, 0)
        }
        buttons.addView(Hb.button(this, "Open", true, R.drawable.ic_play) {
            Launcher.openFile(this@ConverterActivity, r.uri, r.mime)
        }, LinearLayout.LayoutParams(0, Hb.dp(this@ConverterActivity, 46), 1f).apply {
            marginEnd = Hb.dp(this@ConverterActivity, 8)
        })
        buttons.addView(Hb.button(this, "Share", false, R.drawable.ic_share) {
            Launcher.shareFile(this@ConverterActivity, r.uri, r.mime)
        }, LinearLayout.LayoutParams(0, Hb.dp(this@ConverterActivity, 46), 1f))
        card.addView(buttons)
        card.addView(Hb.button(this, "Save a copy to a folder", false, R.drawable.ic_folder) {
            saveFolder.launch(null)
        }.apply {
            (layoutParams as LinearLayout.LayoutParams).topMargin = Hb.dp(this@ConverterActivity, 8)
        })
        resultCard.addView(card)
    }

    private fun buildProgress(): LinearLayout {
        val p = Hb.palette(this)
        val card = Hb.card(this, 16).apply { visibility = View.GONE }
        progressTitle = Hb.text(this, "Converting…", 15f, p.text, bold = true)
        progressLabel = Hb.text(this, "", 11.5f, p.muted).apply { setPadding(0, Hb.dp(this@ConverterActivity, 4), 0, Hb.dp(this@ConverterActivity, 8)) }
        progressBar = Hb.progress(this).apply {
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, Hb.dp(this@ConverterActivity, 8))
        }
        card.addView(progressTitle)
        card.addView(progressLabel)
        card.addView(progressBar)
        card.addView(Hb.button(this, "Cancel conversion", false, R.drawable.ic_close) {
            cancelled = true
            process?.destroy()
            progressLabel.text = "Cancelling…"
        }.apply {
            (layoutParams as LinearLayout.LayoutParams).topMargin = Hb.dp(this@ConverterActivity, 10)
        })
        return card
    }

    override fun onDestroy() {
        super.onDestroy()
        cancelled = true
        process?.destroy()
        job?.cancel()
    }
}
