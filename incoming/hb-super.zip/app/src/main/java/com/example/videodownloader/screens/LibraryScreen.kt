package com.example.videodownloader.screens

import android.content.Intent
import android.os.Environment
import android.os.StatFs
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.TextView
import androidx.core.view.isVisible
import androidx.lifecycle.lifecycleScope
import com.example.videodownloader.HistoryActivity
import com.example.videodownloader.HistoryStore
import com.example.videodownloader.MainActivity
import com.example.videodownloader.R
import com.example.videodownloader.browser.BrowserBookmarksActivity
import com.example.videodownloader.browser.BrowserStore
import com.example.videodownloader.browser.BrowserUrl
import com.example.videodownloader.files.FileManagerActivity
import com.example.videodownloader.files.FileSearchActivity
import com.example.videodownloader.ui.Hb
import com.example.videodownloader.ui.Screen
import com.example.videodownloader.util.Fmt
import com.example.videodownloader.util.Launcher
import com.example.videodownloader.util.MediaIndex
import com.example.videodownloader.util.RecentStore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

class LibraryScreen(private val act: MainActivity) : Screen {

    override val root: View
    private val col: LinearLayout
    private lateinit var statsRow: LinearLayout
    private lateinit var recentBox: LinearLayout
    private lateinit var downloadsBox: LinearLayout
    private lateinit var bookmarksBox: LinearLayout
    private lateinit var storageBar: ProgressBar
    private lateinit var storageText: TextView
    private lateinit var storageSub: TextView
    private var generation = 0

    init {
        val c = act
        val p = Hb.palette(c)
        col = Hb.column(c, 18)
        col.addView(header())
        col.addView(Hb.spacer(c, 10))

        statsRow = LinearLayout(c).apply { orientation = LinearLayout.HORIZONTAL }
        col.addView(statsRow)

        col.addView(Hb.section(c, "Recently played", "Player") {
            Launcher.openTool(c, com.example.videodownloader.util.Tool.PLAYER)
        })
        recentBox = LinearLayout(c).apply { orientation = LinearLayout.VERTICAL }
        col.addView(recentBox)

        col.addView(Hb.section(c, "Downloads", "History") {
            c.startActivity(Intent(c, HistoryActivity::class.java))
        })
        downloadsBox = LinearLayout(c).apply { orientation = LinearLayout.VERTICAL }
        col.addView(downloadsBox)

        col.addView(Hb.section(c, "Bookmarks", "Manage") {
            c.startActivity(Intent(c, BrowserBookmarksActivity::class.java))
        })
        bookmarksBox = LinearLayout(c).apply { orientation = LinearLayout.VERTICAL }
        col.addView(bookmarksBox)

        col.addView(Hb.section(c, "Browse files"))
        col.addView(categoriesCard())

        col.addView(Hb.section(c, "Storage"))
        col.addView(storageCard())

        col.addView(Hb.spacer(c, 22))
        col.addView(Hb.text(c, "HB Super App 1.0 • Library", 10.5f, p.muted).apply { gravity = Gravity.CENTER })

        root = Hb.scroll(c, col)
        refresh()
    }

    private fun header(): LinearLayout = LinearLayout(act).apply {
        orientation = LinearLayout.HORIZONTAL
        gravity = Gravity.CENTER_VERTICAL
        addView(LinearLayout(act).apply {
            orientation = LinearLayout.VERTICAL
            addView(Hb.text(act, "Library", 25f, Hb.palette(act).text, bold = true))
            addView(Hb.text(act, "Everything you saved, played and bookmarked", 11.5f, Hb.palette(act).muted))
        }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        addView(Hb.iconButton(act, R.drawable.ic_search, Hb.palette(act).text, 42) {
            act.startActivity(Intent(act, FileSearchActivity::class.java))
        })
    }

    private fun categoriesCard(): LinearLayout {
        val card = Hb.card(act, 6)
        val rows = listOf(
            Triple("videos", "Videos", R.drawable.ic_play),
            Triple("music", "Music", R.drawable.ic_music),
            Triple("images", "Photos", R.drawable.ic_image),
            Triple("documents", "Documents", R.drawable.ic_pdf),
            Triple("downloads", "Downloads folder", R.drawable.ic_download),
            Triple("apk", "APK files", R.drawable.ic_file),
            Triple("other", "Other files", R.drawable.ic_folder)
        )
        rows.forEachIndexed { index, (id, title, icon) ->
            card.addView(Hb.row(act, icon, title, null) {
                act.startActivity(Intent(act, FileManagerActivity::class.java).putExtra(FileManagerActivity.EXTRA_CATEGORY, id))
            })
            if (index != rows.lastIndex) card.addView(Hb.divider(act, 46))
        }
        return card
    }

    private fun storageCard(): LinearLayout {
        val p = Hb.palette(act)
        val card = Hb.card(act, 16)
        storageText = Hb.text(act, "Calculating…", 15f, p.text, bold = true)
        storageSub = Hb.text(act, "", 11.5f, p.muted)
        card.addView(storageText)
        card.addView(storageSub)
        storageBar = Hb.progress(act).apply {
            max = 100
            progress = 0
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, Hb.dp(act, 8)).apply {
                topMargin = Hb.dp(act, 10)
            }
        }
        card.addView(storageBar)
        card.addView(Hb.spacer(act, 6))
        card.addView(Hb.text(act, "Media, downloads and app data are included. Tap Storage Analyzer for a full breakdown.",
            10.5f, p.muted))
        card.addView(Hb.button(act, "Open Storage Analyzer", primary = false, iconRes = R.drawable.ic_storage, heightDp = 44) {
            Launcher.openTool(act, com.example.videodownloader.util.Tool.STORAGE)
        }.apply { (layoutParams as LinearLayout.LayoutParams).topMargin = Hb.dp(act, 10) })
        return card
    }

    override fun onShow() {
    }

    override fun onHide() {
    }

    override fun onBack(): Boolean = false

    override fun refresh() {
        val gen = ++generation
        act.lifecycleScope.launch {
            statsRow.removeAllViews()
            statsRow.addView(placeholderStat("Videos"), statParams())
            statsRow.addView(placeholderStat("Music"), statParams())
            statsRow.addView(placeholderStat("Photos"), statParams())
            val counts = withContext(Dispatchers.IO) {
                Triple(
                    MediaIndex.videos(act, 500).size,
                    MediaIndex.audio(act, 500).size,
                    MediaIndex.images(act, 500).size
                )
            }
            if (gen != generation) return@launch
            statsRow.removeAllViews()
            statsRow.addView(Hb.stat(act, "Videos", counts.first.toString(), Hb.palette(act).blue), statParams())
            statsRow.addView(Hb.stat(act, "Music", counts.second.toString(), Hb.palette(act).success), statParams())
            statsRow.addView(Hb.stat(act, "Photos", counts.third.toString(), Hb.palette(act).warning), statParams())
        }

        renderRecent()
        renderDownloads()
        renderBookmarks()
        loadStorage()
    }

    private fun statParams(): LinearLayout.LayoutParams =
        LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply {
            marginEnd = Hb.dp(act, 8)
        }

    private fun placeholderStat(label: String): LinearLayout {
        val p = Hb.palette(act)
        return LinearLayout(act).apply {
            orientation = LinearLayout.VERTICAL
            background = Hb.round(act, 16, p.surfaceAlt, p.border, 1)
            setPadding(Hb.dp(act, 12), Hb.dp(act, 11), Hb.dp(act, 12), Hb.dp(act, 11))
            addView(Hb.text(act, "…", 16f, p.muted, bold = true))
            addView(Hb.text(act, label, 10.5f, p.muted).apply { setPadding(0, Hb.dp(act, 3), 0, 0) })
        }
    }

    private fun renderRecent() {
        recentBox.removeAllViews()
        val items = RecentStore.all(act).take(6)
        if (items.isEmpty()) {
            recentBox.addView(Hb.empty(act, R.drawable.ic_play, "Nothing played yet",
                "Open a video or a song and it will appear here with your playback position."))
            return
        }
        val card = Hb.card(act, 6)
        items.forEachIndexed { index, item ->
            val sub = if (item.positionMs > 0 && item.durationMs > 0) {
                "Resume at ${Fmt.duration(item.positionMs)} • ${Fmt.ago(item.at)}"
            } else {
                if (item.durationMs > 0) "${Fmt.duration(item.durationMs)} • ${Fmt.ago(item.at)}" else Fmt.ago(item.at)
            }
            card.addView(Hb.row(act, if (item.mime.startsWith("audio/")) R.drawable.ic_music else R.drawable.ic_play,
                item.name, sub) {
                Launcher.playMedia(act, android.net.Uri.parse(item.uri), item.mime, item.name)
            })
            if (index != items.lastIndex) card.addView(Hb.divider(act, 46))
        }
        recentBox.addView(card)
    }

    private fun renderDownloads() {
        downloadsBox.removeAllViews()
        val items = HistoryStore.all(act).filter { it.ok && it.uri != null }.take(6)
        if (items.isEmpty()) {
            downloadsBox.addView(Hb.empty(act, R.drawable.ic_download, "No downloads yet",
                "Videos and MP3 files you download appear here."))
            return
        }
        val card = Hb.card(act, 6)
        items.forEachIndexed { index, item ->
            card.addView(Hb.row(act, if (HistoryStore.isAudioItem(item)) R.drawable.ic_music else R.drawable.ic_play,
                item.title, "${item.quality} • ${Fmt.ago(item.time)}") {
                val uri = item.uri?.let { android.net.Uri.parse(it) } ?: return@row
                Launcher.openFile(act, uri, item.mime ?: "*/*")
            })
            if (index != items.lastIndex) card.addView(Hb.divider(act, 46))
        }
        downloadsBox.addView(card)
    }

    private fun renderBookmarks() {
        bookmarksBox.removeAllViews()
        val books = BrowserStore.bookmarks(act).take(5)
        if (books.isEmpty()) {
            bookmarksBox.addView(Hb.empty(act, R.drawable.ic_star, "No bookmarks yet",
                "Tap the star in HB Browser to keep a page here."))
            return
        }
        val card = Hb.card(act, 6)
        books.forEachIndexed { index, b ->
            card.addView(Hb.row(act, R.drawable.ic_star, b.title.ifBlank { BrowserUrl.display(b.url) },
                BrowserUrl.display(b.url), trailing = b.folder, iconTint = Hb.palette(act).warning) {
                Launcher.openUrl(act, b.url)
            })
            if (index != books.lastIndex) card.addView(Hb.divider(act, 46))
        }
        bookmarksBox.addView(card)
    }

    private fun loadStorage() {
        act.lifecycleScope.launch {
            val data = withContext(Dispatchers.IO) {
                try {
                    val stat = StatFs(Environment.getExternalStorageDirectory().absolutePath)
                    val total = stat.blockCountLong * stat.blockSizeLong
                    val free = stat.availableBlocksLong * stat.blockSizeLong
                    Triple(total, free, MediaIndex.allSize(act))
                } catch (_: Exception) {
                    Triple(0L, 0L, 0L)
                }
            }
            if (!::storageText.isInitialized) return@launch
            val total = data.first
            val free = data.second
            if (total <= 0) {
                storageText.text = "Storage unavailable"
                storageSub.text = "Android did not report free space"
                storageBar.progress = 0
                return@launch
            }
            val used = total - free
            val pct = ((used * 100) / total).toInt().coerceIn(0, 100)
            storageText.text = "${Fmt.bytes(used)} used of ${Fmt.bytes(total)}"
            storageSub.text = "${Fmt.bytes(free)} free • ${Fmt.bytes(data.third)} in media"
            storageBar.progress = pct
        }
    }
}
