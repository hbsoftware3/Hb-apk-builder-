package com.example.videodownloader.browser

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

data class HistoryEntry(
    val id: String,
    val url: String,
    val title: String,
    val time: Long
)

data class Bookmark(
    val id: String,
    val url: String,
    val title: String,
    val folder: String,
    val time: Long
)

data class SavedTab(
    val url: String,
    val title: String
)

/**
 * Browser history, bookmarks and the normal-tab session.
 * Everything stays on the device inside the app's private storage.
 */
object BrowserStore {

    private const val PREFS = "hb_browser"
    private const val KEY_HISTORY = "history"
    private const val KEY_BOOKMARKS = "bookmarks"
    private const val KEY_FOLDERS = "bookmark_folders"
    private const val KEY_TABS = "saved_tabs"
    private const val MAX_HISTORY = 800

    private fun sp(c: Context) = c.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    // ---------------- History ----------------

    fun history(c: Context): List<HistoryEntry> = readHistory(c).sortedByDescending { it.time }

    fun searchHistory(c: Context, query: String): List<HistoryEntry> {
        val q = query.trim().lowercase()
        val all = history(c)
        if (q.isEmpty()) return all
        return all.filter { it.url.lowercase().contains(q) || it.title.lowercase().contains(q) }
    }

    /** One row per address; repeated visits move the page to the top instead of duplicating it. */
    fun addHistory(c: Context, url: String, title: String) {
        if (!BrowserUrl.isHttp(url)) return
        val list = readHistory(c)
        val existing = list.firstOrNull { it.url == url }
        val fresh = HistoryEntry(
            id = existing?.id ?: UUID.randomUUID().toString(),
            url = url,
            title = title.trim().ifBlank { BrowserUrl.display(url) },
            time = System.currentTimeMillis()
        )
        val out = ArrayList<HistoryEntry>()
        out.add(fresh)
        out.addAll(list.filter { it.url != url }.take(MAX_HISTORY - 1))
        writeHistory(c, out)
    }

    fun removeHistory(c: Context, id: String) {
        writeHistory(c, readHistory(c).filter { it.id != id })
    }

    fun clearHistory(c: Context) {
        sp(c).edit().remove(KEY_HISTORY).apply()
    }

    private fun readHistory(c: Context): MutableList<HistoryEntry> {
        val out = ArrayList<HistoryEntry>()
        val raw = sp(c).getString(KEY_HISTORY, null) ?: return out
        try {
            val arr = JSONArray(raw)
            for (i in 0 until arr.length()) {
                val o = arr.optJSONObject(i) ?: continue
                val url = o.optString("url")
                if (url.isBlank()) continue
                out.add(HistoryEntry(
                    o.optString("id", UUID.randomUUID().toString()),
                    url,
                    o.optString("title"),
                    o.optLong("time")
                ))
            }
        } catch (_: Exception) {
        }
        return out
    }

    private fun writeHistory(c: Context, list: List<HistoryEntry>) {
        val arr = JSONArray()
        list.take(MAX_HISTORY).forEach {
            arr.put(JSONObject().apply {
                put("id", it.id)
                put("url", it.url)
                put("title", it.title)
                put("time", it.time)
            })
        }
        sp(c).edit().putString(KEY_HISTORY, arr.toString()).apply()
    }

    // ---------------- Bookmarks ----------------

    fun folders(c: Context): List<String> {
        val raw = sp(c).getString(KEY_FOLDERS, null) ?: return DEFAULT_FOLDERS
        return try {
            val arr = JSONArray(raw)
            val out = ArrayList<String>()
            for (i in 0 until arr.length()) arr.optString(i).takeIf { it.isNotBlank() }?.let { out.add(it) }
            out.ifEmpty { DEFAULT_FOLDERS }
        } catch (_: Exception) {
            DEFAULT_FOLDERS
        }
    }

    fun addFolder(c: Context, name: String): Boolean {
        val clean = name.trim()
        if (clean.isEmpty()) return false
        val list = ArrayList(folders(c))
        if (list.any { it.equals(clean, true) }) return false
        list.add(clean)
        sp(c).edit().putString(KEY_FOLDERS, JSONArray(list).toString()).apply()
        return true
    }

    fun removeFolder(c: Context, name: String) {
        if (name in DEFAULT_FOLDERS) return
        val list = folders(c).filter { it != name }
        sp(c).edit().putString(KEY_FOLDERS, JSONArray(list).toString()).apply()
        val books = bookmarks(c).map { if (it.folder == name) it.copy(folder = DEFAULT_FOLDER) else it }
        writeBookmarks(c, books)
    }

    fun bookmarks(c: Context): List<Bookmark> = readBookmarks(c).sortedByDescending { it.time }

    fun bookmarksIn(c: Context, folder: String): List<Bookmark> =
        bookmarks(c).filter { it.folder == folder }

    fun searchBookmarks(c: Context, query: String): List<Bookmark> {
        val q = query.trim().lowercase()
        val all = bookmarks(c)
        if (q.isEmpty()) return all
        return all.filter { it.url.lowercase().contains(q) || it.title.lowercase().contains(q) }
    }

    fun isBookmarked(c: Context, url: String): Boolean = readBookmarks(c).any { it.url == url }

    fun addBookmark(c: Context, url: String, title: String, folder: String = DEFAULT_FOLDER): Bookmark? {
        if (!BrowserUrl.isHttp(url)) return null
        if (isBookmarked(c, url)) return null
        val b = Bookmark(
            UUID.randomUUID().toString(),
            url,
            title.trim().ifBlank { BrowserUrl.display(url) },
            folder,
            System.currentTimeMillis()
        )
        val list = readBookmarks(c)
        list.add(b)
        writeBookmarks(c, list)
        return b
    }

    fun updateBookmark(c: Context, id: String, title: String, folder: String) {
        writeBookmarks(c, readBookmarks(c).map {
            if (it.id == id) it.copy(title = title.trim().ifBlank { it.title }, folder = folder) else it
        })
    }

    fun removeBookmark(c: Context, id: String) {
        writeBookmarks(c, readBookmarks(c).filter { it.id != id })
    }

    fun removeBookmarkUrl(c: Context, url: String) {
        writeBookmarks(c, readBookmarks(c).filter { it.url != url })
    }

    private fun readBookmarks(c: Context): MutableList<Bookmark> {
        val out = ArrayList<Bookmark>()
        val raw = sp(c).getString(KEY_BOOKMARKS, null) ?: return out
        try {
            val arr = JSONArray(raw)
            for (i in 0 until arr.length()) {
                val o = arr.optJSONObject(i) ?: continue
                val url = o.optString("url")
                if (url.isBlank()) continue
                out.add(Bookmark(
                    o.optString("id", UUID.randomUUID().toString()),
                    url,
                    o.optString("title"),
                    o.optString("folder", DEFAULT_FOLDER).ifBlank { DEFAULT_FOLDER },
                    o.optLong("time")
                ))
            }
        } catch (_: Exception) {
        }
        return out
    }

    private fun writeBookmarks(c: Context, list: List<Bookmark>) {
        val arr = JSONArray()
        list.forEach {
            arr.put(JSONObject().apply {
                put("id", it.id)
                put("url", it.url)
                put("title", it.title)
                put("folder", it.folder)
                put("time", it.time)
            })
        }
        sp(c).edit().putString(KEY_BOOKMARKS, arr.toString()).apply()
    }

    // ---------------- Normal tab session ----------------

    fun saveTabs(c: Context, tabs: List<SavedTab>) {
        val arr = JSONArray()
        tabs.filter { BrowserUrl.isHttp(it.url) }.take(20).forEach {
            arr.put(JSONObject().apply {
                put("url", it.url)
                put("title", it.title)
            })
        }
        sp(c).edit().putString(KEY_TABS, arr.toString()).apply()
    }

    fun savedTabs(c: Context): List<SavedTab> {
        val raw = sp(c).getString(KEY_TABS, null) ?: return emptyList()
        val out = ArrayList<SavedTab>()
        try {
            val arr = JSONArray(raw)
            for (i in 0 until arr.length()) {
                val o = arr.optJSONObject(i) ?: continue
                val url = o.optString("url")
                if (BrowserUrl.isHttp(url)) out.add(SavedTab(url, o.optString("title")))
            }
        } catch (_: Exception) {
        }
        return out
    }

    fun clearTabs(c: Context) {
        sp(c).edit().remove(KEY_TABS).apply()
    }

    val DEFAULT_FOLDER = "Favorites"
    val DEFAULT_FOLDERS = listOf(DEFAULT_FOLDER, "News", "Entertainment", "Study", "Shopping")
}
