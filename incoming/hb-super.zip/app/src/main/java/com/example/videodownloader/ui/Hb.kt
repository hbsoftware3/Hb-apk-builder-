package com.example.videodownloader.ui

import android.app.Activity
import android.content.Context
import android.content.res.ColorStateList
import android.content.res.Configuration
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.RippleDrawable
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.widget.SwitchCompat
import androidx.core.content.ContextCompat
import androidx.core.view.WindowInsetsControllerCompat
import com.example.videodownloader.R

data class Palette(
    val bg: Int,
    val surface: Int,
    val surfaceAlt: Int,
    val text: Int,
    val muted: Int,
    val blue: Int,
    val blueSoft: Int,
    val border: Int,
    val danger: Int,
    val success: Int,
    val warning: Int,
    val isDark: Boolean
)

object Hb {
    val HH: Int = 0xFF1E90FF.toInt()

    fun isNight(c: Context): Boolean =
        (c.resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) ==
            Configuration.UI_MODE_NIGHT_YES

    fun palette(c: Context): Palette = if (isNight(c)) Palette(
        bg = 0xFF05080D.toInt(),
        surface = 0xFF0C1320.toInt(),
        surfaceAlt = 0xFF121D2F.toInt(),
        text = 0xFFF5F8FF.toInt(),
        muted = 0xFF7A869A.toInt(),
        blue = 0xFF2E9BFF.toInt(),
        blueSoft = 0x332E9BFF,
        border = 0xFF1B2740.toInt(),
        danger = 0xFFFF5C6B.toInt(),
        success = 0xFF32D583.toInt(),
        warning = 0xFFFFB020.toInt(),
        isDark = true
    ) else Palette(
        bg = 0xFFF4F7FC.toInt(),
        surface = 0xFFFFFFFF.toInt(),
        surfaceAlt = 0xFFEDF2FA.toInt(),
        text = 0xFF0B1220.toInt(),
        muted = 0xFF5B6577.toInt(),
        blue = 0xFF1476FF.toInt(),
        blueSoft = 0x1F1476FF,
        border = 0xFFE1E8F3.toInt(),
        danger = 0xFFE5484D.toInt(),
        success = 0xFF12A150.toInt(),
        warning = 0xFFB26A00.toInt(),
        isDark = false
    )

    fun dp(c: Context, v: Number): Int = (v.toFloat() * c.resources.displayMetrics.density).toInt()

    fun round(
        c: Context,
        radiusDp: Number,
        color: Int,
        strokeColor: Int? = null,
        strokeDp: Number = 0
    ): GradientDrawable = GradientDrawable().apply {
        shape = GradientDrawable.RECTANGLE
        cornerRadius = dp(c, radiusDp).toFloat()
        setColor(color)
        if (strokeColor != null && strokeDp.toFloat() > 0f) setStroke(dp(c, strokeDp), strokeColor)
    }

    fun gradient(c: Context, radiusDp: Number, from: Int, to: Int): GradientDrawable =
        GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(from, to)).apply {
            cornerRadius = dp(c, radiusDp).toFloat()
        }

    fun ripple(c: Context, content: Drawable, color: Int = 0x33FFFFFF): Drawable =
        RippleDrawable(ColorStateList.valueOf(color), content, null)

    fun clickable(v: View, onTap: () -> Unit) {
        v.isClickable = true
        v.isFocusable = true
        v.setOnClickListener { onTap() }
    }

    fun pressScale(v: View) {
        v.setOnTouchListener { view, e ->
            when (e.action) {
                android.view.MotionEvent.ACTION_DOWN ->
                    view.animate().scaleX(0.97f).scaleY(0.97f).setDuration(70).start()
                android.view.MotionEvent.ACTION_UP,
                android.view.MotionEvent.ACTION_CANCEL ->
                    view.animate().scaleX(1f).scaleY(1f).setDuration(130).start()
            }
            false
        }
    }

    fun text(
        c: Context,
        value: CharSequence,
        size: Float = 14f,
        color: Int = palette(c).text,
        bold: Boolean = false,
        medium: Boolean = false
    ): TextView = TextView(c).apply {
        text = value
        textSize = size
        setTextColor(color)
        if (bold) typeface = Typeface.create("sans-serif", Typeface.BOLD)
        else if (medium) typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        includeFontPadding = false
    }

    fun icon(c: Context, res: Int, tint: Int, sizeDp: Number = 22): ImageView = ImageView(c).apply {
        setImageResource(res)
        imageTintList = ColorStateList.valueOf(tint)
        scaleType = ImageView.ScaleType.CENTER_INSIDE
        layoutParams = LinearLayout.LayoutParams(dp(c, sizeDp), dp(c, sizeDp))
    }

    fun iconCircle(c: Context, res: Int, tint: Int, bg: Int, sizeDp: Number = 42): FrameLayout =
        FrameLayout(c).apply {
            background = round(c, sizeDp.toFloat() / 2f, bg)
            layoutParams = LinearLayout.LayoutParams(dp(c, sizeDp), dp(c, sizeDp))
            addView(icon(c, res, tint, sizeDp.toFloat() * 0.52f), FrameLayout.LayoutParams(
                dp(c, sizeDp.toFloat() * 0.52f), dp(c, sizeDp.toFloat() * 0.52f), Gravity.CENTER
            ))
        }

    /** Solid or outline pill button with optional icon. */
    fun button(
        c: Context,
        label: String,
        primary: Boolean = true,
        iconRes: Int = 0,
        heightDp: Number = 50,
        onClick: () -> Unit
    ): LinearLayout {
        val p = palette(c)
        val bg = if (primary) {
            ripple(c, gradient(c, 16, p.blue, if (p.isDark) 0xFF0668E8.toInt() else 0xFF0A5FE0.toInt()))
        } else {
            ripple(c, round(c, 16, p.surfaceAlt, p.border, 1))
        }
        return LinearLayout(c).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            background = bg
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(c, heightDp)
            )
            if (iconRes != 0) addView(icon(c, iconRes, if (primary) Color.WHITE else p.text, 20).apply {
                (layoutParams as LinearLayout.LayoutParams).marginEnd = dp(c, 8)
            })
            addView(text(c, label, 14.5f, if (primary) Color.WHITE else p.text, medium = true))
            clickable(this, onClick)
            pressScale(this)
        }
    }

    fun iconButton(c: Context, res: Int, tint: Int? = null, sizeDp: Number = 42, onClick: () -> Unit): FrameLayout {
        val p = palette(c)
        return FrameLayout(c).apply {
            background = ripple(c, round(c, 14, p.surfaceAlt, p.border, 1))
            layoutParams = LinearLayout.LayoutParams(dp(c, sizeDp), dp(c, sizeDp))
            addView(icon(c, res, tint ?: p.text, 20), FrameLayout.LayoutParams(dp(c, 20), dp(c, 20), Gravity.CENTER))
            clickable(this, onClick)
        }
    }

    fun card(c: Context, padDp: Number = 16, radiusDp: Number = 20, color: Int? = null): LinearLayout {
        val p = palette(c)
        return LinearLayout(c).apply {
            orientation = LinearLayout.VERTICAL
            background = round(c, radiusDp, color ?: p.surface, if (p.isDark) p.border else p.border, 1)
            setPadding(dp(c, padDp), dp(c, padDp), dp(c, padDp), dp(c, padDp))
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
            )
        }
    }

    fun section(c: Context, title: String, action: String? = null, onAction: (() -> Unit)? = null): LinearLayout =
        LinearLayout(c).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = dp(c, 22); bottomMargin = dp(c, 10) }
            addView(text(c, title, 16f, palette(c).text, bold = true), LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            if (action != null) addView(text(c, action, 12.5f, palette(c).blue, medium = true).apply {
                setPadding(dp(c, 6), dp(c, 6), 0, dp(c, 6))
                if (onAction != null) clickable(this, onAction)
            })
        }

    fun row(
        c: Context,
        iconRes: Int,
        title: String,
        sub: String? = null,
        trailing: String? = null,
        iconTint: Int? = null,
        onClick: (() -> Unit)? = null
    ): LinearLayout {
        val p = palette(c)
        return LinearLayout(c).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(c, 6), dp(c, 11), dp(c, 6), dp(c, 11))
            addView(iconCircle(c, iconRes, iconTint ?: p.blue, p.blueSoft, 42))
            addView(LinearLayout(c).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(c, 12), 0, dp(c, 8), 0)
                addView(text(c, title, 14.5f, p.text, medium = true))
                if (!sub.isNullOrBlank()) addView(text(c, sub, 11.5f, p.muted).apply {
                    maxLines = 1
                    setPadding(0, dp(c, 3), 0, 0)
                })
            }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            if (!trailing.isNullOrBlank()) addView(text(c, trailing, 12f, p.muted))
            addView(icon(c, R.drawable.ic_chevron_right, p.muted, 18).apply {
                (layoutParams as LinearLayout.LayoutParams).marginStart = dp(c, 4)
            })
            if (onClick != null) {
                background = ripple(c, ColorDrawableTransparent(), 0x22FFFFFF)
                clickable(this, onClick)
            }
        }
    }

    fun divider(c: Context, insetDp: Number = 0): View = View(c).apply {
        setBackgroundColor(palette(c).border)
        layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(c, 1)).apply {
            topMargin = dp(c, 6); bottomMargin = dp(c, 6)
            marginStart = dp(c, insetDp); marginEnd = dp(c, insetDp)
        }
    }

    fun chip(c: Context, label: String, selected: Boolean): TextView {
        val p = palette(c)
        return text(c, label, 12.5f, if (selected) Color.WHITE else p.muted, medium = true).apply {
            gravity = Gravity.CENTER
            setPadding(dp(c, 14), dp(c, 9), dp(c, 14), dp(c, 9))
            background = if (selected) round(c, 40, p.blue) else round(c, 40, p.surfaceAlt, p.border, 1)
        }
    }

    fun stat(c: Context, label: String, value: String, tint: Int? = null): LinearLayout {
        val p = palette(c)
        return LinearLayout(c).apply {
            orientation = LinearLayout.VERTICAL
            background = round(c, 16, p.surfaceAlt, p.border, 1)
            setPadding(dp(c, 12), dp(c, 11), dp(c, 12), dp(c, 11))
            addView(text(c, value, 16f, tint ?: p.text, bold = true))
            addView(text(c, label, 10.5f, p.muted).apply { setPadding(0, dp(c, 3), 0, 0) })
        }
    }

    fun toggleRow(
        c: Context,
        title: String,
        sub: String? = null,
        checked: Boolean,
        onChange: (Boolean) -> Unit
    ): LinearLayout {
        val p = palette(c)
        return LinearLayout(c).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(c, 4), dp(c, 10), dp(c, 4), dp(c, 10))
            addView(LinearLayout(c).apply {
                orientation = LinearLayout.VERTICAL
                addView(text(c, title, 14f, p.text, medium = true))
                if (!sub.isNullOrBlank()) addView(text(c, sub, 11.5f, p.muted).apply { setPadding(0, dp(c, 3), 0, 0) })
            }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            addView(SwitchCompat(c).apply {
                isChecked = checked
                buttonTintList = ColorStateList.valueOf(p.blue)
                setOnCheckedChangeListener { _, v -> onChange(v) }
            })
        }
    }

    fun progress(c: Context): ProgressBar = ProgressBar(
        c, null, android.R.attr.progressBarStyleHorizontal
    ).apply {
        max = 100
        progressTintList = ColorStateList.valueOf(palette(c).blue)
        progressBackgroundTintList = ColorStateList.valueOf(palette(c).surfaceAlt)
        layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(c, 6))
    }

    fun scroll(c: Context, content: View): ScrollView = ScrollView(c).apply {
        isFillViewport = true
        overScrollMode = View.OVER_SCROLL_NEVER
        setBackgroundColor(palette(c).bg)
        addView(content)
    }

    fun column(c: Context, padDp: Number = 18): LinearLayout =
        LinearLayout(c).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(c, padDp), dp(c, 8), dp(c, padDp), dp(c, 28))
        }

    fun spacer(c: Context, heightDp: Number): View = View(c).apply {
        layoutParams = LinearLayout.LayoutParams(1, dp(c, heightDp))
    }

    fun empty(c: Context, iconRes: Int, title: String, sub: String): LinearLayout {
        val p = palette(c)
        return LinearLayout(c).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(c, 16), dp(c, 28), dp(c, 16), dp(c, 28))
            addView(iconCircle(c, iconRes, p.blue, p.blueSoft, 58))
            addView(text(c, title, 14.5f, p.text, medium = true).apply {
                gravity = Gravity.CENTER
                setPadding(0, dp(c, 10), 0, 0)
            })
            addView(text(c, sub, 12f, p.muted).apply {
                gravity = Gravity.CENTER
                setPadding(0, dp(c, 4), 0, 0)
            })
        }
    }

    fun topBar(
        c: Context,
        title: String,
        sub: String? = null,
        onBack: (() -> Unit)? = null,
        actions: List<Pair<Int, () -> Unit>> = emptyList()
    ): LinearLayout {
        val p = palette(c)
        return LinearLayout(c).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(c, 12), dp(c, 10), dp(c, 12), dp(c, 10))
            setBackgroundColor(p.bg)
            if (onBack != null) addView(iconButton(c, R.drawable.ic_back, p.text, 40, onBack).apply {
                (layoutParams as LinearLayout.LayoutParams).marginEnd = dp(c, 8)
            })
            addView(LinearLayout(c).apply {
                orientation = LinearLayout.VERTICAL
                addView(text(c, title, 18f, p.text, bold = true))
                if (!sub.isNullOrBlank()) addView(text(c, sub, 11.5f, p.muted))
            }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            actions.forEach { (res, onTap) ->
                addView(iconButton(c, res, p.text, 40, onTap).apply {
                    (layoutParams as LinearLayout.LayoutParams).marginStart = dp(c, 6)
                })
            }
        }
    }

    fun applySystemBars(a: Activity) {
        val p = palette(a)
        a.window.statusBarColor = p.bg
        a.window.navigationBarColor = p.bg
        WindowInsetsControllerCompat(a.window, a.window.decorView).apply {
            isAppearanceLightStatusBars = !p.isDark
            isAppearanceLightNavigationBars = !p.isDark
        }
    }

    fun toast(c: Context, msg: String) {
        Toast.makeText(c, msg, Toast.LENGTH_LONG).show()
    }

    fun confirm(
        c: Context,
        title: String,
        message: String,
        positive: String = "Confirm",
        negative: String = "Cancel",
        destructive: Boolean = false,
        onYes: () -> Unit
    ) {
        val p = palette(c)
        AlertDialog.Builder(c, R.style.HbDialog)
            .setTitle(title)
            .setMessage(message)
            .setPositiveButton(positive) { _, _ -> onYes() }
            .setNegativeButton(negative, null)
            .show()
            .also { d ->
                d.getButton(AlertDialog.BUTTON_POSITIVE)?.setTextColor(if (destructive) p.danger else p.blue)
                d.getButton(AlertDialog.BUTTON_NEGATIVE)?.setTextColor(p.muted)
            }
    }

    fun alert(c: Context, title: String, message: String, action: String = "OK") {
        val p = palette(c)
        AlertDialog.Builder(c, R.style.HbDialog)
            .setTitle(title)
            .setMessage(message)
            .setPositiveButton(action, null)
            .show()
            .also { it.getButton(AlertDialog.BUTTON_POSITIVE)?.setTextColor(p.blue) }
    }

    fun input(
        c: Context,
        title: String,
        hint: String,
        value: String = "",
        multiline: Boolean = false,
        password: Boolean = false,
        onOk: (String) -> Unit
    ) {
        val p = palette(c)
        val input = EditText(c).apply {
            setText(value)
            this.hint = hint
            setTextColor(p.text)
            setHintTextColor(p.muted)
            background = round(c, 14, p.surfaceAlt, p.border, 1)
            setPadding(dp(c, 14), dp(c, 12), dp(c, 14), dp(c, 12))
            inputType = if (password) InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
            else if (multiline) InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE
            else InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI
            if (multiline) { minLines = 4; gravity = Gravity.TOP }
            imeOptions = if (multiline) EditorInfo.IME_ACTION_NONE else EditorInfo.IME_ACTION_DONE
        }
        val wrap = FrameLayout(c).apply {
            setPadding(dp(c, 20), dp(c, 8), dp(c, 20), 0)
            addView(input)
        }
        val dialog = AlertDialog.Builder(c, R.style.HbDialog)
            .setTitle(title)
            .setView(wrap)
            .setPositiveButton("OK") { _, _ -> onOk(input.text.toString()) }
            .setNegativeButton("Cancel", null)
            .create()
        dialog.setOnShowListener { dialog.getButton(AlertDialog.BUTTON_POSITIVE)?.setTextColor(p.blue) }
        dialog.show()
    }

    fun listContainer(c: Context): LinearLayout = LinearLayout(c).apply {
        orientation = LinearLayout.VERTICAL
        layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
    }

    /** Transparent drawable so a ripple can be applied over an arbitrary row. */
    private class ColorDrawableTransparent : Drawable() {
        override fun draw(canvas: android.graphics.Canvas) {}
        override fun setAlpha(alpha: Int) {}
        override fun setColorFilter(colorFilter: android.graphics.ColorFilter?) {}
        @Deprecated("Deprecated in Java")
        override fun getOpacity(): Int = android.graphics.PixelFormat.TRANSPARENT
    }
}
