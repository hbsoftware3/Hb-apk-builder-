package com.example.videodownloader

import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import androidx.core.view.isVisible
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import com.example.videodownloader.browser.BrowserScreen
import com.example.videodownloader.browser.BrowserUrl
import com.example.videodownloader.screens.DownloadsScreen
import com.example.videodownloader.screens.HomeScreen
import com.example.videodownloader.screens.LibraryScreen
import com.example.videodownloader.screens.ToolsScreen
import com.example.videodownloader.settings.SettingsActivity
import com.example.videodownloader.ui.BaseActivity
import com.example.videodownloader.ui.Hb
import com.example.videodownloader.ui.Screen
import com.example.videodownloader.util.Launcher
import com.example.videodownloader.util.Tool
import kotlinx.coroutines.launch

class MainActivity : BaseActivity() {

    companion object {
        const val EXTRA_TAB = "tab"
        const val EXTRA_OPEN_URL = "open_url"
        const val TAB_HOME = 0
        const val TAB_DOWNLOADS = 1
        const val TAB_BROWSER = 2
        const val TAB_TOOLS = 3
        const val TAB_LIBRARY = 4
    }

    private lateinit var host: FrameLayout
    private lateinit var navRoot: LinearLayout
    private val screens = arrayOfNulls<Screen>(5)
    private var current = -1
    private val navIcons = ArrayList<ImageView>()
    private val navTitles = ArrayList<TextView>()
    private val navPills = ArrayList<FrameLayout>()
    private var navBadge: View? = null

    private var folderCallback: ((Uri) -> Unit)? = null
    private var fileCallback: ((List<Uri>) -> Unit)? = null

    private val folderPicker =
        registerForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
            val cb = folderCallback
            folderCallback = null
            if (uri != null) {
                try {
                    contentResolver.takePersistableUriPermission(
                        uri,
                        Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
                    )
                } catch (_: Exception) {
                    Hb.toast(this, "Android did not allow this folder. Pick another one.")
                    return@registerForActivityResult
                }
                cb?.invoke(uri)
            }
        }

    private val multiFilePicker =
        registerForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
            val cb = fileCallback
            fileCallback = null
            if (cb != null && uris.isNotEmpty()) cb(uris)
        }

    private val singleFilePicker =
        registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
            val cb = fileCallback
            fileCallback = null
            if (cb != null && uri != null) cb(listOf(uri))
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Hb.applySystemBars(this)

        val p = Hb.palette(this)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(p.bg)
        }
        host = FrameLayout(this)
        root.addView(host, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        navRoot = buildNav()
        root.addView(navRoot)
        setContentView(root)

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                val s = if (current in 0..4) screens[current] else null
                if (s?.onBack() == true) return
                if (current != TAB_HOME) {
                    selectTab(TAB_HOME)
                    return
                }
                isEnabled = false
                onBackPressedDispatcher.onBackPressed()
                isEnabled = true
            }
        })

        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                launch {
                    DownloadTracker.items.collect { items ->
                        updateBadge(items.isNotEmpty())
                        (screens[TAB_HOME] as? HomeScreen)?.onDownloadsChanged(items)
                        (screens[TAB_DOWNLOADS] as? DownloadsScreen)?.renderActive(items)
                    }
                }
                launch {
                    DownloadTracker.messages.collect { Hb.toast(this@MainActivity, it) }
                }
                launch {
                    UpdateTracker.ui.collect {
                        (screens[TAB_HOME] as? HomeScreen)?.refreshUpdateLabel()
                    }
                }
            }
        }

        var tab = intent?.getIntExtra(EXTRA_TAB, -1) ?: -1
        if (intent?.getStringExtra(EXTRA_TAB) == "downloader") tab = TAB_DOWNLOADS
        selectTab(if (tab in 0..4) tab else TAB_HOME)

        intent?.getStringExtra(EXTRA_OPEN_URL)?.takeIf { it.isNotBlank() }?.let { url ->
            openInBrowser(url)
        }

        if (savedInstanceState == null) {
            Updater.check(this, false) { msg -> (screens[TAB_HOME] as? HomeScreen)?.showNotice(msg) }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        var tab = intent.getIntExtra(EXTRA_TAB, -1)
        if (intent.getStringExtra(EXTRA_TAB) == "downloader") tab = TAB_DOWNLOADS
        if (tab in 0..4) selectTab(tab)
        intent.getStringExtra(EXTRA_OPEN_URL)?.takeIf { it.isNotBlank() }?.let { openInBrowser(it) }
    }

    override fun onResume() {
        super.onResume()
        if (current in 0..4) screens[current]?.onHostResume()
        (screens[TAB_HOME] as? HomeScreen)?.refresh()
        if (Updater.mustUpdate(this)) Updater.check(this, false) { }
    }

    /** Android only lets an app read the clipboard while it is in front, so this runs when the window gets focus. */
    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) offerCopiedLink()
    }

    /** New feature: a supported video link was copied -> ask once whether to download it. */
    private fun offerCopiedLink() {
        if (!Prefs.clipboardOffer(this) || Updater.mustUpdate(this)) return
        try {
            val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            val text = cm.primaryClip?.takeIf { it.itemCount > 0 }?.getItemAt(0)?.coerceToText(this)?.toString().orEmpty()
            val link = Regex("https?://\\S+").find(text)?.value?.let { UrlTools.clean(it) } ?: return
            val site = Site.detect(link)
            if (site == Site.OTHER) return
            if (link == Prefs.lastClipLink(this)) return
            Prefs.setLastClipLink(this, link)
            val audio = Prefs.audioDefault(this)
            if (DownloadTracker.isActive(link, audio)) return
            val short = if (link.length > 70) link.take(67) + "..." else link
            Hb.confirm(
                this, "Download copied link?",
                "${site.label} link found in your clipboard:\n$short",
                positive = if (audio) "Download MP3" else "Download", negative = "Not now"
            ) {
                ContextCompat.startForegroundService(
                    this,
                    Intent(this, DownloadService::class.java)
                        .putExtra(DownloadService.EXTRA_URL, link)
                        .putExtra(DownloadService.EXTRA_AUDIO, audio)
                )
                Hb.toast(this, "Download started")
            }
        } catch (_: Exception) {
        }
    }

    override fun onPause() {
        super.onPause()
        if (current in 0..4) screens[current]?.onHostPause()
    }

    /** The browser hides the main navigation while a video is in full screen. */
    fun setBottomNavVisible(visible: Boolean) {
        navRoot.visibility = if (visible) View.VISIBLE else View.GONE
    }

    private fun buildNav(): LinearLayout {
        val p = Hb.palette(this)
        val wrapper = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(p.surface)
        }
        wrapper.addView(View(this).apply { setBackgroundColor(p.border) },
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, Hb.dp(this, 1)))

        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setPadding(Hb.dp(this@MainActivity, 6), Hb.dp(this@MainActivity, 6),
                Hb.dp(this@MainActivity, 6), Hb.dp(this@MainActivity, 6))
        }

        val items = listOf(
            Triple(R.drawable.ic_home, "Home", TAB_HOME),
            Triple(R.drawable.ic_download, "Downloads", TAB_DOWNLOADS),
            Triple(R.drawable.ic_browser, "Browser", TAB_BROWSER),
            Triple(R.drawable.ic_tools, "Tools", TAB_TOOLS),
            Triple(R.drawable.ic_library, "Library", TAB_LIBRARY)
        )

        items.forEach { (icon, label, index) ->
            val pill = FrameLayout(this).apply {
                background = Hb.round(this@MainActivity, 12, 0x00000000)
                layoutParams = LinearLayout.LayoutParams(Hb.dp(this@MainActivity, 46), Hb.dp(this@MainActivity, 30))
            }
            val img = Hb.icon(this, icon, p.muted, 21)
            pill.addView(img, FrameLayout.LayoutParams(Hb.dp(this, 21), Hb.dp(this, 21), Gravity.CENTER))
            val title = Hb.text(this, label, 10f, p.muted, medium = true).apply {
                gravity = Gravity.CENTER
                setPadding(0, Hb.dp(this@MainActivity, 4), 0, 0)
                maxLines = 1
            }
            val item = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER
                addView(pill)
                addView(title)
            }
            Hb.clickable(item) { selectTab(index) }
            Hb.pressScale(item)
            bar.addView(item, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            navIcons.add(img)
            navTitles.add(title)
            navPills.add(pill)
        }

        // Badge dot for running downloads
        navBadge = View(this).apply {
            background = Hb.round(this@MainActivity, 5, p.blue, p.surface, 2)
            isVisible = false
            layoutParams = FrameLayout.LayoutParams(Hb.dp(this@MainActivity, 9), Hb.dp(this@MainActivity, 9),
                Gravity.TOP or Gravity.END).apply { topMargin = Hb.dp(this@MainActivity, 1); marginEnd = Hb.dp(this@MainActivity, 9) }
        }
        (navPills[TAB_DOWNLOADS]).addView(navBadge)

        wrapper.addView(bar, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        return wrapper
    }

    private fun updateBadge(show: Boolean) {
        navBadge?.isVisible = show
    }

    private fun updateNav() {
        val p = Hb.palette(this)
        for (i in navIcons.indices) {
            val selected = i == current
            navIcons[i].imageTintList = android.content.res.ColorStateList.valueOf(if (selected) p.blue else p.muted)
            navTitles[i].setTextColor(if (selected) p.blue else p.muted)
            navPills[i].background = Hb.round(this, 12, if (selected) p.blueSoft else 0x00000000)
            navPills[i].animate().scaleX(if (selected) 1f else 0.94f)
                .scaleY(if (selected) 1f else 0.94f).setDuration(160).start()
        }
    }

    fun selectTab(index: Int) {
        if (index !in 0..4) return
        if (current == index) {
            screens[index]?.refresh()
            return
        }
        if (current in 0..4) screens[current]?.onHide()
        val screen = screens[index] ?: createScreen(index).also { screens[index] = it }
        host.removeAllViews()
        host.addView(screen.root, FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT
        ))
        screen.root.alpha = 0f
        screen.root.translationY = Hb.dp(this, 12).toFloat()
        screen.root.animate().alpha(1f).translationY(0f).setDuration(190).start()
        current = index
        updateNav()
        screen.onShow()
        screen.refresh()
    }

    private fun createScreen(index: Int): Screen = when (index) {
        TAB_HOME -> HomeScreen(
            this,
            onOpenSettings = { openSettings() },
            onOpenBrowser = { selectTab(TAB_BROWSER) },
            onSearch = { showGlobalSearch() },
            onTool = { Launcher.openTool(this, it) },
            onTab = { selectTab(it) }
        )
        TAB_DOWNLOADS -> DownloadsScreen(this)
        TAB_BROWSER -> BrowserScreen(this)
        TAB_TOOLS -> ToolsScreen(this, ::launchTool)
        else -> LibraryScreen(this)
    }

    fun launchTool(tool: Tool) {
        if (tool == Tool.BROWSER) selectTab(TAB_BROWSER) else Launcher.openTool(this, tool)
    }

    fun openSettings() {
        startActivity(Intent(this, SettingsActivity::class.java))
    }

    fun openInBrowser(url: String) {
        selectTab(TAB_BROWSER)
        (screens[TAB_BROWSER] as? BrowserScreen)?.openUrl(url)
    }

    fun showGlobalSearch() {
        Hb.input(
            this, "Search",
            "Search the web, files and tools"
        ) { q ->
            if (q.isBlank()) return@input
            val tool = Tool.entries.firstOrNull { it.title.equals(q.trim(), true) || it.id == q.trim() }
            if (tool != null) {
                launchTool(tool)
            } else {
                openInBrowser(BrowserUrl.normalize(q))
            }
        }
    }

    /** Folder picker used by downloads, browser and settings. */
    fun pickFolder(onPicked: (Uri) -> Unit) {
        folderCallback = onPicked
        try {
            folderPicker.launch(null)
        } catch (_: Exception) {
            folderCallback = null
            Hb.toast(this, "The folder picker is not available on this phone")
        }
    }

    /** File chooser used by the browser (uploads) and tools. */
    fun chooseFiles(mimeTypes: Array<String>?, multiple: Boolean, onPicked: (List<Uri>) -> Unit) {
        fileCallback = onPicked
        val types = mimeTypes?.filter { it.contains("/") }?.toTypedArray()
        val arr = if (types.isNullOrEmpty()) arrayOf("*/*") else types
        try {
            if (multiple) multiFilePicker.launch(arr) else singleFilePicker.launch(arr)
        } catch (_: Exception) {
            fileCallback = null
            Hb.toast(this, "The file picker is not available")
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        (screens[TAB_BROWSER] as? BrowserScreen)?.dispose()
    }
}
