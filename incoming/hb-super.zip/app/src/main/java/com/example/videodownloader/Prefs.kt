package com.example.videodownloader

import android.content.Context

object Prefs {
    private fun sp(c: Context) = c.getSharedPreferences("hb_aio", Context.MODE_PRIVATE)

    /** Lowest app version that may still be used (from update-v1.json minVersionCode). 0 = no forced update. */
    fun minVersion(c: Context): Int = sp(c).getInt("min_version", 0)

    fun setMinVersion(c: Context, v: Int) {
        sp(c).edit().putInt("min_version", v).apply()
    }

    /** When yt-dlp was last updated automatically (milliseconds). 0 = never. */
    fun lastYtdlpUpdate(c: Context): Long = sp(c).getLong("ytdlp_last_update", 0L)

    fun setLastYtdlpUpdate(c: Context, t: Long) {
        sp(c).edit().putLong("ytdlp_last_update", t).apply()
    }

    /** Max video height. 0 = best available. Default 720. */
    fun quality(c: Context): Int = sp(c).getInt("quality", 720)

    fun setQuality(c: Context, h: Int) {
        sp(c).edit().putInt("quality", h).apply()
    }

    /** Folder access (a content:// tree address) the user granted for WhatsApp / WhatsApp Business statuses. */
    fun statusTree(c: Context, key: String): String? = sp(c).getString("status_tree_$key", null)

    fun setStatusTree(c: Context, key: String, uri: String?) {
        sp(c).edit().apply { if (uri == null) remove("status_tree_$key") else putString("status_tree_$key", uri) }.apply()
    }

    /** Names of statuses that were already saved, so the button can show "Saved". */
    fun isStatusSaved(c: Context, name: String): Boolean =
        sp(c).getStringSet("status_saved", emptySet())?.contains(name) == true

    @Synchronized
    fun unmarkStatusSaved(c: Context, name: String) {
        val set = HashSet(sp(c).getStringSet("status_saved", emptySet()) ?: emptySet())
        set.remove(name)
        sp(c).edit().putStringSet("status_saved", set).apply()
    }

    @Synchronized
    fun markStatusSaved(c: Context, name: String) {
        val set = HashSet(sp(c).getStringSet("status_saved", emptySet()) ?: emptySet())
        set.add(name)
        sp(c).edit().putStringSet("status_saved", set).apply()
    }

    private fun putOrRemove(c: Context, key: String, v: String?) {
        sp(c).edit().apply { if (v == null) remove(key) else putString(key, v) }.apply()
    }

    /** Folder the user picked for videos and photos (a content:// tree address). null = default DCIM/HB AIO. */
    fun videoTree(c: Context): String? = sp(c).getString("video_tree", null)
    fun setVideoTree(c: Context, v: String?) = putOrRemove(c, "video_tree", v)

    /** Folder the user picked for MP3 / audio. null = default Music/HB AIO. */
    fun audioTree(c: Context): String? = sp(c).getString("audio_tree", null)
    fun setAudioTree(c: Context, v: String?) = putOrRemove(c, "audio_tree", v)

    /** true (default) = YouTube videos go into their own "YouTube" folder inside the video folder. */
    fun youtubeFolder(c: Context): Boolean = sp(c).getBoolean("yt_folder", true)
    fun setYoutubeFolder(c: Context, v: Boolean) {
        sp(c).edit().putBoolean("yt_folder", v).apply()
    }

    /** true = downloads wait until the phone is on Wi-Fi (saves mobile data). Default: off. */
    fun wifiOnly(c: Context): Boolean = sp(c).getBoolean("wifi_only", false)

    fun setWifiOnly(c: Context, v: Boolean) {
        sp(c).edit().putBoolean("wifi_only", v).apply()
    }

    /** true = the Download button and Share both save audio (MP3). Default: video. */
    fun audioDefault(c: Context): Boolean = sp(c).getBoolean("audio_default", false)

    fun setAudioDefault(c: Context, v: Boolean) {
        sp(c).edit().putBoolean("audio_default", v).apply()
    }

    // ---------- HB Super App 1.0 ----------

    /** "system", "light" or "dark". The premium default is dark. */
    fun theme(c: Context): String = sp(c).getString("ui_theme", "dark") ?: "dark"
    fun setTheme(c: Context, v: String) { sp(c).edit().putString("ui_theme", v).apply() }

    /** Quick actions chosen for the Home dashboard. */
    fun homeActions(c: Context): Set<String> =
        sp(c).getStringSet("home_actions", DEFAULT_HOME_ACTIONS) ?: DEFAULT_HOME_ACTIONS
    fun setHomeActions(c: Context, v: Set<String>) { sp(c).edit().putStringSet("home_actions", v).apply() }

    fun favoriteTools(c: Context): Set<String> =
        sp(c).getStringSet("favorite_tools", setOf("browser", "converter")) ?: setOf("browser", "converter")
    fun setFavoriteTools(c: Context, v: Set<String>) { sp(c).edit().putStringSet("favorite_tools", v).apply() }

    fun searchEngine(c: Context): String = sp(c).getString("search_engine", "google") ?: "google"
    fun setSearchEngine(c: Context, v: String) { sp(c).edit().putString("search_engine", v).apply() }

    fun adBlock(c: Context): Boolean = sp(c).getBoolean("browser_adblock", true)
    fun setAdBlock(c: Context, v: Boolean) { sp(c).edit().putBoolean("browser_adblock", v).apply() }

    fun restoreTabs(c: Context): Boolean = sp(c).getBoolean("browser_restore_tabs", true)
    fun setRestoreTabs(c: Context, v: Boolean) { sp(c).edit().putBoolean("browser_restore_tabs", v).apply() }

    fun clearPrivateOnExit(c: Context): Boolean = sp(c).getBoolean("browser_private_clear", true)
    fun setClearPrivateOnExit(c: Context, v: Boolean) { sp(c).edit().putBoolean("browser_private_clear", v).apply() }

    /** Send the website's login cookies with downloads started inside HB Browser. */
    fun browserLoginDownloads(c: Context): Boolean = sp(c).getBoolean("browser_login_downloads", true)
    fun setBrowserLoginDownloads(c: Context, v: Boolean) { sp(c).edit().putBoolean("browser_login_downloads", v).apply() }

    fun browserHome(c: Context): String = sp(c).getString("browser_home", "https://www.google.com") ?: "https://www.google.com"
    fun setBrowserHome(c: Context, v: String) { sp(c).edit().putString("browser_home", v).apply() }

    /** Optional SAF folder where browser downloads are copied after DownloadManager finishes. */
    fun browserDownloadTree(c: Context): String? = sp(c).getString("browser_download_tree", null)
    fun setBrowserDownloadTree(c: Context, v: String?) = putOrRemove(c, "browser_download_tree", v)

    fun browserTextZoom(c: Context): Int = sp(c).getInt("browser_text_zoom", 100)
    fun setBrowserTextZoom(c: Context, v: Int) { sp(c).edit().putInt("browser_text_zoom", v).apply() }

    /** Marker left behind if the app died while a private tab was open, so its data is cleared next launch. */
    fun privateSessionOpen(c: Context): Boolean = sp(c).getBoolean("private_session_open", false)
    fun setPrivateSessionOpen(c: Context, v: Boolean) { sp(c).edit().putBoolean("private_session_open", v).apply() }

    fun readerFont(c: Context): Int = sp(c).getInt("reader_font", 100)
    fun setReaderFont(c: Context, v: Int) { sp(c).edit().putInt("reader_font", v).apply() }

    fun playerResume(c: Context): Boolean = sp(c).getBoolean("player_resume", true)
    fun setPlayerResume(c: Context, v: Boolean) { sp(c).edit().putBoolean("player_resume", v).apply() }

    fun playerBackground(c: Context): Boolean = sp(c).getBoolean("player_background", true)
    fun setPlayerBackground(c: Context, v: Boolean) { sp(c).edit().putBoolean("player_background", v).apply() }

    fun playerAspect(c: Context): Int = sp(c).getInt("player_aspect", 0)
    fun setPlayerAspect(c: Context, v: Int) { sp(c).edit().putInt("player_aspect", v).apply() }

    fun playerSpeed(c: Context): Float = sp(c).getFloat("player_speed", 1f)
    fun setPlayerSpeed(c: Context, v: Float) { sp(c).edit().putFloat("player_speed", v).apply() }

    val DEFAULT_HOME_ACTIONS = setOf("player", "files", "converter", "qr", "status", "browser")

    /** true = downloads that start outside the browser use the login made in HB Browser (Instagram). Default: on. */
    fun autoSiteLogin(c: Context): Boolean = sp(c).getBoolean("auto_site_login", true)
    fun setAutoSiteLogin(c: Context, v: Boolean) { sp(c).edit().putBoolean("auto_site_login", v).apply() }

    /** true = when a supported video link is copied, offer to download it when the app opens. Default: on. */
    fun clipboardOffer(c: Context): Boolean = sp(c).getBoolean("clipboard_offer", true)
    fun setClipboardOffer(c: Context, v: Boolean) { sp(c).edit().putBoolean("clipboard_offer", v).apply() }

    /** The last copied link we already asked about (so we never ask twice for the same one). */
    fun lastClipLink(c: Context): String = sp(c).getString("last_clip_link", "") ?: ""
    fun setLastClipLink(c: Context, v: String) { sp(c).edit().putString("last_clip_link", v).apply() }
}

object Quality {
    val heights = listOf(360, 480, 720, 1080, 1440, 2160)
    val labels = listOf("360p", "480p", "720p (default)", "1080p", "1440p", "4K")

    fun label(h: Int) = when (h) {
        0 -> "Best"
        2160 -> "4K"
        else -> "${h}p"
    }

    /** Old saved "Best" (0) now means 1080p. Unknown values fall back to 720p. */
    fun indexOf(h: Int): Int {
        if (h == 0) return heights.indexOf(1080)
        return heights.indexOf(h).let { if (it < 0) 2 else it }
    }

    /**
     * Up to 1080p: prefer H.264 (plays smoothly on every phone, shows in the gallery).
     * Above 1080p (1440p / 4K) no H.264 exists on YouTube, so VP9/AV1 is allowed.
     */
    fun format(h: Int): String =
        if (h > 1080) "bv*+ba/b"
        else "bv*[vcodec^=avc]+ba/b[vcodec^=avc]/bv*+ba/b"

    /**
     * yt-dlp sort order.
     * Up to 1080p: codec FIRST (H.264 over VP9/AV1/HEVC), then the best resolution up to h, then AAC.
     * Above 1080p: resolution first, VP9 preferred over AV1 (more phones can decode it), Opus audio
     * so the two parts fit one file (webm).
     */
    fun sort(h: Int): String =
        if (h > 1080) "res:$h,vcodec:vp9,acodec:opus,ext"
        else "vcodec:h264,res:$h,acodec:aac,ext"
}
