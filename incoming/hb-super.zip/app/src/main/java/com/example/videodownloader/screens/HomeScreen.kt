package com.example.videodownloader.screens

import android.content.Intent
import android.os.Environment
import android.os.StatFs
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.core.view.isVisible
import androidx.lifecycle.lifecycleScope
import com.example.videodownloader.ActiveDownload
import com.example.videodownloader.DownloadControl
import com.example.videodownloader.DownloadTracker
import com.example.videodownloader.HistoryActivity
import com.example.videodownloader.HistoryStore
import com.example.videodownloader.MainActivity
import com.example.videodownloader.Prefs
import com.example.videodownloader.R
import com.example.videodownloader.Updater
import com.example.videodownloader.player.PlayerActivity
import com.example.videodownloader.ui.Hb
import com.example.videodownloader.ui.Screen
import com.example.videodownloader.util.Fmt
import com.example.videodownloader.util.Launcher
import com.example.videodownloader.util.MediaFile
import com.example.videodownloader.util.MediaIndex
import com.example.videodownloader.util.Tool
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

class HomeScreen(
    private val act: MainActivity,
    private val onOpenSettings: () -> Unit,
    private val onOpenBrowser: () -> Unit,
    private val onSearch: () -> Unit,
    private val onTool: (Tool) -> Unit,
    private val onTab: (Int) -> Unit
) : Screen {

    private val col: LinearLayout
    private lateinit var notice: TextView
    private lateinit var activeBox: LinearLayout
    private lateinit var activeList: LinearLayout
    private lateinit var activeCount: TextView
    private lateinit var quickBox: LinearLayout
    private lateinit var recentBox: LinearLayout
    private lateinit var openedBox: LinearLayout
    private lateinit var favoritesBox: LinearLayout
    private lateinit var storageFill: View
    private lateinit var storageText: TextView
    private var generation = 0

    override val root: View

    init {
        val c = act
        col = Hb.column(c, 18)
        notice = Hb.text(c, "", 12f, Hb.palette(c).blue).apply {
            visibility = View.GONE
            setPadding(0, Hb.dp(c, 6), 0, Hb.dp(c, 6))
        }
        col.addView(header())
        col.addView(notice)
        col.addView(Hb.spacer(c, 6))
        col.addView(searchBar())
        col.addView(Hb.spacer(c, 14))
        col.addView(hero())
        col.addView(Hb.section(c, "Quick actions", "Customize") { customize() })
        quickBox = LinearLayout(c).apply { orientation = LinearLayout.VERTICAL }
        col.addView(quickBox)
        fillQuickActions()
        activeBox = Hb.card(c, 14).apply { visibility = View.GONE }
        val activeHead = LinearLayout(c).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        activeHead.addView(Hb.text(c, "Queue", 14f, Hb.palette(c).text, bold = true),
            LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        activeCount = Hb.text(c, "", 10.5f, Hb.palette(c).muted)
        activeHead.addView(activeCount)
        activeBox.addView(activeHead)
        activeList = Hb.listContainer(c).apply { setPadding(0, Hb.dp(c, 4), 0, 0) }
        activeBox.addView(activeList)
        col.addView(activeBox, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
        ).apply { topMargin = Hb.dp(c, 12) })
        col.addView(statsRow())
        col.addView(Hb.section(c, "Recent downloads", "History") {
            c.startActivity(Intent(c, HistoryActivity::class.java))
        })
        recentBox = Hb.listContainer(c)
        col.addView(recentBox)
        col.addView(Hb.section(c, "Recently opened", "Library") { onTab(MainActivity.TAB_LIBRARY) })
        openedBox = Hb.listContainer(c)
        col.addView(openedBox)
        col.addView(Hb.section(c, "Favorites"))
        favoritesBox = Hb.listContainer(c)
        col.addView(favoritesBox)
        col.addView(Hb.section(c, "Storage"))
        col.addView(storageCard())
        col.addView(footer())

        root = Hb.scroll(c, col)
    }

    private fun header(): View {
        val c = act
        val p = Hb.palette(c)
        val row = LinearLayout(c).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, Hb.dp(c, 6), 0, 0)
        }
        val logo = FrameLayout(c).apply {
            background = Hb.gradient(c, 14, 0xFF2E9BFF.toInt(), 0xFF0A5FE0.toInt())
            addView(Hb.text(c, "HB", 16f, 0xFFFFFFFF.toInt(), bold = true).apply { gravity = Gravity.CENTER },
                FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
            layoutParams = LinearLayout.LayoutParams(Hb.dp(c, 44), Hb.dp(c, 44))
        }
        row.addView(logo)

        val titles = LinearLayout(c).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(Hb.dp(c, 10), 0, 0, 0)
        }
        titles.addView(Hb.text(c, "HB SUPER APP", 16f, p.text, bold = true))
        val sub = LinearLayout(c).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        sub.addView(Hb.text(c, "HB Software", 11f, p.muted))
        sub.addView(Hb.text(c, "  •  1.0", 11f, p.blue, medium = true))
        titles.addView(sub)
        row.addView(titles, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))

        row.addView(Hb.iconButton(c, R.drawable.ic_refresh, p.text, 40) {
            Updater.check(act, true) { showNotice(it) }
        }, LinearLayout.LayoutParams(Hb.dp(c, 40), Hb.dp(c, 40)).apply { marginEnd = Hb.dp(c, 8) })
        row.addView(Hb.iconButton(c, R.drawable.ic_settings, p.text, 40) { onOpenSettings() },
            LinearLayout.LayoutParams(Hb.dp(c, 40), Hb.dp(c, 40)))
        return row
    }

    private fun searchBar(): View {
        val c = act
        val p = Hb.palette(c)
        val bar = LinearLayout(c).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            background = Hb.ripple(c, Hb.round(c, 18, p.surface, p.border, 1))
            setPadding(Hb.dp(c, 14), 0, Hb.dp(c, 14), 0)
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, Hb.dp(c, 54))
        }
        bar.addView(Hb.icon(c, R.drawable.ic_search, p.muted, 20))
        bar.addView(Hb.text(c, "Search the web, files and tools", 13f, p.muted).apply {
            setPadding(Hb.dp(c, 10), 0, 0, 0)
        }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        bar.addView(Hb.icon(c, R.drawable.ic_qr, p.blue, 20))
        Hb.clickable(bar, onSearch)
        return bar
    }

    private fun hero(): View {
        val c = act
        val card = FrameLayout(c).apply {
            background = Hb.gradient(c, 22, 0xFF1476FF.toInt(), 0xFF083B8F.toInt())
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, Hb.dp(c, 150)).apply {
                topMargin = Hb.dp(c, 4)
            }
        }
        card.addView(Hb.icon(c, R.drawable.ic_browser, 0x33FFFFFF, 150), FrameLayout.LayoutParams(
            Hb.dp(c, 150), Hb.dp(c, 150), Gravity.END or Gravity.CENTER_VERTICAL
        ).apply { marginEnd = Hb.dp(c, -20) })

        val inner = LinearLayout(c).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(Hb.dp(c, 18), Hb.dp(c, 18), Hb.dp(c, 18), Hb.dp(c, 16))
        }
        val pill = Hb.text(c, "PRIVATE  •  FAST  •  BUILT IN", 9.5f, 0xFFDCEEFF.toInt(), medium = true).apply {
            background = Hb.round(c, 20, 0x33FFFFFF)
            setPadding(Hb.dp(c, 9), Hb.dp(c, 4), Hb.dp(c, 9), Hb.dp(c, 4))
        }
        inner.addView(pill, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        inner.addView(Hb.text(c, "HB Browser", 24f, 0xFFFFFFFF.toInt(), bold = true).apply {
            setPadding(0, Hb.dp(c, 9), 0, 0)
        })
        inner.addView(Hb.text(c, "Tabs, bookmarks, private mode and secure downloads.", 11.5f, 0xFFC6E2FF.toInt()))
        val open = Hb.text(c, "Open browser   ›", 12f, 0xFFFFFFFF.toInt(), medium = true).apply {
            background = Hb.ripple(c, Hb.round(c, 14, 0x33FFFFFF))
            setPadding(Hb.dp(c, 13), Hb.dp(c, 8), Hb.dp(c, 13), Hb.dp(c, 8))
        }
        inner.addView(open, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
            topMargin = Hb.dp(c, 12)
        })
        card.addView(inner, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        Hb.clickable(card, onOpenBrowser)
        Hb.pressScale(card)
        return card
    }

    private fun quickActions(): View {
        val c = act
        val chosen = Prefs.homeActions(c).mapNotNull { Tool.from(it) }
            .sortedBy { Tool.entries.indexOf(it) }
        val list = chosen.ifEmpty { Prefs.DEFAULT_HOME_ACTIONS.mapNotNull { Tool.from(it) } }
        val wrap = LinearLayout(c).apply { orientation = LinearLayout.VERTICAL }
        list.chunked(3).forEach { rowTools ->
            val row = LinearLayout(c).apply {
                orientation = LinearLayout.HORIZONTAL
                setPadding(0, 0, 0, Hb.dp(c, 9))
            }
            rowTools.forEachIndexed { i, tool ->
                row.addView(tile(tool), LinearLayout.LayoutParams(0, Hb.dp(c, 98), 1f).apply {
                    marginEnd = if (i < rowTools.lastIndex) Hb.dp(c, 9) else 0
                })
            }
            repeat(3 - rowTools.size) {
                row.addView(View(c), LinearLayout.LayoutParams(0, 1, 1f).apply {
                    marginEnd = if (it < 2 - rowTools.size) Hb.dp(c, 9) else 0
                })
            }
            wrap.addView(row)
        }
        return wrap
    }

    private fun fillQuickActions() {
        quickBox.removeAllViews()
        quickBox.addView(quickActions())
    }

    private fun tile(tool: Tool): LinearLayout {
        val c = act
        val p = Hb.palette(c)
        val tile = LinearLayout(c).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            background = Hb.ripple(c, Hb.round(c, 18, p.surface, p.border, 1))
            setPadding(Hb.dp(c, 8), Hb.dp(c, 10), Hb.dp(c, 8), Hb.dp(c, 10))
        }
        tile.addView(Hb.iconCircle(c, tool.icon, p.blue, p.blueSoft, 38))
        tile.addView(Hb.text(c, tool.title, 11f, p.text, medium = true).apply {
            gravity = Gravity.CENTER
            maxLines = 2
            setPadding(0, Hb.dp(c, 7), 0, 0)
        })
        Hb.clickable(tile) { onTool(tool) }
        Hb.pressScale(tile)
        return tile
    }

    private fun statsRow(): View {
        val c = act
        val p = Hb.palette(c)
        val row = LinearLayout(c).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(0, Hb.dp(c, 14), 0, 0)
        }
        val all = HistoryStore.all(c)
        val done = all.count { it.ok }
        val totalSize = all.sumOf { it.size }
        val three = listOf(
            Triple("${all.size}", "Downloads", p.text),
            Triple("$done", "Completed", p.success),
            Triple(Fmt.bytes(totalSize), "Saved", p.blue)
        )
        three.forEachIndexed { i, (v, l, tint) ->
            val card = Hb.stat(c, l, v, tint)
            row.addView(card, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply {
                marginEnd = if (i < 2) Hb.dp(c, 8) else 0
            })
        }
        return row
    }

    private fun storageCard(): View {
        val c = act
        val p = Hb.palette(c)
        val card = Hb.card(c, 15)
        val top = LinearLayout(c).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        top.addView(Hb.iconCircle(c, R.drawable.ic_storage, p.blue, p.blueSoft, 40))
        val labels = LinearLayout(c).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(Hb.dp(c, 10), 0, 0, 0)
        }
        labels.addView(Hb.text(c, "Internal storage", 13.5f, p.text, medium = true))
        storageText = Hb.text(c, "Calculating...", 11.5f, p.muted)
        labels.addView(storageText)
        top.addView(labels, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        card.addView(top)

        val track = FrameLayout(c).apply {
            background = Hb.round(c, 5, p.surfaceAlt)
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, Hb.dp(c, 7)).apply {
                topMargin = Hb.dp(c, 12)
            }
        }
        storageFill = View(c).apply { background = Hb.round(c, 5, p.blue) }
        track.addView(storageFill, FrameLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT))
        card.addView(track)

        val buttons = LinearLayout(c).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(0, Hb.dp(c, 12), 0, 0)
        }
        val b1 = Hb.text(c, "Analyze", 12f, p.blue, medium = true).apply {
            background = Hb.ripple(c, Hb.round(c, 12, p.blueSoft))
            gravity = Gravity.CENTER
            setPadding(0, Hb.dp(c, 9), 0, Hb.dp(c, 9))
        }
        Hb.clickable(b1) { onTool(Tool.STORAGE) }
        val b2 = Hb.text(c, "Files", 12f, p.text, medium = true).apply {
            background = Hb.ripple(c, Hb.round(c, 12, p.surfaceAlt, p.border, 1))
            gravity = Gravity.CENTER
            setPadding(0, Hb.dp(c, 9), 0, Hb.dp(c, 9))
        }
        Hb.clickable(b2) { onTool(Tool.FILES) }
        buttons.addView(b1, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { marginEnd = Hb.dp(c, 8) })
        buttons.addView(b2, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        card.addView(buttons)
        return card
    }

    private fun footer(): View {
        val c = act
        val p = Hb.palette(c)
        return LinearLayout(c).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(0, Hb.dp(c, 22), 0, 0)
            addView(Hb.text(c, "HB Super App 1.0", 11f, p.muted, medium = true))
            addView(Hb.text(c, "HB Software  •  Credit by Hakim Zaib", 10.5f, p.muted).apply {
                setPadding(0, Hb.dp(c, 3), 0, 0)
            })
        }
    }

    private fun customize() {
        val c = act
        val tools = Tool.entries
        val current = Prefs.homeActions(c)
        val checked = tools.map { it.id in current }.toBooleanArray()
        androidx.appcompat.app.AlertDialog.Builder(c, R.style.HbDialog)
            .setTitle("Quick actions")
            .setMultiChoiceItems(tools.map { it.title }.toTypedArray(), checked) { _, which, isChecked ->
                checked[which] = isChecked
            }
            .setPositiveButton("Save") { _, _ ->
                val chosen = tools.filterIndexed { i, _ -> checked[i] }.map { it.id }.toSet()
                Prefs.setHomeActions(c, chosen)
                fillQuickActions()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    fun showNotice(msg: String) {
        if (msg.isBlank()) return
        notice.text = msg
        notice.isVisible = true
        notice.alpha = 0f
        notice.animate().alpha(1f).setDuration(220).start()
    }

    fun refreshUpdateLabel() {
        // The refresh icon leads to a manual check; no persistent text is required.
    }

    fun onDownloadsChanged(items: List<ActiveDownload>) = renderActive(items)

    private fun renderActive(items: List<ActiveDownload>) {
        val c = act
        val p = Hb.palette(c)
        activeBox.isVisible = items.isNotEmpty()
        if (items.isEmpty()) {
            activeList.removeAllViews()
            return
        }
        activeCount.text = "${items.size} active"
        activeList.removeAllViews()
        items.forEach { d ->
            val row = LinearLayout(c).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(0, Hb.dp(c, 9), 0, Hb.dp(c, 9))
            }
            val top = LinearLayout(c).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
            top.addView(Hb.text(c, d.site + if (d.audio) " • MP3" else "", 12.5f, p.text, medium = true),
                LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            top.addView(Hb.text(c, if (d.indeterminate) "..." else "${d.percent}%", 11.5f, p.blue, medium = true))
            row.addView(top)
            row.addView(Hb.text(c, d.text, 10.5f, p.muted).apply { maxLines = 1 })
            val bar = Hb.progress(c)
            if (!d.indeterminate) bar.progress = d.percent
            else bar.isIndeterminate = true
            row.addView(bar, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, Hb.dp(c, 5)).apply {
                topMargin = Hb.dp(c, 6)
            })
            val controls = LinearLayout(c).apply {
                orientation = LinearLayout.HORIZONTAL
                setPadding(0, Hb.dp(c, 7), 0, 0)
            }
            val pause = Hb.text(c, if (d.paused) "Resume" else "Pause", 10.5f, p.blue, medium = true).apply {
                background = Hb.ripple(c, Hb.round(c, 10, p.blueSoft))
                setPadding(Hb.dp(c, 10), Hb.dp(c, 5), Hb.dp(c, 10), Hb.dp(c, 5))
            }
            Hb.clickable(pause) {
                if (d.paused) DownloadControl.resume(d.id) else DownloadControl.pause(d.id)
            }
            val cancel = Hb.text(c, "Cancel", 10.5f, p.danger, medium = true).apply {
                background = Hb.ripple(c, Hb.round(c, 10, 0x22FF5C6B))
                setPadding(Hb.dp(c, 10), Hb.dp(c, 5), Hb.dp(c, 10), Hb.dp(c, 5))
            }
            Hb.clickable(cancel) { DownloadControl.cancel(d.id) }
            controls.addView(pause, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { marginEnd = Hb.dp(c, 8) })
            controls.addView(cancel)
            row.addView(controls)
            activeList.addView(row)
        }
    }

    override fun onShow() {
        showNotice("")
        refresh()
    }

    override fun refresh() {
        val gen = ++generation
        act.lifecycleScope.launch {
            val history = withContext(Dispatchers.IO) { HistoryStore.all(act) }
            val recent = withContext(Dispatchers.IO) { MediaIndex.recent(act, 6) }
            val storage = withContext(Dispatchers.IO) { storageStats() }
            if (gen != generation) return@launch
            renderHistory(history)
            renderOpened(recent)
            renderFavorites()
            renderStorage(storage)
            renderActive(DownloadTracker.items.value)
        }
    }

    private fun renderHistory(all: List<com.example.videodownloader.HistoryItem>) {
        val c = act
        recentBox.removeAllViews()
        if (all.isEmpty()) {
            recentBox.addView(Hb.empty(c, R.drawable.ic_download, "No downloads yet", "Paste a link in Downloads to get started"))
            return
        }
        all.take(4).forEach { h ->
            val row = Hb.row(
                c,
                if (HistoryStore.isAudioItem(h)) R.drawable.ic_music else R.drawable.ic_download,
                h.title.ifBlank { Fmt.titleFromUrl(h.url) },
                "${Fmt.ago(h.time)}  •  ${if (h.ok) Fmt.bytes(h.size) else "Failed"}",
                onClick = {
                    if (h.ok && h.uri != null) {
                        Launcher.openFile(c, android.net.Uri.parse(h.uri), h.mime ?: "*/*")
                    } else {
                        c.startActivity(Intent(c, HistoryActivity::class.java))
                    }
                }
            )
            recentBox.addView(row)
            recentBox.addView(Hb.divider(c, 54))
        }
    }

    private fun renderOpened(list: List<MediaFile>) {
        val c = act
        openedBox.removeAllViews()
        if (list.isEmpty()) {
            openedBox.addView(Hb.empty(c, R.drawable.ic_library, "Nothing opened yet", "Play a video or open a photo from Library"))
            return
        }
        list.take(4).forEach { m ->
            openedBox.addView(Hb.row(
                c, iconFor(m.mime), m.name,
                "${Fmt.ago(m.dateMs)}  •  ${Fmt.bytes(m.size)}",
                onClick = { Launcher.openFile(c, m.uri, m.mime) }
            ))
            openedBox.addView(Hb.divider(c, 54))
        }
    }

    private fun iconFor(mime: String): Int = when {
        mime.startsWith("video") -> R.drawable.ic_play
        mime.startsWith("audio") -> R.drawable.ic_music
        mime.startsWith("image") -> R.drawable.ic_image
        mime == "application/pdf" -> R.drawable.ic_pdf
        else -> R.drawable.ic_file
    }

    private fun renderFavorites() {
        val c = act
        favoritesBox.removeAllViews()
        val favs = Prefs.favoriteTools(c).mapNotNull { Tool.from(it) }
        if (favs.isEmpty()) {
            favoritesBox.addView(Hb.empty(c, R.drawable.ic_star, "No favorites yet", "Star tools in the Tools tab"))
            return
        }
        favs.take(4).forEach { tool ->
            favoritesBox.addView(Hb.row(c, tool.icon, tool.title, tool.subtitle, onClick = { onTool(tool) }))
        }
    }

    private fun storageStats(): Triple<Long, Long, Long> {
        return try {
            val stat = StatFs(Environment.getExternalStorageDirectory().absolutePath)
            val total = stat.blockCountLong * stat.blockSizeLong
            val free = stat.availableBlocksLong * stat.blockSizeLong
            val appCache = dirSize(act.cacheDir)
            Triple(total, free, appCache)
        } catch (_: Exception) {
            Triple(1L, 1L, 0L)
        }
    }

    private fun dirSize(f: File): Long {
        if (!f.exists()) return 0
        if (f.isFile) return f.length()
        var total = 0L
        f.listFiles()?.forEach { total += dirSize(it) }
        return total
    }

    private fun renderStorage(s: Triple<Long, Long, Long>) {
        val (total, free, cache) = s
        val used = total - free
        val pct = if (total > 0) (used * 100 / total).toInt() else 0
        storageText.text = "${Fmt.bytes(free)} free of ${Fmt.bytes(total)}  •  cache ${Fmt.bytes(cache)}"
        storageFill.post {
            val w = (storageFill.parent as? View)?.width ?: 0
            if (w > 0) {
                (storageFill.layoutParams as android.widget.FrameLayout.LayoutParams).width =
                    (w * pct / 100f).toInt().coerceAtLeast(Hb.dp(act, 2))
                storageFill.requestLayout()
            }
        }
    }
}
