package com.example.videodownloader.browser

import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import androidx.core.view.isVisible
import com.example.videodownloader.R
import com.example.videodownloader.ui.BaseActivity
import com.example.videodownloader.ui.Hb
import com.example.videodownloader.util.Fmt
import com.example.videodownloader.util.Launcher
import java.util.Calendar

class BrowserHistoryActivity : BaseActivity() {

    private lateinit var listCol: LinearLayout
    private var query = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val p = Hb.palette(this)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(p.bg)
        }
        root.addView(Hb.topBar(this, "Browsing history", "Stored only on this phone", onBack = { finish() }, actions = listOf(
            R.drawable.ic_delete to { clearAll() }
        )))

        val searchWrap = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(Hb.dp(this@BrowserHistoryActivity, 16), Hb.dp(this@BrowserHistoryActivity, 4),
                Hb.dp(this@BrowserHistoryActivity, 16), Hb.dp(this@BrowserHistoryActivity, 8))
        }
        val search = EditText(this).apply {
            hint = "Search history"
            setHintTextColor(p.muted)
            setTextColor(p.text)
            textSize = 14f
            setSingleLine(true)
            background = Hb.round(this@BrowserHistoryActivity, 14, p.surface, p.border, 1)
            setPadding(Hb.dp(this@BrowserHistoryActivity, 14), 0, Hb.dp(this@BrowserHistoryActivity, 14), 0)
            addTextChangedListener(object : TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
                override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
                override fun afterTextChanged(s: Editable?) {
                    query = s?.toString() ?: ""
                    render()
                }
            })
        }
        searchWrap.addView(search, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, Hb.dp(this, 46)))
        root.addView(searchWrap)

        val scroll = ScrollView(this).apply {
            setBackgroundColor(p.bg)
            overScrollMode = View.OVER_SCROLL_NEVER
        }
        listCol = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(Hb.dp(this@BrowserHistoryActivity, 16), 0,
                Hb.dp(this@BrowserHistoryActivity, 16), Hb.dp(this@BrowserHistoryActivity, 28))
        }
        scroll.addView(listCol)
        root.addView(scroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))

        setContentView(root)
        render()
    }

    private fun render() {
        listCol.removeAllViews()
        val all = BrowserStore.searchHistory(this, query)
        if (all.isEmpty()) {
            listCol.addView(Hb.empty(this, R.drawable.ic_history, "No history yet",
                "Pages you visit in HB Browser appear here. Private tabs never do."))
            return
        }

        var lastDay = ""
        all.forEach { entry ->
            val day = dayLabel(entry.time)
            if (day != lastDay) {
                lastDay = day
                listCol.addView(Hb.section(this, day))
            }
            val row = Hb.row(
                this,
                R.drawable.ic_history,
                entry.title.ifBlank { BrowserUrl.display(entry.url) },
                BrowserUrl.display(entry.url),
                trailing = Fmt.ago(entry.time)
            ) {
                Launcher.openUrl(this, entry.url)
                finish()
            }
            row.setOnLongClickListener {
                Hb.confirm(this, "Remove this page?", entry.title.ifBlank { BrowserUrl.display(entry.url) }, "Remove", destructive = true) {
                    BrowserStore.removeHistory(this, entry.id)
                    render()
                }
                true
            }
            listCol.addView(row)
            listCol.addView(Hb.divider(this, 46))
        }
        if (all.isNotEmpty()) {
            listCol.addView(Hb.spacer(this, 8))
            listCol.addView(Hb.text(this, "Long-press an entry to remove it.", 11f, Hb.palette(this).muted).apply {
                gravity = Gravity.CENTER
            })
        }
    }

    private fun dayLabel(time: Long): String {
        val now = Calendar.getInstance()
        val then = Calendar.getInstance().apply { timeInMillis = time }
        val sameDay = now.get(Calendar.YEAR) == then.get(Calendar.YEAR) &&
            now.get(Calendar.DAY_OF_YEAR) == then.get(Calendar.DAY_OF_YEAR)
        if (sameDay) return "Today"
        now.add(Calendar.DAY_OF_YEAR, -1)
        val yesterday = now.get(Calendar.YEAR) == then.get(Calendar.YEAR) &&
            now.get(Calendar.DAY_OF_YEAR) == then.get(Calendar.DAY_OF_YEAR)
        return if (yesterday) "Yesterday" else Fmt.shortDate(time)
    }

    private fun clearAll() {
        if (BrowserStore.history(this).isEmpty()) {
            Hb.toast(this, "History is already empty")
            return
        }
        Hb.confirm(this, "Clear all history?", "This removes every page stored by HB Browser on this phone. Bookmarks are not touched.", "Clear", destructive = true) {
            BrowserStore.clearHistory(this)
            render()
        }
    }
}
