package com.example.videodownloader.screens

import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.content.ContextCompat
import androidx.core.view.isVisible
import androidx.lifecycle.lifecycleScope
import com.example.videodownloader.ActiveDownload
import com.example.videodownloader.DownloadControl
import com.example.videodownloader.DownloadService
import com.example.videodownloader.DownloadTracker
import com.example.videodownloader.HistoryActivity
import com.example.videodownloader.HistoryStore
import com.example.videodownloader.MainActivity
import com.example.videodownloader.Prefs
import com.example.videodownloader.Quality
import com.example.videodownloader.R
import com.example.videodownloader.SaveStore
import com.example.videodownloader.ui.Hb
import com.example.videodownloader.ui.Screen
import com.example.videodownloader.util.Fmt
import com.example.videodownloader.util.Launcher
import com.example.videodownloader.util.Tool
import com.yausername.youtubedl_android.YoutubeDL
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class DownloadsScreen(private val act: MainActivity) : Screen {

    private lateinit var etUrl: EditText
    private lateinit var typeVideo: TextView
    private lateinit var typeAudio: TextView
    private lateinit var qualityRow: LinearLayout
    private lateinit var downloadBtn: LinearLayout
    private lateinit var secondaryBtn: LinearLayout
    private lateinit var clipCard: LinearLayout
    private lateinit var clipText: TextView
    private lateinit var activeBox: LinearLayout
    private lateinit var activeList: LinearLayout
    private lateinit var activeCount: TextView
    private lateinit var tvVideoPath: TextView
    private lateinit var tvAudioPath: TextView
    private lateinit var historyBox: LinearLayout
    private lateinit var engineBtn: TextView
    private lateinit var engineInfo: TextView

    private var audioMode = false
    private var clipboardUrl: String? = null
    private var engineBusy = false

    override val root: View

    init {
        val c = act
        val p = Hb.palette(c)
        val col = Hb.column(c, 18)

        val header = LinearLayout(c).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, Hb.dp(c, 4), 0, 0)
        }
        val titles = LinearLayout(c).apply { orientation = LinearLayout.VERTICAL }
        titles.addView(Hb.text(c, "Downloader Pro", 22f, p.text, bold = true))
        titles.addView(Hb.text(c, "yt-dlp + FFmpeg • real background downloads", 11f, p.muted))
        header.addView(titles, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        header.addView(Hb.iconButton(c, R.drawable.ic_history, p.text, 40) {
            c.startActivity(Intent(c, HistoryActivity::class.java))
        }, LinearLayout.LayoutParams(Hb.dp(c, 40), Hb.dp(c, 40)).apply { marginEnd = Hb.dp(c, 8) })
        header.addView(Hb.iconButton(c, R.drawable.ic_settings, p.text, 40) {
            c.startActivity(Intent(c, com.example.videodownloader.settings.SettingsActivity::class.java))
        }, LinearLayout.LayoutParams(Hb.dp(c, 40), Hb.dp(c, 40)))
        col.addView(header)

        // Clipboard suggestion
        clipCard = LinearLayout(c).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            background = Hb.round(c, 16, p.blueSoft, p.blue, 1)
            setPadding(Hb.dp(c, 12), Hb.dp(c, 10), Hb.dp(c, 12), Hb.dp(c, 10))
            visibility = View.GONE
        }
        clipText = Hb.text(c, "", 11.5f, p.text).apply { maxLines = 1 }
        clipCard.addView(Hb.icon(c, R.drawable.ic_link, p.blue, 22),
            LinearLayout.LayoutParams(Hb.dp(c, 22), Hb.dp(c, 22)).apply { marginEnd = Hb.dp(c, 9) })
        clipCard.addView(clipText, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        val use = Hb.text(c, "Paste", 11.5f, p.blue, medium = true)
        Hb.clickable(use) {
            etUrl.setText(clipboardUrl)
            clipCard.isVisible = false
        }
        clipCard.addView(use)
        col.addView(clipCard, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
        ).apply { topMargin = Hb.dp(c, 14) })

        // Link card
        val linkCard = Hb.card(c, 16).apply {
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
                .apply { topMargin = Hb.dp(c, 14) }
        }
        linkCard.addView(Hb.text(c, "New download", 15f, p.text, bold = true))
        linkCard.addView(Hb.text(c, "Paste one link, or several links separated by spaces or new lines.", 11.5f, p.muted).apply {
            setPadding(0, Hb.dp(c, 4), 0, Hb.dp(c, 10))
        })
        etUrl = EditText(c).apply {
            hint = "Paste a link"
            setHintTextColor(p.muted)
            setTextColor(p.text)
            textSize = 13f
            background = Hb.round(c, 14, p.surfaceAlt, p.border, 1)
            setPadding(Hb.dp(c, 13), 0, Hb.dp(c, 13), 0)
            minHeight = Hb.dp(c, 52)
            inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_VARIATION_URI or
                android.text.InputType.TYPE_TEXT_FLAG_MULTI_LINE
            maxLines = 3
            imeOptions = EditorInfo.IME_ACTION_DONE
        }
        linkCard.addView(etUrl)

        val pasteRow = LinearLayout(c).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(0, Hb.dp(c, 9), 0, 0)
        }
        val paste = Hb.text(c, "Paste from clipboard", 12f, p.text, medium = true).apply {
            background = Hb.ripple(c, Hb.round(c, 12, p.surfaceAlt, p.border, 1))
            gravity = Gravity.CENTER
            setPadding(0, Hb.dp(c, 9), 0, Hb.dp(c, 9))
        }
        Hb.clickable(paste) { pasteClipboard() }
        pasteRow.addView(paste, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { marginEnd = Hb.dp(c, 8) })
        val browse = Hb.text(c, "Open browser", 12f, p.blue, medium = true).apply {
            background = Hb.ripple(c, Hb.round(c, 12, p.blueSoft))
            gravity = Gravity.CENTER
            setPadding(0, Hb.dp(c, 9), 0, Hb.dp(c, 9))
        }
        Hb.clickable(browse) { act.selectTab(MainActivity.TAB_BROWSER) }
        pasteRow.addView(browse, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        linkCard.addView(pasteRow)

        // Type switch
        linkCard.addView(Hb.text(c, "Download as", 11.5f, p.muted).apply { setPadding(0, Hb.dp(c, 14), 0, Hb.dp(c, 6)) })
        val typeRow = LinearLayout(c).apply { orientation = LinearLayout.HORIZONTAL }
        typeVideo = typeButton("Video")
        typeAudio = typeButton("Audio (MP3)")
        typeRow.addView(typeVideo, LinearLayout.LayoutParams(0, Hb.dp(c, 42), 1f).apply { marginEnd = Hb.dp(c, 8) })
        typeRow.addView(typeAudio, LinearLayout.LayoutParams(0, Hb.dp(c, 42), 1f))
        linkCard.addView(typeRow)

        linkCard.addView(Hb.text(c, "Quality", 11.5f, p.muted).apply { setPadding(0, Hb.dp(c, 14), 0, Hb.dp(c, 6)) })
        val qualityScroll = HorizontalScrollView(c).apply {
            isHorizontalScrollBarEnabled = false
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        }
        qualityRow = LinearLayout(c).apply { orientation = LinearLayout.HORIZONTAL }
        qualityScroll.addView(qualityRow)
        linkCard.addView(qualityScroll)
        buildQualityChips()

        downloadBtn = Hb.button(c, "Download", true, R.drawable.ic_download, 52) { startDownload(audioMode) }
        linkCard.addView(downloadBtn, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, Hb.dp(c, 52)
        ).apply { topMargin = Hb.dp(c, 14) })
        secondaryBtn = Hb.button(c, "", false, 0, 48) { startDownload(!audioMode) }
        linkCard.addView(secondaryBtn, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, Hb.dp(c, 48)
        ).apply { topMargin = Hb.dp(c, 9) })
        col.addView(linkCard)

        // Active queue
        activeBox = Hb.card(c, 15).apply { visibility = View.GONE }
        val activeHead = LinearLayout(c).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        activeHead.addView(Hb.text(c, "Queue", 15f, p.text, bold = true),
            LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        activeCount = Hb.text(c, "", 11f, p.blue, medium = true)
        activeHead.addView(activeCount)
        activeBox.addView(activeHead)
        activeList = Hb.listContainer(c)
        activeBox.addView(activeList)
        col.addView(activeBox, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
        ).apply { topMargin = Hb.dp(c, 14) })

        // Save locations
        col.addView(Hb.section(c, "Save location"))
        val saveCard = Hb.card(c, 15)
        saveCard.addView(label("Videos and photos"))
        tvVideoPath = Hb.text(c, "", 12f, p.blue).apply { setPadding(0, Hb.dp(c, 3), 0, Hb.dp(c, 8)) }
        saveCard.addView(tvVideoPath)
        saveCard.addView(folderButtons(false))
        saveCard.addView(label("MP3 / audio").apply { setPadding(0, Hb.dp(c, 12), 0, 0) })
        tvAudioPath = Hb.text(c, "", 12f, p.blue).apply { setPadding(0, Hb.dp(c, 3), 0, Hb.dp(c, 8)) }
        saveCard.addView(tvAudioPath)
        saveCard.addView(folderButtons(true))
        saveCard.addView(Hb.toggleRow(c, "Wi-Fi only", "Wait for Wi-Fi to save mobile data", Prefs.wifiOnly(c)) {
            Prefs.setWifiOnly(c, it)
        })
        saveCard.addView(Hb.toggleRow(c, "YouTube folder", "Keep YouTube files in their own folder", Prefs.youtubeFolder(c)) {
            Prefs.setYoutubeFolder(c, it)
        })
        col.addView(saveCard)

        // Engine update
        col.addView(Hb.section(c, "Download engine"))
        val engineCard = Hb.card(c, 15)
        val engineTop = LinearLayout(c).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        engineTop.addView(Hb.iconCircle(c, R.drawable.ic_refresh, p.blue, p.blueSoft, 42))
        val engineLabels = LinearLayout(c).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(Hb.dp(c, 10), 0, 0, 0)
        }
        engineLabels.addView(Hb.text(c, "yt-dlp auto-update", 13.5f, p.text, medium = true))
        engineInfo = Hb.text(c, "", 11f, p.muted)
        engineLabels.addView(engineInfo)
        engineTop.addView(engineLabels, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        engineBtn = Hb.text(c, "Update", 11.5f, p.blue, medium = true).apply {
            background = Hb.ripple(c, Hb.round(c, 12, p.blueSoft))
            setPadding(Hb.dp(c, 12), Hb.dp(c, 7), Hb.dp(c, 12), Hb.dp(c, 7))
        }
        Hb.clickable(engineBtn) { updateEngine() }
        engineTop.addView(engineBtn)
        engineCard.addView(engineTop)
        col.addView(engineCard)

        // Recent history
        col.addView(Hb.section(c, "Recent downloads", "See all") {
            c.startActivity(Intent(c, HistoryActivity::class.java))
        })
        historyBox = Hb.listContainer(c)
        col.addView(historyBox)

        // Tips
        val tip = Hb.card(c, 14, 18, p.surfaceAlt)
        tip.addView(Hb.text(c, "Tips", 12f, p.blue, medium = true))
        tip.addView(Hb.text(c,
            "• Share a link from any app and choose HB Super App.\n" +
            "• The same link is never downloaded twice.\n" +
            "• Pause and resume from here or from the notification.\n" +
            "• Download only content you are allowed to save.",
            11.5f, p.muted).apply { setPadding(0, Hb.dp(c, 6), 0, 0) })
        col.addView(tip, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
        ).apply { topMargin = Hb.dp(c, 18) })

        root = Hb.scroll(c, col)
        syncModeButtons()
        refreshPaths()
        refreshEngineInfo()
        etUrl.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_DONE) {
                startDownload(audioMode)
                true
            } else false
        }
    }

    private fun label(s: String): TextView = Hb.text(act, s, 11.5f, Hb.palette(act).muted)

    private fun typeButton(label: String): TextView {
        val p = Hb.palette(act)
        return Hb.text(act, label, 12.5f, p.muted, medium = true).apply {
            gravity = Gravity.CENTER
            setPadding(0, Hb.dp(act, 9), 0, Hb.dp(act, 9))
            background = Hb.ripple(act, Hb.round(act, 13, p.surfaceAlt, p.border, 1))
            Hb.clickable(this) {
                audioMode = label.startsWith("Audio")
                Prefs.setAudioDefault(act, audioMode)
                syncModeButtons()
            }
        }
    }

    private fun syncModeButtons() {
        val p = Hb.palette(act)
        fun style(v: TextView, on: Boolean) {
            v.setTextColor(if (on) android.graphics.Color.WHITE else p.muted)
            v.background = Hb.ripple(act, if (on) Hb.round(act, 13, p.blue) else Hb.round(act, 13, p.surfaceAlt, p.border, 1))
        }
        style(typeVideo, !audioMode)
        style(typeAudio, audioMode)
        (downloadBtn.getChildAt(downloadBtn.childCount - 1) as TextView).text =
            if (audioMode) "Download audio" else "Download video"
        (secondaryBtn.getChildAt(secondaryBtn.childCount - 1) as TextView).text =
            if (audioMode) "Download video instead" else "Download audio only (MP3)"
    }

    private fun buildQualityChips() {
        val c = act
        qualityRow.removeAllViews()
        val current = Prefs.quality(c)
        Quality.heights.forEachIndexed { i, h ->
            val label = if (h == 2160) "4K" else "${h}p"
            val chip = Hb.chip(c, label, h == current)
            chip.layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { marginEnd = Hb.dp(c, 7) }
            Hb.clickable(chip) {
                Prefs.setQuality(c, h)
                buildQualityChips()
            }
            qualityRow.addView(chip)
        }
    }

    private fun folderButtons(audio: Boolean): View {
        val c = act
        val p = Hb.palette(c)
        val row = LinearLayout(c).apply { orientation = LinearLayout.HORIZONTAL }
        val choose = Hb.text(c, "Choose folder", 11.5f, p.text, medium = true).apply {
            background = Hb.ripple(c, Hb.round(c, 12, p.surfaceAlt, p.border, 1))
            gravity = Gravity.CENTER
            setPadding(0, Hb.dp(c, 8), 0, Hb.dp(c, 8))
        }
        Hb.clickable(choose) {
            act.pickFolder { uri ->
                val old = if (audio) Prefs.audioTree(c) else Prefs.videoTree(c)
                if (old != null && old != uri.toString()) releaseFolder(old)
                if (audio) Prefs.setAudioTree(c, uri.toString()) else Prefs.setVideoTree(c, uri.toString())
                refreshPaths()
                Hb.toast(c, "Saved. New downloads go to this folder.")
            }
        }
        val def = Hb.text(c, "Default", 11.5f, p.muted, medium = true).apply {
            background = Hb.ripple(c, Hb.round(c, 12, p.surfaceAlt, p.border, 1))
            gravity = Gravity.CENTER
            setPadding(0, Hb.dp(c, 8), 0, Hb.dp(c, 8))
        }
        Hb.clickable(def) {
            val old = if (audio) Prefs.audioTree(c) else Prefs.videoTree(c)
            if (old != null) releaseFolder(old)
            if (audio) Prefs.setAudioTree(c, null) else Prefs.setVideoTree(c, null)
            refreshPaths()
        }
        row.addView(choose, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { marginEnd = Hb.dp(c, 8) })
        row.addView(def, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        return row
    }

    private fun releaseFolder(tree: String) {
        try {
            act.contentResolver.releasePersistableUriPermission(
                Uri.parse(tree),
                Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
            )
        } catch (_: Exception) {
        }
    }

    private fun refreshPaths() {
        val c = act
        fun line(tree: String?, fallback: String): String {
            val text = SaveStore.label(tree, fallback)
            return if (tree != null && !SaveStore.hasAccess(c, tree)) "$text  (access lost — choose again)" else text
        }
        if (::tvVideoPath.isInitialized) {
            tvVideoPath.text = line(Prefs.videoTree(c), "Default: DCIM/HB AIO (Gallery)")
            tvAudioPath.text = line(Prefs.audioTree(c), "Default: Music/HB AIO")
        }
    }

    private fun pasteClipboard() {
        val cm = act.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        val text = cm.primaryClip?.takeIf { it.itemCount > 0 }
            ?.getItemAt(0)?.coerceToText(act)?.toString().orEmpty()
        val url = Regex("https?://\\S+").find(text)?.value
        if (url.isNullOrBlank()) {
            Hb.toast(act, "Clipboard has no link")
        } else {
            etUrl.setText(url)
        }
    }

    private fun detectClipboard() {
        try {
            val cm = act.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            val text = cm.primaryClip?.takeIf { it.itemCount > 0 }
                ?.getItemAt(0)?.coerceToText(act)?.toString().orEmpty()
            val url = Regex("https?://\\S+").find(text)?.value
            if (url != null && url != etUrl.text.toString().trim()) {
                clipboardUrl = url
                clipText.text = url.take(52)
                clipCard.isVisible = true
            } else {
                clipCard.isVisible = false
            }
        } catch (_: Exception) {
        }
    }

    private fun startDownload(audio: Boolean) {
        val c = act
        val urls = Regex("https?://\\S+").findAll(etUrl.text.toString())
            .map { it.value }.distinct().take(10).toList()
        if (urls.isEmpty()) {
            Hb.toast(c, "Enter a valid link")
            return
        }
        val fresh = urls.filter { !DownloadTracker.isActive(it, audio) }
        if (fresh.isEmpty()) {
            Hb.toast(c, "Already downloading this link")
            return
        }
        fresh.forEach { u ->
            ContextCompat.startForegroundService(
                c,
                Intent(c, DownloadService::class.java)
                    .putExtra(DownloadService.EXTRA_URL, u)
                    .putExtra(DownloadService.EXTRA_AUDIO, audio)
            )
        }
        Hb.toast(c, when {
            fresh.size > 1 -> "${fresh.size} downloads started in the background"
            audio -> "Audio download started in the background"
            else -> "Download started in the background"
        })
        etUrl.setText("")
        clipCard.isVisible = false
    }

    private fun updateEngine() {
        if (engineBusy) return
        engineBusy = true
        engineBtn.text = "Updating..."
        act.lifecycleScope.launch {
            val msg = try {
                var result = ""
                val ran = com.example.videodownloader.YtDlpGate.updateWhenIdle {
                    YoutubeDL.getInstance().init(act)
                    val s = YoutubeDL.getInstance().updateYoutubeDL(act, YoutubeDL.UpdateChannel.NIGHTLY)
                    result = "Engine updated: $s"
                    Prefs.setLastYtdlpUpdate(act, System.currentTimeMillis())
                }
                if (ran) result else "A download is running. Update the engine after it finishes."
            } catch (e: Exception) {
                "Update error: ${e.message}"
            }
            engineBusy = false
            engineBtn.text = "Update"
            refreshEngineInfo()
            Hb.toast(act, msg)
        }
    }

    private fun refreshEngineInfo() {
        val last = Prefs.lastYtdlpUpdate(act)
        engineInfo.text = if (last <= 0) "Checks automatically (every 3 days)"
        else "Last update: ${Fmt.ago(last)}"
    }

    fun renderActive(items: List<ActiveDownload>) {
        if (!::activeList.isInitialized) return
        val c = act
        val p = Hb.palette(c)
        activeBox.isVisible = items.isNotEmpty()
        activeList.removeAllViews()
        if (items.isEmpty()) return
        activeCount.text = "${items.size} active"
        items.forEach { d ->
            val row = LinearLayout(c).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(0, Hb.dp(c, 10), 0, Hb.dp(c, 10))
            }
            val top = LinearLayout(c).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
            top.addView(Hb.text(c, d.site + if (d.audio) " • MP3" else "", 13f, p.text, medium = true),
                LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            top.addView(Hb.text(c, if (d.indeterminate) "..." else "${d.percent}%", 12f, p.blue, medium = true))
            row.addView(top)
            row.addView(Hb.text(c, d.text, 10.5f, p.muted).apply { maxLines = 1 })
            val bar = Hb.progress(c)
            if (d.indeterminate) bar.isIndeterminate = true else bar.progress = d.percent
            row.addView(bar, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, Hb.dp(c, 6)).apply {
                topMargin = Hb.dp(c, 7)
            })
            val controls = LinearLayout(c).apply { orientation = LinearLayout.HORIZONTAL; setPadding(0, Hb.dp(c, 8), 0, 0) }
            val pause = Hb.text(c, if (d.paused) "Resume" else "Pause", 11f, p.blue, medium = true).apply {
                background = Hb.ripple(c, Hb.round(c, 10, p.blueSoft))
                setPadding(Hb.dp(c, 11), Hb.dp(c, 5), Hb.dp(c, 11), Hb.dp(c, 5))
            }
            Hb.clickable(pause) { if (d.paused) DownloadControl.resume(d.id) else DownloadControl.pause(d.id) }
            val cancel = Hb.text(c, "Cancel", 11f, p.danger, medium = true).apply {
                background = Hb.ripple(c, Hb.round(c, 10, 0x22FF5C6B))
                setPadding(Hb.dp(c, 11), Hb.dp(c, 5), Hb.dp(c, 11), Hb.dp(c, 5))
            }
            Hb.clickable(cancel) { DownloadControl.cancel(d.id) }
            controls.addView(pause, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { marginEnd = Hb.dp(c, 8) })
            controls.addView(cancel)
            row.addView(controls)
            activeList.addView(row)
            activeList.addView(Hb.divider(c))
        }
    }

    override fun onShow() {
        detectClipboard()
        refresh()
    }

    override fun refresh() {
        if (!::historyBox.isInitialized) return
        refreshPaths()
        refreshEngineInfo()
        val c = act
        act.lifecycleScope.launch {
            val all = withContext(Dispatchers.IO) { HistoryStore.all(c) }
            val p = Hb.palette(c)
            historyBox.removeAllViews()
            if (all.isEmpty()) {
                historyBox.addView(Hb.empty(c, R.drawable.ic_history, "No downloads yet", "Your finished downloads will appear here"))
            } else {
                all.take(4).forEach { h ->
                    historyBox.addView(Hb.row(
                        c,
                        if (HistoryStore.isAudioItem(h)) R.drawable.ic_music else R.drawable.ic_download,
                        h.title.ifBlank { Fmt.titleFromUrl(h.url) },
                        "${Fmt.ago(h.time)}  •  ${if (h.ok) Fmt.bytes(h.size) else "Failed"}",
                        onClick = {
                            if (h.ok && h.uri != null) Launcher.openFile(c, Uri.parse(h.uri), h.mime ?: "*/*")
                            else c.startActivity(Intent(c, HistoryActivity::class.java))
                        }
                    ))
                }
            }
        }
        renderActive(DownloadTracker.items.value)
    }
}
