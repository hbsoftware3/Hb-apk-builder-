package com.example.videodownloader.settings

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatDelegate
import androidx.lifecycle.lifecycleScope
import com.example.videodownloader.Prefs
import com.example.videodownloader.Quality
import com.example.videodownloader.R
import com.example.videodownloader.SaveStore
import com.example.videodownloader.Site
import com.example.videodownloader.SiteLogin
import com.example.videodownloader.Updater
import com.example.videodownloader.YtDlpAutoUpdate
import com.example.videodownloader.YtDlpGate
import com.example.videodownloader.browser.BrowserBookmarksActivity
import com.example.videodownloader.browser.BrowserHistoryActivity
import com.example.videodownloader.browser.BrowserStore
import com.example.videodownloader.browser.BrowserUrl
import com.example.videodownloader.browser.SearchEngine
import com.example.videodownloader.converter.ConverterActivity
import com.example.videodownloader.files.FileManagerActivity
import com.example.videodownloader.files.StorageAnalyzerActivity
import com.example.videodownloader.player.PlayerActivity
import com.example.videodownloader.ui.BaseActivity
import com.example.videodownloader.ui.Hb
import com.example.videodownloader.util.Fmt
import com.example.videodownloader.util.Launcher
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

class SettingsActivity : BaseActivity() {

    private lateinit var col: LinearLayout
    private var folderTarget = TARGET_VIDEO

    private val folderPicker = registerForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
        if (uri == null) return@registerForActivityResult
        try {
            contentResolver.takePersistableUriPermission(
                uri,
                Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
            )
        } catch (_: Exception) {
            Hb.toast(this, "Android did not allow this folder")
            return@registerForActivityResult
        }
        when (folderTarget) {
            TARGET_VIDEO -> Prefs.setVideoTree(this, uri.toString())
            TARGET_AUDIO -> Prefs.setAudioTree(this, uri.toString())
            TARGET_BROWSER -> Prefs.setBrowserDownloadTree(this, uri.toString())
        }
        Hb.toast(this, "Folder saved")
        recreate()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val p = Hb.palette(this)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(p.bg)
        }
        root.addView(Hb.topBar(this, "Settings", "HB Super App 1.0", onBack = { finish() }))

        val scroll = ScrollView(this).apply { setBackgroundColor(p.bg); isFillViewport = true }
        col = Hb.column(this, 18)
        scroll.addView(col)
        root.addView(scroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        setContentView(root)

        buildAppearance()
        buildDownloads()
        buildBrowser()
        buildPlayer()
        buildStorage()
        buildNotificationsAndPrivacy()
        buildAbout()
    }

    // --------------------------------------------------------------- sections

    private fun section(title: String): LinearLayout {
        col.addView(Hb.section(this, title))
        val card = Hb.card(this, 6)
        col.addView(card)
        col.addView(Hb.spacer(this, 2))
        return card
    }

    private fun buildAppearance() {
        val card = section("Appearance")
        card.addView(Hb.row(this, R.drawable.ic_settings, "Theme", themeLabel(), trailing = "Change") { themeDialog() })
        card.addView(Hb.divider(this, 42))
        card.addView(Hb.row(this, R.drawable.ic_home, "Home shortcuts", "${Prefs.homeActions(this).size} shown on the dashboard") {
            Hb.alert(this, "Home shortcuts", "Change shortcuts directly on the Home dashboard: tap Customize above Quick actions.")
        })
    }

    private fun buildDownloads() {
        val card = section("Download preferences")
        card.addView(Hb.row(this, R.drawable.ic_folder, "Video folder", SaveStore.label(Prefs.videoTree(this), "DCIM/HB AIO")) {
            folderTarget = TARGET_VIDEO
            folderPicker.launch(null)
        })
        card.addView(Hb.divider(this, 42))
        card.addView(Hb.row(this, R.drawable.ic_music, "Audio folder", SaveStore.label(Prefs.audioTree(this), "Music/HB AIO")) {
            folderTarget = TARGET_AUDIO
            folderPicker.launch(null)
        })
        card.addView(Hb.divider(this, 42))
        card.addView(Hb.row(this, R.drawable.ic_speed, "Default quality", Quality.label(Prefs.quality(this)), trailing = "Change") { qualityDialog() })
        card.addView(Hb.divider(this, 42))
        card.addView(Hb.toggleRow(this, "Wi-Fi only downloads", "Queue mobile downloads until Wi-Fi is available", Prefs.wifiOnly(this)) {
            Prefs.setWifiOnly(this, it)
        })
        card.addView(Hb.divider(this, 42))
        card.addView(Hb.toggleRow(this, "YouTube folder", "Put YouTube videos in their own folder", Prefs.youtubeFolder(this)) {
            Prefs.setYoutubeFolder(this, it)
        })
        card.addView(Hb.divider(this, 42))
        card.addView(Hb.toggleRow(this, "Audio by default", "The Download button saves MP3 instead of video", Prefs.audioDefault(this)) {
            Prefs.setAudioDefault(this, it)
        })
        card.addView(Hb.divider(this, 42))
        card.addView(Hb.toggleRow(this, "Offer to download copied links", "When you copy a video link, ask to download it as soon as the app opens", Prefs.clipboardOffer(this)) {
            Prefs.setClipboardOffer(this, it)
        })
        buildSiteLogins()
    }

    private var igLoggedInShown: Boolean? = null

    private fun buildSiteLogins() {
        val card = section("Instagram login")
        val loggedIn = SiteLogin.isLoggedIn(Site.INSTAGRAM)
        igLoggedInShown = loggedIn
        card.addView(Hb.row(
            this, R.drawable.ic_browser, "Instagram login",
            if (loggedIn) "Logged in. Shared Instagram links download with this login."
            else "Not logged in. Log in once so Instagram does not block downloads.",
            trailing = if (loggedIn) "Log out" else "Log in"
        ) {
            if (loggedIn) {
                Hb.confirm(this, "Log out of Instagram?", "Downloads of Instagram links will go back to anonymous mode.", "Log out", destructive = true) {
                    SiteLogin.logOut(Site.INSTAGRAM)
                    recreate()
                }
            } else {
                Launcher.openUrl(this, "https://www.instagram.com/accounts/login/")
            }
        })
        card.addView(Hb.divider(this, 42))
        card.addView(Hb.toggleRow(this, "Use saved login for downloads", "Shared links use the login you made in HB Browser; the login never leaves your phone", Prefs.autoSiteLogin(this)) {
            Prefs.setAutoSiteLogin(this, it)
        })
    }

    override fun onResume() {
        super.onResume()
        val shown = igLoggedInShown
        if (shown != null && shown != SiteLogin.isLoggedIn(Site.INSTAGRAM)) recreate()
    }

    private fun buildBrowser() {
        val card = section("Browser preferences")
        card.addView(Hb.row(this, R.drawable.ic_search, "Search engine", SearchEngine.from(Prefs.searchEngine(this)).label, trailing = "Change") {
            engineDialog()
        })
        card.addView(Hb.divider(this, 42))
        card.addView(Hb.row(this, R.drawable.ic_home, "Home page", BrowserUrl.display(Prefs.browserHome(this)), trailing = "Change") {
            Hb.input(this, "Browser home page", "https://…", Prefs.browserHome(this)) { value ->
                val url = BrowserUrl.normalize(value, Prefs.searchEngine(this))
                if (BrowserUrl.isHttp(url)) {
                    Prefs.setBrowserHome(this, url)
                    recreate()
                } else {
                    Hb.toast(this, "Enter a web address")
                }
            }
        })
        card.addView(Hb.divider(this, 42))
        card.addView(Hb.row(this, R.drawable.ic_text, "Text size", "${Prefs.browserTextZoom(this)}%", trailing = "Change") {
            textSizeDialog()
        })
        card.addView(Hb.divider(this, 42))
        card.addView(Hb.row(this, R.drawable.ic_folder, "Download folder", browserFolderLabel(), trailing = "Choose") {
            folderTarget = TARGET_BROWSER
            folderPicker.launch(null)
        })
        card.addView(Hb.divider(this, 42))
        card.addView(Hb.toggleRow(this, "Block ads and trackers", "Blocks a small, transparent list of known ad hosts", Prefs.adBlock(this)) {
            Prefs.setAdBlock(this, it)
        })
        card.addView(Hb.divider(this, 42))
        card.addView(Hb.toggleRow(this, "Restore tabs", "Reopen normal tabs after a restart", Prefs.restoreTabs(this)) {
            Prefs.setRestoreTabs(this, it)
        })
        card.addView(Hb.divider(this, 42))
        card.addView(Hb.toggleRow(this, "Clear private data on exit", "Clear cookies, cache and storage when leaving the browser", Prefs.clearPrivateOnExit(this)) {
            Prefs.setClearPrivateOnExit(this, it)
        })
        card.addView(Hb.divider(this, 42))
        card.addView(Hb.toggleRow(this, "Use browser login for downloads", "Send this website's login cookies so private or members-only videos can download", Prefs.browserLoginDownloads(this)) {
            Prefs.setBrowserLoginDownloads(this, it)
        })
        card.addView(Hb.divider(this, 42))
        card.addView(Hb.row(this, R.drawable.ic_history, "Browsing history", "${BrowserStore.history(this).size} entries") {
            startActivity(Intent(this, BrowserHistoryActivity::class.java))
        })
        card.addView(Hb.divider(this, 42))
        card.addView(Hb.row(this, R.drawable.ic_star, "Bookmarks", "${BrowserStore.bookmarks(this).size} saved") {
            startActivity(Intent(this, BrowserBookmarksActivity::class.java))
        })
        card.addView(Hb.divider(this, 42))
        card.addView(Hb.row(this, R.drawable.ic_delete, "Clear cookies & cache", "Remove browser session data") {
            Hb.confirm(this, "Clear browser data?", "Cookies, cache, local storage and form data will be removed.", "Clear", destructive = true) {
                clearBrowserData()
            }
        })
        card.addView(Hb.divider(this, 42))
        card.addView(Hb.row(this, R.drawable.ic_lock, "Private browsing", "How far WebView isolation can go") {
            Hb.alert(this, "Private browsing",
                "Private tabs are never saved or restored and do not write history. Android WebView shares one " +
                    "cookie jar between all tabs, so leaving the browser clears cookies, storage and cache for the " +
                    "strongest isolation WebView offers. This can sign you out of sites in normal tabs.")
        })
    }

    private fun buildPlayer() {
        val card = section("Player")
        card.addView(Hb.toggleRow(this, "Resume playback", "Remember where you stopped", Prefs.playerResume(this)) {
            Prefs.setPlayerResume(this, it)
        })
        card.addView(Hb.divider(this, 42))
        card.addView(Hb.toggleRow(this, "Background audio", "Keep playing when you leave the player", Prefs.playerBackground(this)) {
            Prefs.setPlayerBackground(this, it)
        })
        card.addView(Hb.divider(this, 42))
        card.addView(Hb.row(this, R.drawable.ic_speed, "Playback speed", "${Prefs.playerSpeed(this)}x", trailing = "Change") {
            speedDialog()
        })
        card.addView(Hb.divider(this, 42))
        card.addView(Hb.row(this, R.drawable.ic_play, "Open media player", "Play local videos and music") {
            startActivity(Intent(this, PlayerActivity::class.java))
        })
    }

    private fun buildStorage() {
        val card = section("Storage")
        card.addView(Hb.row(this, R.drawable.ic_storage, "Cache", cacheLabel(), trailing = "Clear") {
            Hb.confirm(this, "Clear cache?", "Temporary files will be removed. Downloads and media are not touched.", "Clear", destructive = true) {
                val size = clearCache()
                Hb.toast(this, "Cleared ${Fmt.bytes(size)}")
                recreate()
            }
        })
        card.addView(Hb.divider(this, 42))
        card.addView(Hb.row(this, R.drawable.ic_storage, "Storage Analyzer", "See what is using your space") {
            startActivity(Intent(this, StorageAnalyzerActivity::class.java))
        })
        card.addView(Hb.divider(this, 42))
        card.addView(Hb.row(this, R.drawable.ic_folder, "File Manager", "Browse, zip and organize files") {
            startActivity(Intent(this, FileManagerActivity::class.java))
        })
        card.addView(Hb.divider(this, 42))
        card.addView(Hb.row(this, R.drawable.ic_convert, "Converter Studio", "MP3, trim, compress and PDF") {
            startActivity(Intent(this, ConverterActivity::class.java))
        })
    }

    private fun buildNotificationsAndPrivacy() {
        val card = section("Notifications & privacy")
        card.addView(Hb.row(this, R.drawable.ic_more, "Notification settings", "Download and update notifications") {
            Launcher.notificationSettings(this)
        })
        card.addView(Hb.divider(this, 42))
        card.addView(Hb.row(this, R.drawable.ic_lock, "Permissions explained", "Why the app asks for each permission") {
            showPermissions()
        })
        card.addView(Hb.divider(this, 42))
        card.addView(Hb.row(this, R.drawable.ic_text, "Privacy", "What HB keeps on your phone") {
            Hb.alert(this, "Privacy",
                "HB Super App keeps downloads, history, bookmarks, playlists and settings on this device. " +
                    "Browsing history is never uploaded. The only network requests are the pages you open, the " +
                    "downloads you start, the update check and optional yt-dlp updates.")
        })
    }

    private fun buildAbout() {
        val card = section("About & updates")
        val info = try {
            packageManager.getPackageInfo(packageName, 0)
        } catch (_: Exception) {
            null
        }
        val name = info?.versionName ?: "1.0"
        val code = if (info != null) {
            if (android.os.Build.VERSION.SDK_INT >= 28) info.longVersionCode else info.versionCode.toLong()
        } else 26L
        card.addView(Hb.row(this, R.drawable.ic_play, "HB Super App", "Version $name ($code) • HB Software").apply {
            isClickable = false
        })
        card.addView(Hb.divider(this, 42))
        card.addView(Hb.row(this, R.drawable.ic_convert, "Check for updates", "Uses GitHub Releases and update-v1.json", trailing = "Now") {
            Updater.check(this, true) { msg -> if (msg.isNotBlank()) Hb.toast(this, msg) }
        })
        card.addView(Hb.divider(this, 42))
        card.addView(Hb.row(this, R.drawable.ic_download, "Update yt-dlp engine", "Fixes download errors on changed sites") {
            updateYtdlp()
        })
        card.addView(Hb.divider(this, 42))
        card.addView(Hb.row(this, R.drawable.ic_more, "Update source", Updater.UPDATE_JSON_URL, trailing = "Info") {
            Hb.alert(this, "Update source",
                "Official update metadata:\n\n${Updater.UPDATE_JSON_URL}\n\nWhen publishing a new release, update versionCode, " +
                    "versionName, apkUrl, minVersionCode, notes and sha256 in update-v1.json. Never change the signing key.")
        })
        card.addView(Hb.divider(this, 42))
        card.addView(Hb.row(this, R.drawable.ic_lock, "Firebase & Admin Panel", "Optional, not enabled in 1.0", trailing = "Info") {
            Hb.alert(this, "Firebase — optional",
                "This build works fully without Firebase. No Firebase SDK, service account or secret is included. " +
                    "The Admin Panel is planned for a future version. When Firebase is added later, keep authentication, " +
                    "Firestore, FCM, Remote Config and crash reporting optional, and never upload browsing history, " +
                    "private URLs or personal files.")
        })
        card.addView(Hb.divider(this, 42))
        card.addView(Hb.row(this, R.drawable.ic_settings, "App settings", "Android permission and notification controls") {
            Launcher.appSettings(this)
        })
        col.addView(Hb.spacer(this, 18))
        col.addView(Hb.text(this, "HB Software\nCredit by Hakim Zaib", 11f, Hb.palette(this).muted).apply {
            gravity = Gravity.CENTER
        })
    }

    // --------------------------------------------------------------- labels

    private fun themeLabel(): String = when (Prefs.theme(this)) {
        "light" -> "Light"
        "system" -> "System"
        else -> "Dark"
    }

    private fun browserFolderLabel(): String {
        val tree = Prefs.browserDownloadTree(this) ?: return "App Downloads folder"
        return SaveStore.label(tree, "App Downloads folder")
    }

    private fun cacheLabel(): String = Fmt.bytes(cacheSize())

    private fun refreshLabels() {
        recreate()
    }

    // --------------------------------------------------------------- dialogs

    private fun themeDialog() {
        val labels = arrayOf("System", "Light", "Dark")
        val values = arrayOf("system", "light", "dark")
        AlertDialog.Builder(this, R.style.HbDialog)
            .setTitle("Theme")
            .setSingleChoiceItems(labels, values.indexOf(Prefs.theme(this))) { d, which ->
                Prefs.setTheme(this, values[which])
                when (values[which]) {
                    "light" -> AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO)
                    "dark" -> AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES)
                    else -> AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_FOLLOW_SYSTEM)
                }
                d.dismiss()
            }
            .show()
    }

    private fun qualityDialog() {
        AlertDialog.Builder(this, R.style.HbDialog)
            .setTitle("Default video quality")
            .setItems(Quality.labels.toTypedArray()) { _, which ->
                Prefs.setQuality(this, Quality.heights[which])
                recreate()
            }
            .show()
    }

    private fun engineDialog() {
        val engines = SearchEngine.entries
        AlertDialog.Builder(this, R.style.HbDialog)
            .setTitle("Search engine")
            .setItems(engines.map { it.label }.toTypedArray()) { _, which ->
                Prefs.setSearchEngine(this, engines[which].id)
                recreate()
            }
            .show()
    }

    private fun textSizeDialog() {
        val values = intArrayOf(80, 100, 120, 150, 180)
        val labels = arrayOf("Small (80%)", "Normal (100%)", "Large (120%)", "Extra large (150%)", "Huge (180%)")
        AlertDialog.Builder(this, R.style.HbDialog)
            .setTitle("Browser text size")
            .setItems(labels) { _, which ->
                Prefs.setBrowserTextZoom(this, values[which])
                recreate()
            }
            .show()
    }

    private fun speedDialog() {
        val values = floatArrayOf(0.5f, 0.75f, 1f, 1.25f, 1.5f, 2f)
        val labels = values.map { "${it}x" }.toTypedArray()
        AlertDialog.Builder(this, R.style.HbDialog)
            .setTitle("Playback speed")
            .setItems(labels) { _, which ->
                Prefs.setPlayerSpeed(this, values[which])
                recreate()
            }
            .show()
    }

    private fun showPermissions() {
        Hb.alert(this, "Permissions",
            "• Internet & network state — downloads and browsing.\n" +
                "• Foreground service (data sync) — keeps downloads running in the background.\n" +
                "• Notifications — download, playback and update status.\n" +
                "• Camera — only for the QR scanner. Websites are blocked from using the camera and microphone.\n" +
                "• Read media (images/video/audio) — the player, file manager and library.\n" +
                "• All files access — optional, only needed for the WhatsApp status saver on Android 11+. Status saver is the only feature that uses it; you can deny it and use every other feature.\n" +
                "• Install unknown apps — used only for installing an APK you downloaded from the official update channel.\n" +
                "• Write settings — only when you tap Ringtone Maker to set a ringtone.")
    }

    private fun updateYtdlp() {
        Hb.toast(this, "Updating yt-dlp…")
        lifecycleScope.launch {
            val ok = withContext(Dispatchers.IO) {
                try {
                    YtDlpGate.updateWhenIdle {
                        com.yausername.youtubedl_android.YoutubeDL.getInstance().init(applicationContext)
                        com.yausername.youtubedl_android.YoutubeDL.getInstance()
                            .updateYoutubeDL(applicationContext, com.yausername.youtubedl_android.YoutubeDL.UpdateChannel.NIGHTLY)
                    }
                } catch (_: Exception) {
                    false
                }
            }
            if (ok) {
                Prefs.setLastYtdlpUpdate(this@SettingsActivity, System.currentTimeMillis())
                Hb.toast(this@SettingsActivity, "yt-dlp is up to date")
            } else {
                Hb.toast(this@SettingsActivity, "Could not update yt-dlp. Check your connection or try after downloads finish.")
            }
        }
    }

    private fun clearBrowserData() {
        try {
            android.webkit.CookieManager.getInstance().removeAllCookies(null)
            android.webkit.CookieManager.getInstance().flush()
        } catch (_: Exception) {
        }
        try {
            android.webkit.WebStorage.getInstance().deleteAllData()
        } catch (_: Exception) {
        }
        try {
            android.webkit.WebViewDatabase.getInstance(this).clearFormData()
        } catch (_: Exception) {
        }
        Hb.toast(this, "Browser data cleared")
    }

    // --------------------------------------------------------------- storage helpers

    private fun cacheSize(): Long {
        fun size(dir: File?): Long {
            if (dir == null || !dir.exists()) return 0L
            return try {
                dir.walkBottomUp().filter { it.isFile }.sumOf { it.length() }
            } catch (_: Exception) {
                0L
            }
        }
        return size(cacheDir) + size(externalCacheDir)
    }

    private fun clearCache(): Long {
        val before = cacheSize()
        fun wipe(dir: File?) {
            if (dir == null || !dir.exists()) return
            dir.listFiles()?.forEach {
                try {
                    if (it.isDirectory) it.deleteRecursively() else it.delete()
                } catch (_: Exception) {
                }
            }
        }
        wipe(cacheDir)
        wipe(externalCacheDir)
        return before
    }

    private companion object {
        const val TARGET_VIDEO = 1
        const val TARGET_AUDIO = 2
        const val TARGET_BROWSER = 3
    }
}
