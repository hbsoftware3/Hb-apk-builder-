package com.example.videodownloader.files

import android.Manifest
import android.app.Activity
import android.content.ContentUris
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.DocumentsContract
import android.provider.MediaStore
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.CheckBox
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import androidx.activity.result.IntentSenderRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import androidx.documentfile.provider.DocumentFile
import androidx.lifecycle.lifecycleScope
import com.example.videodownloader.R
import com.example.videodownloader.ui.BaseActivity
import com.example.videodownloader.ui.Hb
import com.example.videodownloader.util.Fmt
import com.example.videodownloader.util.Launcher
import com.example.videodownloader.util.MediaIndex
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.BufferedOutputStream
import java.io.File
import java.io.FileOutputStream
import java.io.OutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

/**
 * File manager that works in two honest ways:
 *  - "Categories" read what Android's media index already knows (videos, music, photos, documents, APKs).
 *  - "Folders" use the Storage Access Framework: the user picks a folder once, then the app can really
 *    browse, rename, copy, move, create folders and delete inside it.
 * Nothing outside the picked folder is touched, and deletions always ask first.
 */
class FileManagerActivity : BaseActivity() {

    companion object {
        const val EXTRA_CATEGORY = "category"
    }

    private data class Node(
        val uri: Uri,
        val name: String,
        val mime: String,
        val size: Long,
        val modified: Long,
        val isDir: Boolean,
        val doc: DocumentFile? = null
    )

    private lateinit var body: LinearLayout
    private lateinit var pathText: android.widget.TextView
    private lateinit var selectionBar: LinearLayout
    private lateinit var selectionCount: android.widget.TextView

    private var category: String? = null
    private var tree: Uri? = null
    private val path = ArrayList<String>()
    private var currentDir: DocumentFile? = null
    private var nodes: List<Node> = emptyList()
    private val selected = LinkedHashSet<String>()
    private var selectionMode = false
    private var sortMode = 0
    private var search = ""
    private var searchRow: LinearLayout? = null
    private var loading = false

    private val prefs by lazy { getSharedPreferences("hb_files", MODE_PRIVATE) }
    private val pendingDelete = ArrayList<Uri>()
    private var pendingOp = ""

    private val openFolder = registerForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
        uri ?: return@registerForActivityResult
        try {
            contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION)
        } catch (_: Exception) {
        }
        prefs.edit().putString("tree", uri.toString()).apply()
        category = null
        path.clear()
        tree = uri
        load()
    }

    private val destination = registerForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
        uri ?: return@registerForActivityResult
        val targets = selectedNodes()
        if (targets.isEmpty()) return@registerForActivityResult
        val move = pendingOp == "move"
        lifecycleScope.launch {
            val result = withContext(Dispatchers.IO) { copyTo(uri, targets, move) }
            Hb.toast(this@FileManagerActivity, result)
            clearSelection()
            load()
        }
    }

    private val pickZip = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        uri ?: return@registerForActivityResult
        lifecycleScope.launch {
            val msg = withContext(Dispatchers.IO) { extract(uri) }
            Hb.toast(this@FileManagerActivity, msg)
            load()
        }
    }

    private val deleteRequest = registerForActivityResult(ActivityResultContracts.StartIntentSenderForResult()) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            lifecycleScope.launch {
                val done = withContext(Dispatchers.IO) {
                    pendingDelete.count { u -> runCatching { contentResolver.delete(u, null, null) > 0 }.getOrDefault(false) }
                }
                Hb.toast(this@FileManagerActivity, "$done item(s) deleted")
                clearSelection()
                load()
            }
        }
        pendingDelete.clear()
    }

    private val mediaPermissions = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        load()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        category = intent?.getStringExtra(EXTRA_CATEGORY)
        tree = prefs.getString("tree", null)?.let { runCatching { Uri.parse(it) }.getOrNull() }
        if (category != null) path.clear()

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Hb.palette(this@FileManagerActivity).bg)
        }
        root.addView(buildTopBar())
        selectionBar = buildSelectionBar()
        root.addView(selectionBar)
        pathText = Hb.text(this, "", 11f, Hb.palette(this).muted).apply {
            setPadding(Hb.dp(this@FileManagerActivity, 20), Hb.dp(this@FileManagerActivity, 2),
                Hb.dp(this@FileManagerActivity, 20), Hb.dp(this@FileManagerActivity, 4))
        }
        root.addView(pathText)
        val scroll = ScrollView(this).apply {
            isFillViewport = true
            overScrollMode = View.OVER_SCROLL_NEVER
        }
        body = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(Hb.dp(this@FileManagerActivity, 14), Hb.dp(this@FileManagerActivity, 4),
                Hb.dp(this@FileManagerActivity, 14), Hb.dp(this@FileManagerActivity, 30))
        }
        scroll.addView(body)
        root.addView(scroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        setContentView(root)
        updateSelectionBar()
        load()
    }

    private fun buildTopBar(): LinearLayout = Hb.topBar(
        this,
        when (category) {
            "videos" -> "Videos"
            "music" -> "Music"
            "images" -> "Photos"
            "documents" -> "Documents"
            "downloads" -> "Downloads"
            "apk" -> "APK files"
            "other" -> "Other files"
            else -> "File Manager"
        },
        "Browse, organize and zip files",
        onBack = {
            when {
                selectionMode -> clearSelection()
                path.isNotEmpty() -> {
                    path.removeAt(path.lastIndex)
                    load()
                }
                category != null -> {
                    category = null
                    load()
                }
                else -> finish()
            }
        },
        actions = listOf(
            R.drawable.ic_search to { toggleSearch() },
            R.drawable.ic_sort to { showSort() },
            R.drawable.ic_more to { showMore() }
        )
    )

    private fun buildSelectionBar(): LinearLayout {
        val p = Hb.palette(this)
        selectionCount = Hb.text(this, "", 13f, p.text, bold = true)
        return LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(Hb.dp(this@FileManagerActivity, 16), Hb.dp(this@FileManagerActivity, 8),
                Hb.dp(this@FileManagerActivity, 8), Hb.dp(this@FileManagerActivity, 8))
            setBackgroundColor(p.surface)
            visibility = View.GONE
            addView(selectionCount, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            listOf(
                R.drawable.ic_share to { shareSelected() },
                R.drawable.ic_copy to { startCopyOrMove("copy") },
                R.drawable.ic_folder to { startCopyOrMove("move") },
                R.drawable.ic_zip to { zipSelected() },
                R.drawable.ic_delete to { deleteSelected() }
            ).forEach { (icon, action) ->
                addView(Hb.iconButton(this@FileManagerActivity, icon, p.text, 38, action).apply {
                    (layoutParams as LinearLayout.LayoutParams).marginStart = Hb.dp(this@FileManagerActivity, 4)
                })
            }
            addView(Hb.iconButton(this@FileManagerActivity, R.drawable.ic_close, p.muted, 38) { clearSelection() })
        }
    }

    private fun updateSelectionBar() {
        selectionBar.visibility = if (selectionMode) View.VISIBLE else View.GONE
        selectionCount.text = "${selected.size} selected"
    }

    private fun toggleSearch() {
        val existing = searchRow
        if (existing != null) {
            body.removeView(existing)
            searchRow = null
            search = ""
            render()
            return
        }
        val p = Hb.palette(this)
        val input = EditText(this).apply {
            hint = "Filter this list"
            setHintTextColor(p.muted)
            setTextColor(p.text)
            background = Hb.round(this@FileManagerActivity, 14, p.surfaceAlt, p.border, 1)
            setPadding(Hb.dp(this@FileManagerActivity, 14), Hb.dp(this@FileManagerActivity, 8),
                Hb.dp(this@FileManagerActivity, 14), Hb.dp(this@FileManagerActivity, 8))
            setSingleLine(true)
            setText(search)
            addTextChangedListener(object : android.text.TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
                override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {
                    search = s?.toString().orEmpty()
                    render()
                }
                override fun afterTextChanged(s: android.text.Editable?) {}
            })
        }
        searchRow = LinearLayout(this).apply {
            setPadding(Hb.dp(this@FileManagerActivity, 14), Hb.dp(this@FileManagerActivity, 6),
                Hb.dp(this@FileManagerActivity, 14), Hb.dp(this@FileManagerActivity, 6))
            addView(input)
        }
        body.addView(searchRow, 0)
        input.requestFocus()
    }

    // ---------------------------------------------------------------- loading

    private fun load() {
        if (loading) return
        loading = true
        lifecycleScope.launch {
            val result = withContext(Dispatchers.IO) { readCurrent() }
            currentDir = result.second
            nodes = result.first
            loading = false
            updateSelectionBar()
            render()
        }
    }

    /** Returns the sorted nodes and the SAF directory they came from (null in category mode). */
    private fun readCurrent(): Pair<List<Node>, DocumentFile?> {
        val dir = if (category == null && tree != null) {
            var cur = DocumentFile.fromTreeUri(this, tree!!)
            for (name in path) cur = cur?.findFile(name)?.takeIf { it.isDirectory }
            cur
        } else null

        val list = if (category != null) categoryNodes(category!!)
        else if (tree != null) listOfNotNull(dir).flatMap { d ->
            try {
                d.listFiles().map { f ->
                    Node(
                        f.uri, f.name ?: "file",
                        f.type ?: guessMime(f.name ?: "file"),
                        f.length(), f.lastModified(), f.isDirectory, f
                    )
                }
            } catch (_: Exception) {
                emptyList()
            }
        } else emptyList()
        return sortNodes(list) to dir
    }

    private fun categoryNodes(id: String): List<Node> {
        return when (id) {
            "videos" -> MediaIndex.videos(this, 500).map {
                Node(it.uri, it.name, it.mime, it.size, it.dateMs, false)
            }
            "music" -> MediaIndex.audio(this, 500).map {
                Node(it.uri, it.name, it.mime, it.size, it.dateMs, false)
            }
            "images" -> MediaIndex.images(this, 500).map {
                Node(it.uri, it.name, it.mime, it.size, it.dateMs, false)
            }
            else -> mediaStoreFiles(id)
        }
    }

    private fun mediaStoreFiles(id: String): List<Node> {
        val files = MediaStore.Files.getContentUri(MediaStore.VOLUME_EXTERNAL)
        val selection: String
        val args: Array<String>?
        when (id) {
            "downloads" -> {
                selection = "${MediaStore.MediaColumns.RELATIVE_PATH} LIKE ?"
                args = arrayOf("Download%")
            }
            "apk" -> {
                selection = "${MediaStore.MediaColumns.MIME_TYPE} = ?"
                args = arrayOf("application/vnd.android.package-archive")
            }
            "documents" -> {
                selection = "(${MediaStore.MediaColumns.MIME_TYPE} = ? OR ${MediaStore.MediaColumns.MIME_TYPE} LIKE ? OR " +
                    "${MediaStore.MediaColumns.MIME_TYPE} = ? OR ${MediaStore.MediaColumns.MIME_TYPE} = ? OR " +
                    "${MediaStore.MediaColumns.MIME_TYPE} = ? OR ${MediaStore.MediaColumns.MIME_TYPE} = ?)"
                args = arrayOf(
                    "application/pdf", "text/%", "application/msword",
                    "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
                    "application/vnd.ms-excel",
                    "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
                )
            }
            else -> {
                selection = "${MediaStore.MediaColumns.MIME_TYPE} NOT LIKE ? AND " +
                    "${MediaStore.MediaColumns.MIME_TYPE} NOT LIKE ? AND " +
                    "${MediaStore.MediaColumns.MIME_TYPE} NOT LIKE ? AND " +
                    "${MediaStore.MediaColumns.MIME_TYPE} != ?"
                args = arrayOf("video/%", "audio/%", "image/%", "application/vnd.android.package-archive")
            }
        }
        val out = ArrayList<Node>()
        try {
            contentResolver.query(
                files,
                arrayOf(
                    MediaStore.MediaColumns._ID, MediaStore.MediaColumns.DISPLAY_NAME,
                    MediaStore.MediaColumns.MIME_TYPE, MediaStore.MediaColumns.SIZE,
                    MediaStore.MediaColumns.DATE_MODIFIED
                ), selection, args, "${MediaStore.MediaColumns.DATE_MODIFIED} DESC"
            )?.use { cur ->
                while (cur.moveToNext() && out.size < 1000) {
                    val idValue = cur.getLong(0)
                    val name = cur.getString(1) ?: "file"
                    out.add(
                        Node(
                            ContentUris.withAppendedId(files, idValue), name,
                            cur.getString(2) ?: guessMime(name), cur.getLong(3),
                            cur.getLong(4) * 1000L, false
                        )
                    )
                }
            }
        } catch (_: Exception) {
        }
        return out
    }

    private fun sortNodes(list: List<Node>): List<Node> {
        val base = list.sortedWith(compareByDescending<Node> { it.isDir })
        return when (sortMode) {
            0 -> base.sortedWith(compareBy({ !it.isDir }, { it.name.lowercase() }))
            1 -> base.sortedWith(compareByDescending { it.modified })
            2 -> base.sortedWith(compareBy { it.modified })
            3 -> base.sortedWith(compareByDescending { it.size })
            else -> base.sortedWith(compareBy { it.size })
        }
    }

    // ----------------------------------------------------------------- render

    private fun render() {
        body.removeAllViews()
        if (searchRow != null) body.addView(searchRow, 0)
        val p = Hb.palette(this)

        if (category == null && tree == null) {
            renderHome()
            return
        }

        pathText.text = when {
            category != null -> "Android media library"
            path.isEmpty() -> "Folder: ${treeLabel()}"
            else -> "${treeLabel()}/${path.joinToString("/")}"
        }

        val shown = if (search.isBlank()) nodes
        else nodes.filter { it.name.contains(search, ignoreCase = true) }

        if (shown.isEmpty()) {
            body.addView(Hb.empty(this, R.drawable.ic_folder, "Nothing here", "Files you add or pick will appear in this folder"))
        }

        shown.forEachIndexed { index, node ->
            body.addView(nodeRow(node))
            if (index != shown.lastIndex) {
                body.addView(View(this).apply {
                    setBackgroundColor(p.border)
                    layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, Hb.dp(this@FileManagerActivity, 1)).apply {
                        marginStart = Hb.dp(this@FileManagerActivity, 54)
                    }
                })
            }
        }
    }

    private fun renderHome() {
        val p = Hb.palette(this)

        val hero = Hb.card(this, 18)
        hero.addView(Hb.text(this, "Organize your files", 18f, p.text, bold = true))
        hero.addView(Hb.text(this, "Pick a folder to browse and edit it. Nothing is scanned in the background.", 11.5f, p.muted).apply {
            setPadding(0, Hb.dp(this@FileManagerActivity, 4), 0, Hb.dp(this@FileManagerActivity, 10))
        })
        hero.addView(Hb.button(this, "Choose a folder", true, R.drawable.ic_folder) { openFolder.launch(null) })
        val saved = prefs.getString("tree", null)
        if (saved != null) {
            hero.addView(Hb.button(this, "Open my folder", false, R.drawable.ic_folder) {
                tree = runCatching { Uri.parse(saved) }.getOrNull()
                path.clear()
                load()
            }.apply {
                (layoutParams as LinearLayout.LayoutParams).topMargin = Hb.dp(this@FileManagerActivity, 8)
            })
        }
        body.addView(hero)

        if (Build.VERSION.SDK_INT >= 30 && !Environment.isExternalStorageManager()) {
            val card = Hb.card(this, 14).apply {
                (layoutParams as LinearLayout.LayoutParams).topMargin = Hb.dp(this@FileManagerActivity, 12)
            }
            card.addView(Hb.text(this, "See all files", 14.5f, p.text, medium = true))
            card.addView(Hb.text(this, "Allow all-files access to list documents and APKs from other apps. Without it, category lists may be incomplete.", 11.5f, p.muted).apply {
                setPadding(0, Hb.dp(this@FileManagerActivity, 3), 0, Hb.dp(this@FileManagerActivity, 8))
            })
            card.addView(Hb.button(this, "Open file access settings", false, R.drawable.ic_settings) {
                try {
                    startActivity(Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, Uri.parse("package:$packageName")))
                } catch (_: Exception) {
                    startActivity(Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION))
                }
            })
            body.addView(card)
        }

        if (!hasMediaPermission()) {
            val card = Hb.card(this, 14).apply {
                (layoutParams as LinearLayout.LayoutParams).topMargin = Hb.dp(this@FileManagerActivity, 12)
            }
            card.addView(Hb.text(this, "Media access", 14.5f, p.text, medium = true))
            card.addView(Hb.text(this, "Allow the app to show your videos, music and photos in the categories below.", 11.5f, p.muted).apply {
                setPadding(0, Hb.dp(this@FileManagerActivity, 3), 0, Hb.dp(this@FileManagerActivity, 8))
            })
            card.addView(Hb.button(this, "Allow media access", false, R.drawable.ic_image) { askMediaPermission() })
            body.addView(card)
        }

        body.addView(Hb.section(this, "Categories"))
        val grid = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        listOf(
            Triple("videos", "Videos", R.drawable.ic_play),
            Triple("music", "Music", R.drawable.ic_music),
            Triple("images", "Photos", R.drawable.ic_image),
            Triple("documents", "Documents", R.drawable.ic_pdf),
            Triple("downloads", "Downloads", R.drawable.ic_download),
            Triple("apk", "APK files", R.drawable.ic_file),
            Triple("other", "Other files", R.drawable.ic_folder)
        ).forEach { (id, title, icon) ->
            grid.addView(Hb.row(this, icon, title) {
                category = id
                load()
            })
        }
        body.addView(Hb.card(this, 6).apply { addView(grid) })

        body.addView(Hb.section(this, "Tools"))
        body.addView(Hb.row(this, R.drawable.ic_storage, "Storage analyzer", "What is using your space") {
            startActivity(Intent(this, StorageAnalyzerActivity::class.java))
        })
        body.addView(Hb.row(this, R.drawable.ic_search, "File search", "Search by name") {
            startActivity(Intent(this, FileSearchActivity::class.java))
        })

        if (Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS).exists()) {
            body.addView(Hb.section(this, "Downloads"))
            body.addView(Hb.text(this, "Public Downloads folder: use \"Choose a folder\" and pick Download to manage it.", 11.5f, p.muted).apply {
                setPadding(Hb.dp(this@FileManagerActivity, 4), 0, Hb.dp(this@FileManagerActivity, 4), 0)
            })
        }
    }

    private fun nodeRow(node: Node): LinearLayout {
        val p = Hb.palette(this)
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(Hb.dp(this@FileManagerActivity, 6), Hb.dp(this@FileManagerActivity, 9),
                Hb.dp(this@FileManagerActivity, 6), Hb.dp(this@FileManagerActivity, 9))
        }
        row.addView(Hb.iconCircle(this, iconFor(node), p.blue, p.blueSoft, 40))
        val info = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(Hb.dp(this@FileManagerActivity, 12), 0, Hb.dp(this@FileManagerActivity, 8), 0)
        }
        info.addView(Hb.text(this, node.name, 14f, p.text, medium = true).apply {
            maxLines = 2
            ellipsize = android.text.TextUtils.TruncateAt.MIDDLE
        })
        info.addView(Hb.text(this,
            if (node.isDir) "Folder" else "${Fmt.bytes(node.size)} • ${Fmt.shortDate(node.modified)}",
            11f, p.muted).apply { setPadding(0, Hb.dp(this@FileManagerActivity, 2), 0, 0) })
        row.addView(info, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))

        if (selectionMode) {
            val check = CheckBox(this).apply {
                isChecked = selected.contains(node.uri.toString())
                buttonTintList = android.content.res.ColorStateList.valueOf(p.blue)
                setOnCheckedChangeListener { _, checked ->
                    if (checked) selected.add(node.uri.toString()) else selected.remove(node.uri.toString())
                    updateSelectionBar()
                }
            }
            row.addView(check)
        } else if (node.isDir) {
            row.addView(Hb.icon(this, R.drawable.ic_chevron_right, p.muted, 18))
        } else {
            row.addView(Hb.iconButton(this, R.drawable.ic_more, p.muted, 36) { fileMenu(node) })
        }

        Hb.clickable(row) {
            if (selectionMode) {
                val key = node.uri.toString()
                if (!selected.add(key)) selected.remove(key)
                updateSelectionBar()
                render()
                return@clickable
            }
            if (node.isDir) {
                if (node.doc != null) {
                    path.add(node.name)
                    load()
                } else {
                    Hb.toast(this, "This folder needs folder access — use \"Choose a folder\" first")
                }
            } else {
                Launcher.openFile(this, node.uri, node.mime)
            }
        }
        row.setOnLongClickListener {
            if (!selectionMode) {
                selectionMode = true
                selected.add(node.uri.toString())
                updateSelectionBar()
                render()
            }
            true
        }
        return row
    }

    private fun iconFor(node: Node): Int = when {
        node.isDir -> R.drawable.ic_folder
        node.mime.startsWith("video/") -> R.drawable.ic_play
        node.mime.startsWith("audio/") -> R.drawable.ic_music
        node.mime.startsWith("image/") -> R.drawable.ic_image
        node.mime == "application/pdf" -> R.drawable.ic_pdf
        node.mime.contains("zip") || node.name.endsWith(".zip", true) -> R.drawable.ic_zip
        else -> R.drawable.ic_file
    }

    private fun fileMenu(node: Node) {
        val actions = arrayListOf("Open", "Share", "Rename", "Copy to…", "Move to…", "Delete")
        androidx.appcompat.app.AlertDialog.Builder(this, R.style.HbDialog)
            .setTitle(node.name)
            .setItems(actions.toTypedArray()) { _, which ->
                when (which) {
                    0 -> Launcher.openFile(this, node.uri, node.mime)
                    1 -> Launcher.shareFile(this, node.uri, node.mime)
                    2 -> rename(node)
                    3 -> {
                        selected.clear(); selected.add(node.uri.toString()); selectionMode = true
                        updateSelectionBar(); render(); startCopyOrMove("copy")
                    }
                    4 -> {
                        selected.clear(); selected.add(node.uri.toString()); selectionMode = true
                        updateSelectionBar(); render(); startCopyOrMove("move")
                    }
                    5 -> {
                        selected.clear(); selected.add(node.uri.toString()); selectionMode = true
                        updateSelectionBar(); render(); deleteSelected()
                    }
                }
            }
            .show()
    }

    // --------------------------------------------------------------- actions

    private fun selectedNodes(): List<Node> =
        nodes.filter { selected.contains(it.uri.toString()) }

    private fun clearSelection() {
        selected.clear()
        selectionMode = false
        updateSelectionBar()
        render()
    }

    private fun shareSelected() {
        val list = selectedNodes()
        if (list.isEmpty()) return
        if (list.size == 1) {
            Launcher.shareFile(this, list[0].uri, list[0].mime)
            return
        }
        val uris = ArrayList<Uri>()
        list.forEach { if (!it.isDir) uris.add(it.uri) }
        if (uris.isEmpty()) {
            Hb.toast(this, "Folders cannot be shared")
            return
        }
        try {
            val send = Intent(Intent.ACTION_SEND_MULTIPLE).apply {
                type = "*/*"
                putParcelableArrayListExtra(Intent.EXTRA_STREAM, uris)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            startActivity(Intent.createChooser(send, "Share ${uris.size} files"))
        } catch (_: Exception) {
            Hb.toast(this, "Sharing is not available")
        }
    }

    private fun deleteSelected() {
        val list = selectedNodes()
        if (list.isEmpty()) return
        Hb.confirm(this, "Delete ${list.size} item(s)?", "This removes the files for good. This cannot be undone.", "Delete", destructive = true) {
            val saf = list.filter { it.doc != null }
            val media = list.filter { it.doc == null }
            lifecycleScope.launch {
                val safDeleted = withContext(Dispatchers.IO) {
                    saf.count { runCatching { it.doc?.delete() == true }.getOrDefault(false) }
                }
                if (safDeleted > 0) Hb.toast(this@FileManagerActivity, "$safDeleted item(s) deleted")
                if (media.isNotEmpty()) {
                    if (Build.VERSION.SDK_INT >= 30) {
                        try {
                            val request = MediaStore.createDeleteRequest(contentResolver, media.map { it.uri })
                            pendingDelete.clear()
                            pendingDelete.addAll(media.map { it.uri })
                            deleteRequest.launch(IntentSenderRequest.Builder(request.intentSender).build())
                        } catch (_: Exception) {
                            deleteDirect(media)
                        }
                    } else {
                        deleteDirect(media)
                    }
                } else {
                    clearSelection()
                    load()
                }
            }
        }
    }

    private fun deleteDirect(list: List<Node>) {
        lifecycleScope.launch {
            val count = withContext(Dispatchers.IO) {
                list.count { n ->
                    runCatching { contentResolver.delete(n.uri, null, null) > 0 }.getOrDefault(false) ||
                        runCatching { n.doc?.delete() == true }.getOrDefault(false)
                }
            }
            Hb.toast(this@FileManagerActivity, "$count item(s) deleted")
            clearSelection()
            load()
        }
    }

    private fun rename(node: Node) {
        Hb.input(this, "Rename", "New name", node.name) { value ->
            val name = Fmt.safeName(value).ifBlank { node.name }
            if (name == node.name) return@input
            lifecycleScope.launch {
                val ok = withContext(Dispatchers.IO) {
                    try {
                        if (node.doc != null) {
                            node.doc.renameTo(name)
                        } else {
                            val values = android.content.ContentValues().apply {
                                put(MediaStore.MediaColumns.DISPLAY_NAME, name)
                            }
                            contentResolver.update(node.uri, values, null, null) > 0
                        }
                    } catch (_: Exception) {
                        false
                    }
                }
                Hb.toast(this@FileManagerActivity, if (ok) "Renamed" else "Could not rename this file")
                load()
            }
        }
    }

    private fun startCopyOrMove(op: String) {
        if (selectedNodes().isEmpty()) {
            Hb.toast(this, "Select files first")
            return
        }
        pendingOp = op
        destination.launch(null)
    }

    private fun copyTo(destTree: Uri, targets: List<Node>, move: Boolean): String {
        val dest = DocumentFile.fromTreeUri(this, destTree) ?: return "Destination is not available"
        var copied = 0
        targets.forEach { node ->
            if (node.isDir) return@forEach
            try {
                val mime = node.mime.ifBlank { "application/octet-stream" }
                val out = dest.createFile(mime, node.name) ?: return@forEach
                contentResolver.openInputStream(node.uri)?.use { input ->
                    contentResolver.openOutputStream(out.uri)?.use { o -> input.copyTo(o, 128 * 1024) }
                } ?: return@forEach
                copied++
                if (move) {
                    val removed = runCatching { node.doc?.delete() == true }.getOrDefault(false) ||
                        runCatching { contentResolver.delete(node.uri, null, null) > 0 }.getOrDefault(false)
                    if (!removed) {
                        // copied but could not remove the original
                    }
                }
            } catch (_: Exception) {
            }
        }
        return when {
            copied == 0 -> "Nothing was copied"
            move -> "$copied file(s) moved"
            else -> "$copied file(s) copied"
        }
    }

    private fun zipSelected() {
        val files = selectedNodes().filter { !it.isDir }
        if (files.isEmpty()) {
            Hb.toast(this, "Select at least one file")
            return
        }
        usedEntries = HashSet()
        lifecycleScope.launch {
            var cacheZip: File? = null
            val msg = withContext(Dispatchers.IO) {
                val name = "HB_${System.currentTimeMillis()}.zip"
                try {
                    val dir = currentDir
                    val doc = dir?.createFile("application/zip", name)
                    val cache = if (doc == null) File(cacheDir, name) else null
                    val stream: OutputStream = if (doc != null) {
                        contentResolver.openOutputStream(doc.uri) ?: return@withContext "Could not create the ZIP"
                    } else {
                        FileOutputStream(cache!!)
                    }
                    ZipOutputStream(BufferedOutputStream(stream)).use { zip ->
                        files.forEach { node ->
                            val entry = uniqueEntry(node.name)
                            zip.putNextEntry(ZipEntry(entry))
                            contentResolver.openInputStream(node.uri)?.use { it.copyTo(zip, 128 * 1024) }
                            zip.closeEntry()
                        }
                    }
                    if (cache != null) {
                        cacheZip = cache
                        "ZIP created in the app cache"
                    } else {
                        "ZIP saved in ${path.lastOrNull() ?: "this folder"}"
                    }
                } catch (e: Exception) {
                    "Could not create ZIP: ${e.message ?: "error"}"
                }
            }
            Hb.toast(this@FileManagerActivity, msg)
            cacheZip?.let { Launcher.shareFile(this@FileManagerActivity, it, "application/zip") }
            clearSelection()
            load()
        }
    }

    private var usedEntries = HashSet<String>()
    private fun uniqueEntry(name: String): String {
        if (usedEntries.add(name)) return name
        var i = 2
        val base = Fmt.base(name)
        val ext = Fmt.ext(name)
        while (true) {
            val candidate = if (ext.isBlank()) "$base ($i)" else "$base ($i).$ext"
            if (usedEntries.add(candidate)) return candidate
            i++
        }
    }

    private fun extract(zipUri: Uri): String {
        usedEntries = HashSet()
        var count = 0
        try {
            val dir = currentDir
            val cacheRoot = File(cacheDir, "unzip_${System.currentTimeMillis()}")
            ZipInputStream(contentResolver.openInputStream(zipUri) ?: return "Could not read the ZIP")
                .use { zin ->
                    while (true) {
                        val entry = zin.nextEntry ?: break
                        if (entry.isDirectory) {
                            zin.closeEntry()
                            continue
                        }
                        val clean = entry.name.replace('\\', '/').trimStart('/')
                        if (clean.split('/').any { it == ".." }) {
                            zin.closeEntry()
                            continue
                        }
                        val parts = clean.split('/').filter { it.isNotBlank() }
                        if (parts.isEmpty()) {
                            zin.closeEntry()
                            continue
                        }
                        val stream: OutputStream? = if (dir != null) {
                            var parent: DocumentFile = dir
                            var failed = false
                            for (i in 0 until parts.size - 1) {
                                val next = parent.findFile(parts[i])?.takeIf { it.isDirectory }
                                    ?: parent.createDirectory(parts[i])
                                if (next == null) {
                                    failed = true
                                    break
                                }
                                parent = next
                            }
                            if (failed) null else {
                                val name = parts.last()
                                val doc = parent.createFile(guessMime(name), name) ?: null
                                doc?.uri?.let { contentResolver.openOutputStream(it) }
                            }
                        } else {
                            val target = File(cacheRoot, clean)
                            target.parentFile?.mkdirs()
                            FileOutputStream(target)
                        }
                        stream?.use { o -> zin.copyTo(o, 128 * 1024) }
                        zin.closeEntry()
                        count++
                    }
                }
        } catch (e: Exception) {
            return "Extraction failed: ${e.message ?: "bad archive"}"
        }
        if (count == 0) return "The ZIP was empty"
        return if (currentDir == null) {
            "$count file(s) extracted to the app cache (choose a folder to keep them)"
        } else {
            "$count file(s) extracted here, keeping the ZIP's folders"
        }
    }

    private fun showSort() {
        val options = arrayOf("Name", "Newest first", "Oldest first", "Largest first", "Smallest first")
        androidx.appcompat.app.AlertDialog.Builder(this, R.style.HbDialog)
            .setTitle("Sort by")
            .setSingleChoiceItems(options, sortMode) { dialog, which ->
                sortMode = which
                dialog.dismiss()
                nodes = sortNodes(nodes)
                render()
            }
            .show()
    }

    private fun showMore() {
        val actions = arrayListOf<String>()
        if (category == null && tree != null) {
            actions.add("New folder")
            actions.add("Extract ZIP…")
            actions.add("Select all")
            actions.add("Choose another folder")
        } else {
            actions.add("Back to folders")
            actions.add("Choose a folder")
        }
        actions.add("File search")
        actions.add("Storage analyzer")

        androidx.appcompat.app.AlertDialog.Builder(this, R.style.HbDialog)
            .setTitle("More")
            .setItems(actions.toTypedArray()) { _, which ->
                when (actions[which]) {
                    "New folder" -> newFolder()
                    "Extract ZIP…" -> pickZip.launch(arrayOf("application/zip", "application/x-zip-compressed", "*/*"))
                    "Select all" -> {
                        selectionMode = true
                        nodes.forEach { selected.add(it.uri.toString()) }
                        updateSelectionBar(); render()
                    }
                    "Choose another folder" -> openFolder.launch(null)
                    "Back to folders" -> {
                        category = null
                        load()
                    }
                    "File search" -> startActivity(Intent(this, FileSearchActivity::class.java))
                    "Storage analyzer" -> startActivity(Intent(this, StorageAnalyzerActivity::class.java))
                }
            }
            .show()
    }

    private fun newFolder() {
        val dir = currentDir
        if (dir == null) {
            Hb.toast(this, "Open a folder first")
            return
        }
        Hb.input(this, "New folder", "Folder name") { value ->
            val name = Fmt.safeName(value)
            lifecycleScope.launch {
                val doc = withContext(Dispatchers.IO) {
                    try {
                        dir.createDirectory(name)
                    } catch (_: Exception) {
                        null
                    }
                }
                if (doc == null) Hb.toast(this@FileManagerActivity, "Could not create the folder")
                load()
            }
        }
    }

    // ------------------------------------------------------------- helpers

    private fun treeLabel(): String {
        val t = tree ?: return "Internal storage"
        return try {
            val id = DocumentsContract.getTreeDocumentId(t)
            val rel = id.substringAfter(':', "")
            if (rel.isBlank()) "Internal storage" else rel
        } catch (_: Exception) {
            "Selected folder"
        }
    }

    private fun guessMime(name: String): String =
        android.webkit.MimeTypeMap.getSingleton()
            .getMimeTypeFromExtension(Fmt.ext(name).lowercase()) ?: "application/octet-stream"

    private fun hasMediaPermission(): Boolean {
        val permissions = if (Build.VERSION.SDK_INT >= 33) {
            listOf(Manifest.permission.READ_MEDIA_IMAGES, Manifest.permission.READ_MEDIA_VIDEO, Manifest.permission.READ_MEDIA_AUDIO)
        } else {
            listOf(Manifest.permission.READ_EXTERNAL_STORAGE)
        }
        return permissions.all {
            ContextCompat.checkSelfPermission(this, it) == PackageManager.PERMISSION_GRANTED
        }
    }

    private fun askMediaPermission() {
        val permissions = if (Build.VERSION.SDK_INT >= 33) {
            arrayOf(Manifest.permission.READ_MEDIA_IMAGES, Manifest.permission.READ_MEDIA_VIDEO, Manifest.permission.READ_MEDIA_AUDIO)
        } else {
            arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE)
        }
        mediaPermissions.launch(permissions)
    }
}
