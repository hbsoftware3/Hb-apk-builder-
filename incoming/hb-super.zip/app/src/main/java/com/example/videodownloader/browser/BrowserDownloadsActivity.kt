package com.example.videodownloader.browser

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.ScrollView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.FileProvider
import androidx.core.view.isVisible
import androidx.documentfile.provider.DocumentFile
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import com.example.videodownloader.Prefs
import com.example.videodownloader.R
import com.example.videodownloader.ui.BaseActivity
import com.example.videodownloader.ui.Hb
import com.example.videodownloader.util.Fmt
import com.example.videodownloader.util.Launcher
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

class BrowserDownloadsActivity : BaseActivity() {

    private lateinit var listCol: LinearLayout
    private lateinit var summary: android.widget.TextView
    private lateinit var folderInfo: android.widget.TextView

    private val picker = registerForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
        if (uri != null) {
            try {
                contentResolver.takePersistableUriPermission(
                    uri,
                    Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
                )
                Prefs.setBrowserDownloadTree(this, uri.toString())
                BrowserDownloads.autoSaveCompleted(this)
                render()
                Hb.toast(this, "Completed files will also be copied to this folder")
            } catch (_: Exception) {
                Hb.toast(this, "Android did not allow this folder")
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val p = Hb.palette(this)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(p.bg)
        }
        root.addView(Hb.topBar(this, "Browser downloads", "Android DownloadManager", onBack = { finish() }, actions = listOf(
            R.drawable.ic_folder to { picker.launch(null) },
            R.drawable.ic_delete to { clearFinished() }
        )))

        val top = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(Hb.dp(this@BrowserDownloadsActivity, 16), 0,
                Hb.dp(this@BrowserDownloadsActivity, 16), Hb.dp(this@BrowserDownloadsActivity, 6))
        }
        summary = Hb.text(this, "No downloads yet", 12f, p.muted)
        top.addView(summary)

        val folderCard = Hb.card(this, 14).apply {
            (layoutParams as LinearLayout.LayoutParams).topMargin = Hb.dp(this@BrowserDownloadsActivity, 10)
        }
        val folderHead = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        folderHead.addView(Hb.iconCircle(this, R.drawable.ic_folder, p.blue, p.blueSoft, 40))
        val folderTexts = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(Hb.dp(this@BrowserDownloadsActivity, 12), 0, 0, 0)
        }
        folderTexts.addView(Hb.text(this, "Save copy to a folder", 14f, p.text, medium = true))
        folderInfo = Hb.text(this, "Not set — files stay in the app's Downloads folder", 11.5f, p.muted)
        folderTexts.addView(folderInfo)
        folderHead.addView(folderTexts, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        folderCard.addView(folderHead)
        val folderActions = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(0, Hb.dp(this@BrowserDownloadsActivity, 10), 0, 0)
        }
        folderActions.addView(smallButton("Choose folder", true) { picker.launch(null) })
        folderActions.addView(smallButton("Reset", false) {
            Prefs.setBrowserDownloadTree(this, null)
            render()
            Hb.toast(this, "Folder reset")
        })
        folderCard.addView(folderActions)
        folderCard.addView(Hb.toggleRow(this, "Wi-Fi only downloads", "Wait for Wi-Fi before starting browser downloads", Prefs.wifiOnly(this)) {
            Prefs.setWifiOnly(this, it)
        })
        top.addView(folderCard)
        root.addView(top)

        val scroll = ScrollView(this).apply { setBackgroundColor(p.bg) }
        listCol = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(Hb.dp(this@BrowserDownloadsActivity, 16), Hb.dp(this@BrowserDownloadsActivity, 4),
                Hb.dp(this@BrowserDownloadsActivity, 16), Hb.dp(this@BrowserDownloadsActivity, 28))
        }
        scroll.addView(listCol)
        root.addView(scroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))

        setContentView(root)

        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                while (true) {
                    render()
                    delay(1200)
                }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        render()
        BrowserDownloads.autoSaveCompleted(this)
    }

    private fun render() {
        val items = BrowserDownloads.list(this)
        val active = items.count { it.running }
        summary.text = when {
            items.isEmpty() -> "Files downloaded from HB Browser appear here"
            active > 0 -> "$active downloading • ${items.size} total"
            else -> "${items.size} files"
        }
        val tree = Prefs.browserDownloadTree(this)
        folderInfo.text = if (tree == null) {
            "Not set — files stay in the app's Downloads folder"
        } else {
            val name = try {
                DocumentFile.fromTreeUri(this, Uri.parse(tree))?.name
            } catch (_: Exception) {
                null
            } ?: "Selected folder"
            "Completed files are also copied to \"$name\""
        }

        listCol.removeAllViews()
        if (items.isEmpty()) {
            listCol.addView(Hb.empty(this, R.drawable.ic_download, "No browser downloads",
                "Tap a download link on a website. HB Browser asks before every download."))
            return
        }
        listCol.addView(Hb.spacer(this, 8))
        items.forEach { item ->
            listCol.addView(downloadCard(item))
            listCol.addView(Hb.spacer(this, 10))
        }
        listCol.addView(Hb.text(this, "Files are stored in the app's private Downloads folder. Choose a folder above to keep a copy you can share with other apps.", 10.5f, Hb.palette(this).muted).apply {
            setPadding(Hb.dp(this@BrowserDownloadsActivity, 4), Hb.dp(this@BrowserDownloadsActivity, 8), 0, 0)
        })
    }

    private fun downloadCard(item: BrowserDownload): LinearLayout {
        val p = Hb.palette(this)
        val card = Hb.card(this, 14)
        val head = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val icon = when {
            item.mime.startsWith("image/") -> R.drawable.ic_image
            item.mime.startsWith("video/") || item.mime.startsWith("audio/") -> R.drawable.ic_play
            item.mime.contains("pdf") -> R.drawable.ic_pdf
            item.mime.contains("zip") -> R.drawable.ic_zip
            else -> R.drawable.ic_file
        }
        head.addView(Hb.iconCircle(this, icon, p.blue, p.blueSoft, 42))
        val texts = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(Hb.dp(this@BrowserDownloadsActivity, 12), 0, Hb.dp(this@BrowserDownloadsActivity, 6), 0)
        }
        texts.addView(Hb.text(this, item.name, 13.5f, p.text, medium = true).apply { maxLines = 1 })
        texts.addView(Hb.text(this, BrowserUrl.host(item.url), 10.5f, p.muted).apply { maxLines = 1 })
        head.addView(texts, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        val status = Hb.text(this, BrowserDownloads.statusLabel(this, item), 10.5f,
            if (item.failed) p.danger else if (item.done) p.success else p.blue, medium = true)
        head.addView(status)
        card.addView(head)

        if (item.running) {
            val bar = Hb.progress(this)
            bar.progress = item.progress
            card.addView(bar.apply {
                (layoutParams as LinearLayout.LayoutParams).topMargin = Hb.dp(this@BrowserDownloadsActivity, 10)
            })
            if (item.total > 0) {
                card.addView(Hb.text(this, "${Fmt.bytes(item.downloaded)} / ${Fmt.bytes(item.total)}", 10f, p.muted).apply {
                    setPadding(0, Hb.dp(this@BrowserDownloadsActivity, 5), 0, 0)
                })
            }
        }

        val actions = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(0, Hb.dp(this@BrowserDownloadsActivity, 10), 0, 0)
        }
        if (item.done) {
            actions.addView(smallButton("Open", true) { open(item) })
            actions.addView(smallButton("Share", false) { share(item) })
            if (Prefs.browserDownloadTree(this) != null) {
                actions.addView(smallButton(if (item.saved) "Saved ✓" else "Save copy", false) {
                    if (BrowserDownloads.copyToUserFolder(this, item)) {
                        Hb.toast(this, "Copied to your folder")
                        render()
                    } else {
                        Hb.toast(this, "Could not copy. Check the folder permission.")
                    }
                })
            }
            actions.addView(smallButton("Delete", false, danger = true) { confirmDelete(item) })
        } else if (item.failed) {
            actions.addView(smallButton("Retry", true) { retry(item) })
            actions.addView(smallButton("Remove", false, danger = true) { confirmDelete(item) })
        } else {
            actions.addView(smallButton("Cancel", false, danger = true) {
                BrowserDownloads.cancel(this, item.id)
                render()
                Hb.toast(this, "Download cancelled")
            })
        }
        card.addView(actions)
        return card
    }

    private fun smallButton(label: String, primary: Boolean, danger: Boolean = false, onTap: () -> Unit): android.widget.TextView {
        val p = Hb.palette(this)
        return Hb.text(this, label, 11.5f,
            if (primary) android.graphics.Color.WHITE else if (danger) p.danger else p.text, medium = true).apply {
            gravity = Gravity.CENTER
            setPadding(Hb.dp(this@BrowserDownloadsActivity, 12), Hb.dp(this@BrowserDownloadsActivity, 8),
                Hb.dp(this@BrowserDownloadsActivity, 12), Hb.dp(this@BrowserDownloadsActivity, 8))
            background = if (primary) Hb.round(this@BrowserDownloadsActivity, 40, p.blue)
            else Hb.round(this@BrowserDownloadsActivity, 40, p.surfaceAlt, p.border, 1)
            Hb.clickable(this, onTap)
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                marginEnd = Hb.dp(this@BrowserDownloadsActivity, 6)
            }
        }
    }

    private fun fileUri(item: BrowserDownload): Uri? {
        val file = BrowserDownloads.fileFor(this, item.name)
        if (!file.exists()) {
            Hb.toast(this, "The file is missing from storage")
            return null
        }
        return try {
            FileProvider.getUriForFile(this, "$packageName.fileprovider", file)
        } catch (_: Exception) {
            Hb.toast(this, "Could not open this file")
            null
        }
    }

    private fun open(item: BrowserDownload) {
        val uri = fileUri(item) ?: return
        val mime = item.mime.ifBlank { BrowserDownloads.guessMime(item.url) }
        Launcher.openFile(this, uri, mime)
    }

    private fun share(item: BrowserDownload) {
        val uri = fileUri(item) ?: return
        val mime = item.mime.ifBlank { BrowserDownloads.guessMime(item.url) }
        Launcher.shareFile(this, uri, mime, item.name)
    }

    private fun retry(item: BrowserDownload) {
        // Remove the failed record and its partial file first, so the original name can be reused.
        BrowserDownloads.cancel(this, item.id)
        BrowserDownloads.enqueue(this, item.url, item.userAgent, null, item.referer,
            item.mime, item.name, Prefs.wifiOnly(this))
        render()
        Hb.toast(this, "Download queued again")
    }

    private fun confirmDelete(item: BrowserDownload) {
        Hb.confirm(this, "Remove download?", "The file will be deleted from the app's Downloads folder.", "Delete", destructive = true) {
            BrowserDownloads.cancel(this, item.id)
            render()
        }
    }

    private fun clearFinished() {
        val items = BrowserDownloads.list(this)
        if (items.none { it.done || it.failed }) {
            Hb.toast(this, "No completed downloads to clear")
            return
        }
        Hb.confirm(this, "Clear finished?", "Removes completed and failed entries and deletes their files from the app's Downloads folder.", "Clear", destructive = true) {
            BrowserDownloads.clearFinished(this)
            render()
        }
    }
}
