package com.example.videodownloader.browser

import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.ScrollView
import androidx.appcompat.app.AlertDialog
import com.example.videodownloader.R
import com.example.videodownloader.ui.BaseActivity
import com.example.videodownloader.ui.Hb
import com.example.videodownloader.util.Launcher

class BrowserBookmarksActivity : BaseActivity() {

    private lateinit var chips: LinearLayout
    private lateinit var listCol: LinearLayout
    private var folder: String? = null
    private var query = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val p = Hb.palette(this)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(p.bg)
        }
        root.addView(Hb.topBar(this, "Bookmarks", "Organize saved pages", onBack = { finish() }, actions = listOf(
            R.drawable.ic_add to { addFolder() }
        )))

        val searchWrap = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(Hb.dp(this@BrowserBookmarksActivity, 16), Hb.dp(this@BrowserBookmarksActivity, 4),
                Hb.dp(this@BrowserBookmarksActivity, 16), Hb.dp(this@BrowserBookmarksActivity, 8))
        }
        val search = EditText(this).apply {
            hint = "Search bookmarks"
            setHintTextColor(p.muted)
            setTextColor(p.text)
            textSize = 14f
            setSingleLine(true)
            background = Hb.round(this@BrowserBookmarksActivity, 14, p.surface, p.border, 1)
            setPadding(Hb.dp(this@BrowserBookmarksActivity, 14), 0, Hb.dp(this@BrowserBookmarksActivity, 14), 0)
            addTextChangedListener(object : TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
                override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
                override fun afterTextChanged(s: Editable?) {
                    query = s?.toString() ?: ""
                    render()
                }
            })
        }
        searchWrap.addView(search, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, Hb.dp(this, 46)))
        root.addView(searchWrap)

        val chipScroll = HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false }
        chips = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(Hb.dp(this@BrowserBookmarksActivity, 16), 0,
                Hb.dp(this@BrowserBookmarksActivity, 16), Hb.dp(this@BrowserBookmarksActivity, 10))
        }
        chipScroll.addView(chips)
        root.addView(chipScroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        val scroll = ScrollView(this).apply { setBackgroundColor(p.bg) }
        listCol = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(Hb.dp(this@BrowserBookmarksActivity, 16), 0,
                Hb.dp(this@BrowserBookmarksActivity, 16), Hb.dp(this@BrowserBookmarksActivity, 28))
        }
        scroll.addView(listCol)
        root.addView(scroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))

        setContentView(root)
        render()
    }

    private fun render() {
        renderChips()
        listCol.removeAllViews()
        val all = BrowserStore.searchBookmarks(this, query).filter { folder == null || it.folder == folder }
        if (all.isEmpty()) {
            listCol.addView(Hb.empty(this, R.drawable.ic_star,
                if (query.isBlank() && folder == null) "No bookmarks yet" else "Nothing here",
                "Tap the star in HB Browser to save a page. Long-press a bookmark to rename, move or delete it."))
            return
        }
        listCol.addView(Hb.section(this, if (folder == null) "All bookmarks" else folder!!, "${all.size}"))
        all.forEach { bookmark ->
            val row = Hb.row(
                this,
                R.drawable.ic_star,
                bookmark.title.ifBlank { BrowserUrl.display(bookmark.url) },
                BrowserUrl.display(bookmark.url),
                trailing = bookmark.folder,
                iconTint = Hb.palette(this).warning
            ) {
                Launcher.openUrl(this, bookmark.url)
                finish()
            }
            row.setOnLongClickListener {
                showActions(bookmark)
                true
            }
            listCol.addView(row)
            listCol.addView(Hb.divider(this, 46))
        }
    }

    private fun renderChips() {
        chips.removeAllViews()
        val p = Hb.palette(this)
        val allChip = Hb.chip(this, "All", folder == null)
        Hb.clickable(allChip) { folder = null; render() }
        chips.addView(allChip, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
            marginEnd = Hb.dp(this@BrowserBookmarksActivity, 8)
        })
        BrowserStore.folders(this).forEach { name ->
            val chip = Hb.chip(this, name, folder == name)
            Hb.clickable(chip) { folder = name; render() }
            chip.setOnLongClickListener {
                if (name == BrowserStore.DEFAULT_FOLDER) {
                    Hb.toast(this, "The default folder cannot be removed")
                } else {
                    Hb.confirm(this, "Remove folder?", "Bookmarks inside \"$name\" will move to Favorites.", "Remove", destructive = true) {
                        BrowserStore.removeFolder(this, name)
                        if (folder == name) folder = null
                        render()
                    }
                }
                true
            }
            chips.addView(chip, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                marginEnd = Hb.dp(this@BrowserBookmarksActivity, 8)
            })
        }
        val add = Hb.text(this, "+ Folder", 12.5f, p.blue, medium = true).apply {
            setPadding(Hb.dp(this@BrowserBookmarksActivity, 12), Hb.dp(this@BrowserBookmarksActivity, 9),
                Hb.dp(this@BrowserBookmarksActivity, 12), Hb.dp(this@BrowserBookmarksActivity, 9))
            background = Hb.round(this@BrowserBookmarksActivity, 40, p.blueSoft)
            Hb.clickable(this) { addFolder() }
        }
        chips.addView(add)
    }

    private fun showActions(bookmark: Bookmark) {
        val labels = arrayOf("Open", "Rename", "Move to folder", "Share link", "Copy link", "Delete bookmark")
        AlertDialog.Builder(this, R.style.HbDialog)
            .setTitle(bookmark.title.ifBlank { BrowserUrl.display(bookmark.url) })
            .setItems(labels) { _, which ->
                when (which) {
                    0 -> {
                        Launcher.openUrl(this, bookmark.url)
                        finish()
                    }
                    1 -> Hb.input(this, "Rename bookmark", "Title", bookmark.title) { value ->
                        BrowserStore.updateBookmark(this, bookmark.id, value, bookmark.folder)
                        render()
                    }
                    2 -> moveBookmark(bookmark)
                    3 -> Launcher.shareText(this, bookmark.url, "Share bookmark")
                    4 -> Launcher.copy(this, bookmark.url, "Link copied")
                    5 -> Hb.confirm(this, "Delete bookmark?", bookmark.title.ifBlank { BrowserUrl.display(bookmark.url) }, "Delete", destructive = true) {
                        BrowserStore.removeBookmark(this, bookmark.id)
                        render()
                    }
                }
            }
            .show()
    }

    private fun moveBookmark(bookmark: Bookmark) {
        val folders = BrowserStore.folders(this)
        AlertDialog.Builder(this, R.style.HbDialog)
            .setTitle("Move to folder")
            .setItems(folders.toTypedArray()) { _, which ->
                BrowserStore.updateBookmark(this, bookmark.id, bookmark.title, folders[which])
                render()
            }
            .show()
    }

    private fun addFolder() {
        Hb.input(this, "New folder", "Folder name") { name ->
            if (name.isBlank()) {
                Hb.toast(this, "Enter a folder name")
                return@input
            }
            if (BrowserStore.addFolder(this, name)) {
                folder = name.trim()
                render()
            } else {
                Hb.toast(this, "That folder already exists")
            }
        }
    }
}
