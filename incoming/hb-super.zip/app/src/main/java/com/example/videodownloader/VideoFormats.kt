package com.example.videodownloader

import android.content.Context
import com.yausername.youtubedl_android.YoutubeDL
import com.yausername.youtubedl_android.YoutubeDLRequest
import org.json.JSONArray
import org.json.JSONObject

/** Asks yt-dlp which picture heights a video really offers, for the quality picker. */
object VideoFormats {

    private val cache = HashMap<String, List<Int>>()

    fun heights(
        context: Context,
        url: String,
        referer: String? = null,
        userAgent: String? = null,
        cookiesFile: String? = null
    ): List<Int> {
        synchronized(cache) { cache[url]?.let { return it } }
        val list = try {
            YoutubeDL.getInstance().init(context.applicationContext)
            val req = YoutubeDLRequest(url).apply {
                addOption("--dump-single-json")
                addOption("--no-playlist")
                addOption("--no-warnings")
                addOption("--skip-download")
                if (referer != null) addOption("--referer", referer)
                if (userAgent != null) addOption("--user-agent", userAgent)
                if (cookiesFile != null) addOption("--cookies", cookiesFile)
            }
            val json = JSONObject(YoutubeDL.getInstance().execute(req).out)
            val formats = json.optJSONArray("formats") ?: JSONArray()
            val heights = sortedSetOf<Int>()
            for (i in 0 until formats.length()) {
                val f = formats.optJSONObject(i) ?: continue
                if (f.optString("vcodec") == "none") continue
                val h = f.optInt("height", 0)
                if (h > 0) heights.add(h)
            }
            heights.toList()
        } catch (_: Exception) {
            emptyList()
        }
        synchronized(cache) { cache[url] = list }
        return list
    }
}
