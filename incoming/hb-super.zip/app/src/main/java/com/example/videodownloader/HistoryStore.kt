package com.example.videodownloader

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

data class HistoryItem(
    val id: Long,
    val url: String,
    val title: String,
    val uri: String?,
    val mime: String?,
    val ok: Boolean,
    val message: String,
    val quality: String,
    val time: Long,
    val size: Long = 0 // bytes of everything saved by this download (0 = unknown, older entries)
)

object HistoryStore {
    private val lock = Any()
    private fun file(c: Context) = File(c.filesDir, "history.json")

    fun all(c: Context): List<HistoryItem> = synchronized(lock) { read(c) }

    fun add(c: Context, item: HistoryItem) {
        synchronized(lock) { write(c, (listOf(item) + read(c)).take(1000)) }
    }

    fun remove(c: Context, id: Long) {
        synchronized(lock) { write(c, read(c).filter { it.id != id }) }
    }

    /** Removes every entry for which [test] is true (used by "Clear all" of the video / audio lists). */
    fun removeWhere(c: Context, test: (HistoryItem) -> Boolean) {
        synchronized(lock) { write(c, read(c).filter { !test(it) }) }
    }

    fun clear(c: Context) {
        synchronized(lock) { file(c).delete() }
    }

    private fun read(c: Context): List<HistoryItem> {
        val f = file(c)
        if (!f.exists()) return emptyList()
        return try {
            val arr = JSONArray(f.readText())
            (0 until arr.length()).map { i ->
                val o = arr.getJSONObject(i)
                HistoryItem(
                    id = o.getLong("id"),
                    url = o.getString("url"),
                    title = o.getString("title"),
                    uri = if (o.isNull("uri")) null else o.getString("uri"),
                    mime = if (o.isNull("mime")) null else o.getString("mime"),
                    ok = o.getBoolean("ok"),
                    message = o.optString("message", ""),
                    quality = o.optString("quality", ""),
                    time = o.getLong("time"),
                    size = o.optLong("size", 0L)
                )
            }
        } catch (e: Exception) {
            emptyList()
        }
    }

    private fun write(c: Context, list: List<HistoryItem>) {
        val arr = JSONArray()
        list.forEach { h ->
            arr.put(JSONObject().apply {
                put("id", h.id)
                put("url", h.url)
                put("title", h.title)
                put("uri", h.uri ?: JSONObject.NULL)
                put("mime", h.mime ?: JSONObject.NULL)
                put("ok", h.ok)
                put("message", h.message)
                put("quality", h.quality)
                put("time", h.time)
                put("size", h.size)
            })
        }
        file(c).writeText(arr.toString())
    }

    /** Audio (MP3) entry? Failed ones have no file type, so the quality label decides. */
    fun isAudioItem(h: HistoryItem): Boolean =
        h.mime?.startsWith("audio/") == true || h.quality.startsWith("Audio")

    /** 1536 -> "1.5 KB", 5242880 -> "5.0 MB", 1610612736 -> "1.50 GB" */
    fun fmtSize(bytes: Long): String {
        val kb = 1024.0
        val mb = kb * 1024
        val gb = mb * 1024
        return when {
            bytes < mb -> String.format(java.util.Locale.US, "%.0f KB", bytes / kb)
            bytes < gb -> String.format(java.util.Locale.US, "%.1f MB", bytes / mb)
            else -> String.format(java.util.Locale.US, "%.2f GB", bytes / gb)
        }
    }
}
