package com.example.videodownloader

import android.content.Context
import android.webkit.CookieManager
import java.io.File
import java.util.UUID

/**
 * Uses the login the person made inside HB Browser (WebView cookies) for downloads that start
 * outside the browser, for example a link shared from the Instagram app.
 * Instagram refuses anonymous requests quickly ("rate-limit ... redirected to the login page"),
 * so one login in HB Browser fixes it. The cookie file is created per download and deleted after.
 */
object SiteLogin {
    private fun urls(site: Site): List<String> = when (site) {
        Site.INSTAGRAM -> listOf("https://www.instagram.com", "https://instagram.com")
        else -> emptyList()
    }

    private fun domain(site: Site): String? = when (site) {
        Site.INSTAGRAM -> ".instagram.com"
        else -> null
    }

    private fun rawCookies(site: Site): String {
        val cm = try { CookieManager.getInstance() } catch (_: Exception) { return "" }
        val parts = LinkedHashMap<String, String>()
        for (u in urls(site)) {
            val c = try { cm.getCookie(u) } catch (_: Exception) { null } ?: continue
            c.split(';').forEach { p ->
                val t = p.trim()
                val eq = t.indexOf('=')
                if (eq > 0) parts[t.substring(0, eq).trim()] = t.substring(eq + 1).trim()
            }
        }
        return parts.entries.joinToString("; ") { it.key + "=" + it.value }
    }

    /** True when the browser holds a real Instagram login (the sessionid cookie). */
    fun isLoggedIn(site: Site): Boolean {
        if (site != Site.INSTAGRAM) return false
        return rawCookies(site).split(';').any { it.trim().startsWith("sessionid=") && it.trim().length > 12 }
    }

    /** Removes the saved login of this site from the browser. */
    fun logOut(site: Site) {
        try {
            val cm = CookieManager.getInstance()
            for (u in urls(site)) {
                cm.getCookie(u)?.split(';')?.forEach { p ->
                    val name = p.trim().substringBefore('=').trim()
                    if (name.isNotEmpty()) {
                        cm.setCookie(u, "$name=; Max-Age=0; Path=/")
                        cm.setCookie(u, "$name=; Max-Age=0; Path=/; Domain=${domain(site)}")
                    }
                }
            }
            cm.flush()
        } catch (_: Exception) {
        }
    }

    /** Writes a Netscape cookies.txt for yt-dlp, or returns null if there is no login. */
    fun cookieFile(c: Context, site: Site): String? {
        val dom = domain(site) ?: return null
        if (!isLoggedIn(site)) return null
        return try {
            val sb = StringBuilder("# Netscape HTTP Cookie File\n")
            rawCookies(site).split(';').forEach { part ->
                val p = part.trim()
                val eq = p.indexOf('=')
                if (eq <= 0) return@forEach
                val name = p.substring(0, eq).trim().replace("\t", "").replace("\n", "")
                val value = p.substring(eq + 1).trim().replace("\t", "").replace("\n", "")
                if (name.isEmpty() || name.startsWith("#")) return@forEach
                sb.append(dom).append('\t').append("TRUE").append('\t').append('/').append('\t')
                    .append("TRUE").append('\t').append("0").append('\t')
                    .append(name).append('\t').append(value).append('\n')
            }
            val dir = File(c.cacheDir, "dl_cookies").apply { mkdirs() }
            val f = File(dir, "c_" + UUID.randomUUID().toString().take(8) + ".txt")
            f.writeText(sb.toString())
            f.absolutePath
        } catch (_: Exception) {
            null
        }
    }
}
