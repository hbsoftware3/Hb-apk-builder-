package com.example.videodownloader.util

import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import android.widget.Toast
import androidx.core.content.FileProvider
import com.example.videodownloader.MainActivity
import com.example.videodownloader.R
import com.example.videodownloader.RingtoneActivity
import com.example.videodownloader.StatusActivity
import com.example.videodownloader.converter.ConverterActivity
import com.example.videodownloader.files.FileManagerActivity
import com.example.videodownloader.files.FileSearchActivity
import com.example.videodownloader.files.StorageAnalyzerActivity
import com.example.videodownloader.player.PlayerActivity
import com.example.videodownloader.tools.ClipboardToolActivity
import com.example.videodownloader.tools.ImageViewerActivity
import com.example.videodownloader.tools.PdfViewerActivity
import com.example.videodownloader.tools.QrCreateActivity
import com.example.videodownloader.tools.QrScanActivity
import com.example.videodownloader.tools.TextToolsActivity
import java.io.File

object Launcher {

    fun openTool(c: Context, tool: Tool) {
        when (tool) {
            Tool.PLAYER -> start(c, Intent(c, PlayerActivity::class.java))
            Tool.FILES -> start(c, Intent(c, FileManagerActivity::class.java))
            Tool.CONVERTER -> start(c, Intent(c, ConverterActivity::class.java))
            Tool.QR_SCAN -> start(c, Intent(c, QrScanActivity::class.java))
            Tool.QR_CREATE -> start(c, Intent(c, QrCreateActivity::class.java))
            Tool.PDF -> start(c, Intent(c, PdfViewerActivity::class.java))
            Tool.IMAGE -> start(c, Intent(c, ImageViewerActivity::class.java))
            Tool.RINGTONE -> start(c, Intent(c, RingtoneActivity::class.java))
            Tool.CLIPBOARD -> start(c, Intent(c, ClipboardToolActivity::class.java))
            Tool.STORAGE -> start(c, Intent(c, StorageAnalyzerActivity::class.java))
            Tool.SEARCH -> start(c, Intent(c, FileSearchActivity::class.java))
            Tool.TEXT -> start(c, Intent(c, TextToolsActivity::class.java))
            Tool.STATUS -> start(c, Intent(c, StatusActivity::class.java))
            Tool.BROWSER -> openBrowserTab(c, MainActivity.TAB_BROWSER)
        }
    }

    fun openBrowserTab(c: Context, tab: Int) {
        start(c, Intent(c, MainActivity::class.java)
            .putExtra(MainActivity.EXTRA_TAB, tab)
            .addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP))
    }

    fun openUrl(c: Context, url: String) {
        start(c, Intent(c, MainActivity::class.java)
            .putExtra(MainActivity.EXTRA_OPEN_URL, url)
            .addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP))
    }

    fun playMedia(c: Context, uri: Uri, mime: String, title: String? = null) {
        start(c, Intent(c, PlayerActivity::class.java)
            .setDataAndType(uri, mime)
            .putExtra(PlayerActivity.EXTRA_TITLE, title))
    }

    fun viewImage(c: Context, uri: Uri) {
        start(c, Intent(c, ImageViewerActivity::class.java).setData(uri))
    }

    fun viewPdf(c: Context, uri: Uri) {
        start(c, Intent(c, PdfViewerActivity::class.java).setData(uri))
    }

    fun openFile(c: Context, uri: Uri, mime: String) {
        when {
            mime.startsWith("video/") || mime.startsWith("audio/") -> playMedia(c, uri, mime)
            mime == "application/pdf" -> viewPdf(c, uri)
            mime.startsWith("image/") -> viewImage(c, uri)
            else -> openWith(c, uri, mime)
        }
    }

    fun openWith(c: Context, uri: Uri, mime: String) {
        try {
            val i = Intent(Intent.ACTION_VIEW).setDataAndType(uri, mime)
                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            c.startActivity(i)
        } catch (_: ActivityNotFoundException) {
            Toast.makeText(c, "No app can open this file type", Toast.LENGTH_LONG).show()
        } catch (_: Exception) {
            Toast.makeText(c, "Could not open this file", Toast.LENGTH_LONG).show()
        }
    }

    fun shareFile(c: Context, uri: Uri, mime: String, title: String = "Share file") {
        try {
            val send = Intent(Intent.ACTION_SEND).apply {
                type = mime
                putExtra(Intent.EXTRA_STREAM, uri)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            c.startActivity(Intent.createChooser(send, title))
        } catch (_: Exception) {
            Toast.makeText(c, "Sharing is not available", Toast.LENGTH_LONG).show()
        }
    }

    fun shareFile(c: Context, file: File, mime: String) {
        try {
            val uri = FileProvider.getUriForFile(c, "${c.packageName}.fileprovider", file)
            shareFile(c, uri, mime)
        } catch (_: Exception) {
            Toast.makeText(c, "Sharing is not available", Toast.LENGTH_LONG).show()
        }
    }

    fun shareText(c: Context, text: String, title: String = "Share") {
        c.startActivity(Intent.createChooser(
            Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, text),
            title
        ))
    }

    fun copy(c: Context, text: String, label: String = "Copied") {
        val cm = c.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        cm.setPrimaryClip(ClipData.newPlainText("HB", text))
        Toast.makeText(c, label, Toast.LENGTH_SHORT).show()
    }

    fun appSettings(c: Context) {
        try {
            c.startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${c.packageName}")))
        } catch (_: Exception) {
        }
    }

    fun notificationSettings(c: Context) {
        try {
            c.startActivity(Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS)
                .putExtra(Settings.EXTRA_APP_PACKAGE, c.packageName))
        } catch (_: Exception) {
            appSettings(c)
        }
    }

    private fun start(c: Context, i: Intent) {
        if (c !is Activity) i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        try {
            c.startActivity(i)
        } catch (e: Exception) {
            Toast.makeText(c, "Could not open this screen", Toast.LENGTH_LONG).show()
        }
    }
}
