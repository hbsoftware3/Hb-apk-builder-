package com.example.videodownloader

import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * The single tap after a background update download: hands the stored APK to Android's installer and
 * closes, so the user does not have to open the app and hunt for a button first.
 *
 * Android never lets a normal app install an APK with no confirmation at all, so this screen adds none
 * of its own: it only opens Android's installer.
 */
class InstallUpdateActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (savedInstanceState != null) return
        val apk = UpdateStore.readyApk(this)
        if (apk == null) {
            // nothing finished to install (still downloading, or the file was cleared): show the app
            openApp()
            finish()
            return
        }
        if (Build.VERSION.SDK_INT >= 26 && !packageManager.canRequestPackageInstalls()) {
            Toast.makeText(this, "Allow \"Install unknown apps\" for HB Super App.", Toast.LENGTH_LONG).show()
            openApp()
            try {
                startActivity(
                    Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:$packageName"))
                )
            } catch (_: Exception) {
            }
            finish()
            return
        }
        Toast.makeText(this, "Installing update...", Toast.LENGTH_SHORT).show()
        // the APK is copied into the installer session, so this is done away from the main thread
        lifecycleScope.launch(Dispatchers.IO) {
            val failure = runCatching { Updater.installFrom(applicationContext, apk) }.exceptionOrNull()
            withContext(Dispatchers.Main) {
                if (failure != null) {
                    Toast.makeText(
                        this@InstallUpdateActivity,
                        "Could not open the installer: ${failure.message}",
                        Toast.LENGTH_LONG
                    ).show()
                    openApp()
                    finish()
                    return@withContext
                }
                Updater.markHandedOver()
                UpdateStore.setStatus(this@InstallUpdateActivity, UpdateStore.INSTALLING)
                UpdateTracker.set(UpdateStore.INSTALLING, "Opening Android's installer...", 100)
                // Stay alive for a moment, otherwise Android may keep the installer screen hidden until
                // the app is opened again.
                window.decorView.postDelayed({ finish() }, 1500)
            }
        }
    }

    private fun openApp() {
        startActivity(
            Intent(this, MainActivity::class.java)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
        )
    }
}
