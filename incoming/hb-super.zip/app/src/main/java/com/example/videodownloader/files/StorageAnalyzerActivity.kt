package com.example.videodownloader.files

import android.content.ContentUris
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.os.StatFs
import android.provider.MediaStore
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.documentfile.provider.DocumentFile
import androidx.lifecycle.lifecycleScope
import com.example.videodownloader.R
import com.example.videodownloader.ui.BaseActivity
import com.example.videodownloader.ui.Hb
import com.example.videodownloader.util.Fmt
import com.example.videodownloader.util.Launcher
import com.example.videodownloader.util.MediaIndex
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

/**
 * Storage screen: real numbers from the system (StatFs, MediaStore) plus an optional folder scan
 * the user starts by picking a folder. MediaStore sizes are what Android reports to apps; the
 * filesystem total is the source of truth for free space.
 */
class StorageAnalyzerActivity : BaseActivity() {

    private lateinit var body: LinearLayout
    private var scanning = false

    private val pickFolder = registerForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
        uri ?: return@registerForActivityResult
        try {
            contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
        } catch (_: Exception) {
        }
        scanFolder(uri)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Hb.palette(this@StorageAnalyzerActivity).bg)
        }
        root.addView(Hb.topBar(this, "Storage Analyzer", "Space, big files and folders", { finish() }))
        val scroll = ScrollView(this).apply { isFillViewport = true }
        body = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(Hb.dp(this@StorageAnalyzerActivity, 16), Hb.dp(this@StorageAnalyzerActivity, 6),
                Hb.dp(this@StorageAnalyzerActivity, 16), Hb.dp(this@StorageAnalyzerActivity, 30))
        }
        scroll.addView(body)
        root.addView(scroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        setContentView(root)
        render()
    }

    private fun render() {
        body.removeAllViews()
        val p = Hb.palette(this)

        val stat = StatFs(Environment.getExternalStorageDirectory().absolutePath)
        val total = if (android.os.Build.VERSION.SDK_INT >= 18) stat.totalBytes else 0L
        val free = if (android.os.Build.VERSION.SDK_INT >= 18) stat.availableBytes else 0L
        val used = (total - free).coerceAtLeast(0)

        val hero = Hb.card(this, 18)
        hero.addView(Hb.text(this, "Internal storage", 16f, p.text, bold = true))
        hero.addView(Hb.text(this, "${Fmt.bytes(used)} used of ${Fmt.bytes(total)}", 12f, p.muted).apply {
            setPadding(0, Hb.dp(this@StorageAnalyzerActivity, 3), 0, Hb.dp(this@StorageAnalyzerActivity, 10))
        })
        val bar = Hb.progress(this).apply {
            max = 100
            progress = if (total > 0) ((used * 100) / total).toInt() else 0
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, Hb.dp(this@StorageAnalyzerActivity, 8))
        }
        hero.addView(bar)
        val stats = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(0, Hb.dp(this@StorageAnalyzerActivity, 12), 0, 0)
        }
        stats.addView(Hb.stat(this, "Used", Fmt.bytes(used), p.blue), LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply {
            marginEnd = Hb.dp(this@StorageAnalyzerActivity, 8)
        })
        stats.addView(Hb.stat(this, "Free", Fmt.bytes(free), p.success), LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        hero.addView(stats)
        body.addView(hero)

        body.addView(Hb.section(this, "By type"))
        val byType = Hb.card(this, 6)
        val sums = categorySizes()
        val max = (sums.values.maxOrNull() ?: 1L).coerceAtLeast(1L)
        val labels = listOf(
            "videos" to "Videos", "images" to "Photos", "audio" to "Music",
            "documents" to "Documents", "apk" to "APK files", "downloads" to "Downloads folder",
            "other" to "Other indexed files"
        )
        labels.forEachIndexed { index, (key, label) ->
            val value = sums[key] ?: 0L
            byType.addView(typeRow(label, value, max))
            if (index != labels.lastIndex) byType.addView(Hb.divider(this, 4))
        }
        body.addView(byType)
        body.addView(Hb.text(this, "Sizes come from Android's media index. Files Android does not index are not counted here.", 10.5f, p.muted).apply {
            setPadding(Hb.dp(this@StorageAnalyzerActivity, 4), Hb.dp(this@StorageAnalyzerActivity, 6), 0, 0)
        })

        body.addView(Hb.section(this, "Largest indexed files"))
        lifecycleScope.launch {
            val files = withContext(Dispatchers.IO) { largestFiles() }
            if (files.isEmpty()) {
                body.addView(Hb.empty(this@StorageAnalyzerActivity, R.drawable.ic_storage, "No indexed files", "Allow media access or pick a folder below"))
            } else {
                val card = Hb.card(this@StorageAnalyzerActivity, 6)
                files.forEachIndexed { index, f ->
                    card.addView(Hb.row(this@StorageAnalyzerActivity, iconFor(f.mime), f.name, Fmt.bytes(f.size)) {
                        Launcher.openFile(this@StorageAnalyzerActivity, f.uri, f.mime)
                    })
                    if (index != files.lastIndex) card.addView(Hb.divider(this@StorageAnalyzerActivity, 4))
                }
                body.addView(card)
            }
        }

        body.addView(Hb.section(this, "App cache"))
        val cacheCard = Hb.card(this, 14)
        val cacheSize = folderSize(cacheDir)
        cacheCard.addView(Hb.text(this, Fmt.bytes(cacheSize), 17f, p.text, bold = true))
        cacheCard.addView(Hb.text(this, "Temporary files created by the app (thumbs, conversions, ZIPs)", 11f, p.muted).apply {
            setPadding(0, Hb.dp(this@StorageAnalyzerActivity, 3), 0, Hb.dp(this@StorageAnalyzerActivity, 8))
        })
        cacheCard.addView(Hb.button(this, "Clear app cache", false, R.drawable.ic_delete) {
            lifecycleScope.launch {
                val freed = withContext(Dispatchers.IO) { clearCache() }
                Hb.toast(this@StorageAnalyzerActivity, "Freed ${Fmt.bytes(freed)}")
                render()
            }
        })
        body.addView(cacheCard)

        body.addView(Hb.section(this, "Analyze a folder"))
        val scanCard = Hb.card(this, 14)
        scanCard.addView(Hb.text(this, "Pick any folder to see what is inside", 14.5f, p.text, medium = true))
        scanCard.addView(Hb.text(this, "The scan runs on your phone only. Very large folders are capped at 20,000 files.", 11f, p.muted).apply {
            setPadding(0, Hb.dp(this@StorageAnalyzerActivity, 3), 0, Hb.dp(this@StorageAnalyzerActivity, 8))
        })
        scanCard.addView(Hb.button(this, if (scanning) "Analyzing…" else "Choose a folder", true, R.drawable.ic_folder) {
            if (!scanning) pickFolder.launch(null)
        })
        body.addView(scanCard)
    }

    private fun typeRow(label: String, value: Long, max: Long): LinearLayout {
        val p = Hb.palette(this)
        return LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(Hb.dp(this@StorageAnalyzerActivity, 6), Hb.dp(this@StorageAnalyzerActivity, 8),
                Hb.dp(this@StorageAnalyzerActivity, 6), Hb.dp(this@StorageAnalyzerActivity, 8))
            val head = LinearLayout(this@StorageAnalyzerActivity).apply {
                orientation = LinearLayout.HORIZONTAL
                addView(Hb.text(this@StorageAnalyzerActivity, label, 13.5f, p.text).apply {
                    layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
                })
                addView(Hb.text(this@StorageAnalyzerActivity, Fmt.bytes(value), 11.5f, p.muted))
            }
            addView(head)
            val track = android.widget.FrameLayout(this@StorageAnalyzerActivity).apply {
                setBackgroundColor(p.surfaceAlt)
                layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, Hb.dp(this@StorageAnalyzerActivity, 6)).apply {
                    topMargin = Hb.dp(this@StorageAnalyzerActivity, 5)
                }
            }
            val fill = View(this@StorageAnalyzerActivity).apply {
                setBackgroundColor(p.blue)
            }
            track.addView(fill, android.widget.FrameLayout.LayoutParams(
                ((resources.displayMetrics.widthPixels - Hb.dp(this@StorageAnalyzerActivity, 84)) *
                    (value.toFloat() / max.toFloat())).toInt().coerceAtLeast(0),
                ViewGroup.LayoutParams.MATCH_PARENT
            ))
            addView(track)
        }
    }

    private data class BigFile(val uri: Uri, val name: String, val mime: String, val size: Long)

    private fun largestFiles(): List<BigFile> {
        val out = ArrayList<BigFile>()
        val files = MediaStore.Files.getContentUri(MediaStore.VOLUME_EXTERNAL)
        try {
            contentResolver.query(
                files,
                arrayOf(MediaStore.MediaColumns._ID, MediaStore.MediaColumns.DISPLAY_NAME,
                    MediaStore.MediaColumns.MIME_TYPE, MediaStore.MediaColumns.SIZE),
                null, null, "${MediaStore.MediaColumns.SIZE} DESC"
            )?.use { cur ->
                while (cur.moveToNext() && out.size < 25) {
                    val size = cur.getLong(3)
                    if (size <= 0) continue
                    out.add(
                        BigFile(
                            ContentUris.withAppendedId(files, cur.getLong(0)),
                            cur.getString(1) ?: "file",
                            cur.getString(2) ?: "*/*",
                            size
                        )
                    )
                }
            }
        } catch (_: Exception) {
        }
        return out
    }

    private fun categorySizes(): Map<String, Long> {
        val out = HashMap<String, Long>()
        out["videos"] = sum(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, null, null)
        out["images"] = sum(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, null, null)
        out["audio"] = sum(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, null, null)
        val files = MediaStore.Files.getContentUri(MediaStore.VOLUME_EXTERNAL)
        out["documents"] = sum(
            files,
            "(${MediaStore.MediaColumns.MIME_TYPE} = ? OR ${MediaStore.MediaColumns.MIME_TYPE} LIKE ? OR " +
                "${MediaStore.MediaColumns.MIME_TYPE} = ? OR ${MediaStore.MediaColumns.MIME_TYPE} = ? OR " +
                "${MediaStore.MediaColumns.MIME_TYPE} = ? OR ${MediaStore.MediaColumns.MIME_TYPE} = ?)",
            arrayOf("application/pdf", "text/%", "application/msword",
                "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
                "application/vnd.ms-excel",
                "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")
        )
        out["apk"] = sum(
            files,
            "${MediaStore.MediaColumns.MIME_TYPE} = ?",
            arrayOf("application/vnd.android.package-archive")
        )
        out["downloads"] = sum(
            files,
            "${MediaStore.MediaColumns.RELATIVE_PATH} LIKE ?",
            arrayOf("Download%")
        )
        val all = sum(files, null, null)
        val known = (out["videos"] ?: 0) + (out["images"] ?: 0) + (out["audio"] ?: 0) +
            (out["apk"] ?: 0) + (out["documents"] ?: 0)
        out["other"] = (all - known).coerceAtLeast(0)
        return out
    }

    private fun sum(uri: Uri, selection: String?, args: Array<String>?): Long {
        return try {
            contentResolver.query(uri, arrayOf("SUM(${MediaStore.MediaColumns.SIZE})"), selection, args, null)
                ?.use { if (it.moveToFirst()) it.getLong(0) else 0L } ?: 0L
        } catch (_: Exception) {
            0L
        }
    }

    private fun iconFor(mime: String): Int = when {
        mime.startsWith("video/") -> R.drawable.ic_play
        mime.startsWith("audio/") -> R.drawable.ic_music
        mime.startsWith("image/") -> R.drawable.ic_image
        mime == "application/pdf" -> R.drawable.ic_pdf
        else -> R.drawable.ic_file
    }

    private fun folderSize(f: File): Long {
        if (!f.exists()) return 0
        if (f.isFile) return f.length()
        var total = 0L
        try {
            f.listFiles()?.forEach { total += folderSize(it) }
        } catch (_: Exception) {
        }
        return total
    }

    private fun clearCache(): Long {
        var freed = 0L
        try {
            cacheDir.listFiles()?.forEach { child ->
                val size = folderSize(child)
                if (child.deleteRecursively()) freed += size
            }
        } catch (_: Exception) {
        }
        return freed
    }

    private fun scanFolder(tree: Uri) {
        if (scanning) return
        scanning = true
        val status = TextView(this).apply {
            text = "Analyzing…"
            setTextColor(Hb.palette(this@StorageAnalyzerActivity).muted)
            textSize = 12f
            setPadding(Hb.dp(this@StorageAnalyzerActivity, 4), Hb.dp(this@StorageAnalyzerActivity, 8), 0, 0)
        }
        body.addView(status)
        lifecycleScope.launch {
            val result = withContext(Dispatchers.IO) { analyze(tree) }
            scanning = false
            body.removeView(status)
            showScanResult(tree, result)
        }
    }

    private data class ScanEntry(val name: String, val size: Long, val files: Int)

    private fun analyze(tree: Uri): List<ScanEntry> {
        val root = DocumentFile.fromTreeUri(this, tree) ?: return emptyList()
        var budget = 20_000
        fun walk(dir: DocumentFile, depth: Int): Pair<Long, Int> {
            var size = 0L
            var files = 0
            if (depth > 10 || budget <= 0) return 0L to 0
            val children = try { dir.listFiles() } catch (_: Exception) { emptyArray() }
            children.forEach { child ->
                if (budget <= 0) return@forEach
                budget--
                if (child.isDirectory) {
                    val (s, n) = walk(child, depth + 1)
                    size += s
                    files += n
                } else {
                    size += child.length()
                    files++
                }
            }
            return size to files
        }
        val entries = ArrayList<ScanEntry>()
        val children = try { root.listFiles() } catch (_: Exception) { emptyArray() }
        children.forEach { child ->
            if (child.isDirectory) {
                val (s, n) = walk(child, 1)
                entries.add(ScanEntry(child.name ?: "Folder", s, n))
            } else {
                entries.add(ScanEntry(child.name ?: "File", child.length(), 1))
            }
        }
        return entries.sortedByDescending { it.size }.take(30)
    }

    private fun showScanResult(tree: Uri, entries: List<ScanEntry>) {
        val p = Hb.palette(this)
        body.addView(Hb.section(this, "Folder breakdown"))
        if (entries.isEmpty()) {
            body.addView(Hb.empty(this, R.drawable.ic_folder, "Nothing to show", "This folder is empty or Android did not grant access"))
            return
        }
        val total = entries.sumOf { it.size }
        val card = Hb.card(this, 16)
        card.addView(Hb.text(this, "${Fmt.bytes(total)} in ${entries.size} item(s)", 16f, p.text, bold = true))
        val label = try {
            android.provider.DocumentsContract.getTreeDocumentId(tree).substringAfter(':').ifBlank { "Selected folder" }
        } catch (_: Exception) {
            "Selected folder"
        }
        card.addView(Hb.text(this, label, 11f, p.muted))
        body.addView(card)

        val list = Hb.card(this, 6).apply {
            (layoutParams as LinearLayout.LayoutParams).topMargin = Hb.dp(this@StorageAnalyzerActivity, 10)
        }
        val max = (entries.maxOfOrNull { it.size } ?: 1L).coerceAtLeast(1L)
        entries.forEachIndexed { index, entry ->
            list.addView(typeRow(entry.name, entry.size, max))
            if (index != entries.lastIndex) list.addView(Hb.divider(this@StorageAnalyzerActivity, 4))
        }
        body.addView(list)
    }
}
