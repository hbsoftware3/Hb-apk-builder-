package com.example.videodownloader

/**
 * Reads the extra details (speed, time left) out of one yt-dlp progress line, e.g.
 * "[download]  45.3% of ~  10.00MiB at    1.20MiB/s ETA 01:02:03 (frag 3/10)".
 * The library's own time-left reading breaks for downloads longer than one hour, so it is done here.
 */
object ProgressInfo {
    private val speedRx = Regex("""\sat\s+(\d+(?:\.\d+)?)\s*([KMGT]?i?B)/s""")
    private val totalRx = Regex("""\sof\s+~?\s*(\d+(?:\.\d+)?)\s*([KMGT]?)i?B""")
    private val etaRx = Regex("""ETA\s+(?:(\d+):)?(\d+):(\d+)""")

    /** "1.20 MiB/s", or null when the line shows no speed. */
    fun speed(line: String): String? {
        val m = speedRx.find(line) ?: return null
        return "${m.groupValues[1]} ${m.groupValues[2]}/s"
    }

    /** Seconds left from "ETA 1:02:03" or "ETA 02:03", or null when the line has none ("ETA Unknown"). */
    fun etaSeconds(line: String): Long? {
        val m = etaRx.find(line) ?: return null
        val h = m.groupValues[1].toLongOrNull() ?: 0L
        val min = m.groupValues[2].toLongOrNull() ?: return null
        val s = m.groupValues[3].toLongOrNull() ?: return null
        return h * 3600 + min * 60 + s
    }

    /** 3725 -> "1:02:05", 125 -> "2:05" */
    fun clock(sec: Long): String {
        val h = sec / 3600
        val m = (sec % 3600) / 60
        val s = sec % 60
        val ss = s.toString().padStart(2, '0')
        return if (h > 0) "$h:${m.toString().padStart(2, '0')}:$ss" else "$m:$ss"
    }

    /** Total size in bytes from "45.3% of ~ 10.00MiB at ...", or null when the line shows none. */
    fun totalBytes(line: String): Long? {
        val m = totalRx.find(line) ?: return null
        val n = m.groupValues[1].toDoubleOrNull() ?: return null
        val mul = when (m.groupValues[2]) {
            "K" -> 1024.0
            "M" -> 1024.0 * 1024
            "G" -> 1024.0 * 1024 * 1024
            "T" -> 1024.0 * 1024 * 1024 * 1024
            else -> 1.0
        }
        return (n * mul).toLong()
    }
}
