package com.example.videodownloader.util

import android.content.ContentUris
import android.content.Context
import android.net.Uri
import android.provider.MediaStore

data class MediaFile(
    val uri: Uri,
    val name: String,
    val mime: String,
    val size: Long,
    val dateMs: Long,
    val durationMs: Long = 0L
)

object MediaIndex {

    private fun query(
        c: Context,
        uri: Uri,
        projection: Array<String>,
        sort: String,
        limit: Int,
        idCol: String,
        nameCol: String,
        sizeCol: String,
        dateCol: String,
        mimeCol: String,
        durationCol: String?
    ): List<MediaFile> {
        val out = ArrayList<MediaFile>()
        try {
            c.contentResolver.query(uri, projection, null, null, sort)?.use { cur ->
                val idI = cur.getColumnIndexOrThrow(idCol)
                val nameI = cur.getColumnIndexOrThrow(nameCol)
                val sizeI = cur.getColumnIndexOrThrow(sizeCol)
                val dateI = cur.getColumnIndexOrThrow(dateCol)
                val mimeI = cur.getColumnIndexOrThrow(mimeCol)
                val durI = if (durationCol != null) cur.getColumnIndex(durationCol) else -1
                while (cur.moveToNext() && out.size < limit) {
                    val id = cur.getLong(idI)
                    out.add(
                        MediaFile(
                            uri = ContentUris.withAppendedId(uri, id),
                            name = cur.getString(nameI) ?: "media",
                            mime = cur.getString(mimeI) ?: "*/*",
                            size = cur.getLong(sizeI),
                            dateMs = cur.getLong(dateI) * 1000L,
                            durationMs = if (durI >= 0) cur.getLong(durI) else 0L
                        )
                    )
                }
            }
        } catch (_: Exception) {
        }
        return out
    }

    fun videos(c: Context, limit: Int = 100): List<MediaFile> = query(
        c, MediaStore.Video.Media.EXTERNAL_CONTENT_URI,
        arrayOf(
            MediaStore.Video.Media._ID, MediaStore.Video.Media.DISPLAY_NAME,
            MediaStore.Video.Media.SIZE, MediaStore.Video.Media.DATE_MODIFIED,
            MediaStore.Video.Media.MIME_TYPE, MediaStore.Video.Media.DURATION
        ),
        "${MediaStore.Video.Media.DATE_MODIFIED} DESC", limit,
        MediaStore.Video.Media._ID, MediaStore.Video.Media.DISPLAY_NAME,
        MediaStore.Video.Media.SIZE, MediaStore.Video.Media.DATE_MODIFIED,
        MediaStore.Video.Media.MIME_TYPE, MediaStore.Video.Media.DURATION
    )

    fun audio(c: Context, limit: Int = 100): List<MediaFile> = query(
        c, MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,
        arrayOf(
            MediaStore.Audio.Media._ID, MediaStore.Audio.Media.DISPLAY_NAME,
            MediaStore.Audio.Media.SIZE, MediaStore.Audio.Media.DATE_MODIFIED,
            MediaStore.Audio.Media.MIME_TYPE, MediaStore.Audio.Media.DURATION
        ),
        "${MediaStore.Audio.Media.DATE_MODIFIED} DESC", limit,
        MediaStore.Audio.Media._ID, MediaStore.Audio.Media.DISPLAY_NAME,
        MediaStore.Audio.Media.SIZE, MediaStore.Audio.Media.DATE_MODIFIED,
        MediaStore.Audio.Media.MIME_TYPE, MediaStore.Audio.Media.DURATION
    )

    fun images(c: Context, limit: Int = 100): List<MediaFile> = query(
        c, MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
        arrayOf(
            MediaStore.Images.Media._ID, MediaStore.Images.Media.DISPLAY_NAME,
            MediaStore.Images.Media.SIZE, MediaStore.Images.Media.DATE_MODIFIED,
            MediaStore.Images.Media.MIME_TYPE
        ),
        "${MediaStore.Images.Media.DATE_MODIFIED} DESC", limit,
        MediaStore.Images.Media._ID, MediaStore.Images.Media.DISPLAY_NAME,
        MediaStore.Images.Media.SIZE, MediaStore.Images.Media.DATE_MODIFIED,
        MediaStore.Images.Media.MIME_TYPE, null
    )

    fun recent(c: Context, limit: Int = 12): List<MediaFile> =
        (videos(c, 20) + audio(c, 20) + images(c, 20)).sortedByDescending { it.dateMs }.take(limit)

    fun allSize(c: Context): Long {
        var total = 0L
        fun sum(uri: Uri, col: String) {
            try {
                c.contentResolver.query(uri, arrayOf("SUM($col)"), null, null, null)?.use { cur ->
                    if (cur.moveToFirst()) total += cur.getLong(0)
                }
            } catch (_: Exception) {
            }
        }
        sum(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, MediaStore.Video.Media.SIZE)
        sum(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, MediaStore.Audio.Media.SIZE)
        sum(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, MediaStore.Images.Media.SIZE)
        return total
    }
}
