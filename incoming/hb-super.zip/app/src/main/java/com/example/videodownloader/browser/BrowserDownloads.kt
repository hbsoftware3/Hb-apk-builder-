package com.example.videodownloader.browser

import android.app.DownloadManager
import android.content.Context
import android.net.Uri
import android.os.Environment
import android.webkit.MimeTypeMap
import android.webkit.URLUtil
import androidx.documentfile.provider.DocumentFile
import com.example.videodownloader.Prefs
import com.example.videodownloader.R
import com.example.videodownloader.ui.Hb
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

data class BrowserDownload(
    val id: Long,
    val url: String,
    val name: String,
    val mime: String,
    val status: Int,
    val downloaded: Long,
    val total: Long,
    val reason: Int,
    val time: Long,
    val saved: Boolean,
    val userAgent: String? = null,
    val referer: String? = null
) {
    val running: Boolean get() = status == DownloadManager.STATUS_RUNNING || status == DownloadManager.STATUS_PENDING
    val done: Boolean get() = status == DownloadManager.STATUS_SUCCESSFUL
    val failed: Boolean get() = status == DownloadManager.STATUS_FAILED
    val progress: Int
        get() = if (total > 0) ((downloaded * 100) / total).toInt().coerceIn(0, 100) else 0
}

/**
 * Browser downloads through Android's DownloadManager. Files land in the app's own
 * Downloads folder (no storage permission needed) and can be copied into a folder the
 * user picked with the Storage Access Framework.
 */
object BrowserDownloads {

    private const val PREFS = "hb_browser_dl"
    private const val KEY_ITEMS = "items"

    private data class Tracked(
        val id: Long,
        val url: String,
        val name: String,
        val mime: String,
        val time: Long,
        var saved: Boolean,
        val userAgent: String? = null,
        val referer: String? = null
    )

    private fun sp(c: Context) = c.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
    private fun dm(c: Context) = c.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager

    fun dir(c: Context): File =
        (c.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS) ?: File(c.filesDir, "downloads"))
            .apply { if (!exists()) mkdirs() }

    fun fileFor(c: Context, name: String): File = File(dir(c), name)

    fun guessName(url: String, disposition: String?, mime: String?): String {
        val name = try {
            URLUtil.guessFileName(url, disposition, mime)
        } catch (_: Exception) {
            ""
        }
        return if (name.isBlank()) "download_${System.currentTimeMillis()}" else name
    }

    fun guessMime(url: String, fallback: String? = null): String {
        val ext = MimeTypeMap.getFileExtensionFromUrl(url)
        if (!ext.isNullOrBlank()) {
            MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext.lowercase())?.let { return it }
        }
        return fallback?.takeIf { it.contains("/") && it != "application/octet-stream" } ?: "application/octet-stream"
    }

    fun isDownloading(c: Context, url: String): Boolean =
        tracked(c).any { it.url == url && isRunning(c, it.id) }

    private fun safeName(raw: String): String {
        val base = raw.substringAfterLast('/').substringAfterLast('\\').trim()
        val cleaned = base.replace(Regex("[\\u0000-\\u001F:*?\"<>|]"), "_").take(120)
        return cleaned.ifBlank { "download_${System.currentTimeMillis()}" }
    }

    /** DownloadManager refuses to overwrite a destination, so give repeated names a " (2)" suffix. */
    private fun uniqueName(c: Context, name: String): String {
        if (!File(dir(c), name).exists()) return name
        val dot = name.lastIndexOf('.')
        val base = if (dot > 0) name.substring(0, dot) else name
        val ext = if (dot > 0) name.substring(dot) else ""
        var i = 2
        while (File(dir(c), "$base ($i)$ext").exists()) i++
        return "$base ($i)$ext"
    }

    fun enqueue(
        c: Context,
        url: String,
        userAgent: String?,
        cookie: String?,
        referer: String?,
        mime: String?,
        suggestedName: String?,
        wifiOnly: Boolean,
        contentDisposition: String? = null
    ): Long? {
        if (!BrowserUrl.isHttp(url)) return null
        val type = if (!mime.isNullOrBlank() && mime != "application/octet-stream") mime
        else guessMime(url, mime)
        val requested = suggestedName?.takeIf { it.isNotBlank() }
            ?: guessName(url, contentDisposition, type)
        val name = uniqueName(c, safeName(requested))

        // DownloadManager cannot report favourites, so guard duplicates from our own list.
        val duplicate = tracked(c).firstOrNull { it.url == url && isRunning(c, it.id) }
        if (duplicate != null) {
            Hb.toast(c, "This file is already downloading")
            return duplicate.id
        }

        return try {
            val request = DownloadManager.Request(Uri.parse(url)).apply {
                setTitle(name)
                setDescription("HB Browser")
                setMimeType(type)
                setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                setAllowedOverMetered(!wifiOnly)
                setAllowedOverRoaming(false)
                userAgent?.takeIf { it.isNotBlank() }?.let { addRequestHeader("User-Agent", it) }
                referer?.takeIf { it.isNotBlank() }?.let { addRequestHeader("Referer", it) }
                cookie?.takeIf { it.isNotBlank() }?.let { addRequestHeader("Cookie", it) }
                setDestinationInExternalFilesDir(c, Environment.DIRECTORY_DOWNLOADS, name)
                allowScanningByMediaScanner()
            }
            val id = dm(c).enqueue(request)
            val list = tracked(c)
            list.add(Tracked(id, url, name, type, System.currentTimeMillis(), false, userAgent, referer))
            write(c, list)
            id
        } catch (e: Exception) {
            Hb.toast(c, "Could not start this download")
            null
        }
    }

    fun list(c: Context): List<BrowserDownload> {
        val managed = dm(c)
        val out = ArrayList<BrowserDownload>()
        for (t in tracked(c)) {
            try {
                managed.query(DownloadManager.Query().setFilterById(t.id))?.use { cur ->
                    if (cur.moveToFirst()) {
                        out.add(
                            BrowserDownload(
                                id = t.id,
                                url = t.url,
                                name = t.name,
                                mime = t.mime,
                                status = cur.getInt(cur.getColumnIndexOrThrow(DownloadManager.COLUMN_STATUS)),
                                downloaded = cur.getLong(cur.getColumnIndexOrThrow(DownloadManager.COLUMN_BYTES_DOWNLOADED_SO_FAR)),
                                total = cur.getLong(cur.getColumnIndexOrThrow(DownloadManager.COLUMN_TOTAL_SIZE_BYTES)),
                                reason = cur.getInt(cur.getColumnIndexOrThrow(DownloadManager.COLUMN_REASON)),
                                time = t.time,
                                saved = t.saved,
                                userAgent = t.userAgent,
                                referer = t.referer
                            )
                        )
                    }
                }
            } catch (_: Exception) {
            }
        }
        return out.sortedByDescending { it.time }
    }

    fun activeCount(c: Context): Int = list(c).count { it.running }

    fun exists(c: Context, id: Long): Boolean = tracked(c).any { it.id == id }

    fun markSaved(c: Context, id: Long) {
        val list = tracked(c)
        list.firstOrNull { it.id == id }?.saved = true
        write(c, list)
    }

    /**
     * Copies a finished download into the user-picked SAF folder.
     * Returns true when the copy was written.
     */
    fun copyToUserFolder(c: Context, item: BrowserDownload): Boolean {
        val tree = Prefs.browserDownloadTree(c) ?: return false
        val file = fileFor(c, item.name)
        if (!file.exists()) return false
        return try {
            val treeDoc = DocumentFile.fromTreeUri(c, Uri.parse(tree)) ?: return false
            if (!treeDoc.canWrite()) return false
            val existing = treeDoc.findFile(item.name)
            if (existing != null && existing.isFile) {
                // Overwrite the previous copy instead of creating "file (1).ext" duplicates.
                c.contentResolver.openOutputStream(existing.uri, "wt")?.use { out ->
                    file.inputStream().use { it.copyTo(out) }
                }
                markSaved(c, item.id)
                return true
            }
            val mime = item.mime.ifBlank { guessMime(item.url) }
            val doc = treeDoc.createFile(mime, file.name) ?: return false
            c.contentResolver.openOutputStream(doc.uri)?.use { out ->
                file.inputStream().use { it.copyTo(out) }
            }
            markSaved(c, item.id)
            true
        } catch (_: Exception) {
            false
        }
    }

    /** Called periodically; copies completed downloads when the user enabled a folder. */
    fun autoSaveCompleted(c: Context) {
        if (Prefs.browserDownloadTree(c) == null) return
        list(c).filter { it.done && !it.saved }.take(4).forEach { copyToUserFolder(c, it) }
    }

    fun cancel(c: Context, id: Long) {
        try {
            dm(c).remove(id)
        } catch (_: Exception) {
        }
        removeRecord(c, id)
    }

    fun removeRecord(c: Context, id: Long) {
        val name = tracked(c).firstOrNull { it.id == id }?.name
        write(c, tracked(c).filter { it.id != id })
        try {
            if (name != null) {
                val file = fileFor(c, name)
                if (file.exists() && file.parentFile?.canonicalPath == dir(c).canonicalPath) file.delete()
            }
        } catch (_: Exception) {
        }
    }

    fun clearFinished(c: Context) {
        list(c).filter { it.done || it.failed }.forEach { removeRecord(c, it.id) }
    }

    fun statusLabel(c: Context, item: BrowserDownload): String = when {
        item.done -> "Completed"
        item.failed -> failureReason(c, item.reason)
        item.status == DownloadManager.STATUS_PAUSED -> "Paused"
        item.running -> if (item.total > 0) "${item.progress}% • ${item.downloaded / 1024} KB" else "Downloading…"
        else -> "Queued"
    }

    private fun failureReason(c: Context, reason: Int): String = when (reason) {
        DownloadManager.ERROR_INSUFFICIENT_SPACE -> "Not enough storage"
        DownloadManager.ERROR_FILE_ERROR -> "Could not write the file"
        DownloadManager.ERROR_HTTP_DATA_ERROR -> "Download interrupted"
        DownloadManager.ERROR_TOO_MANY_REDIRECTS -> "Too many redirects"
        DownloadManager.ERROR_UNHANDLED_HTTP_CODE -> "Server refused the file"
        DownloadManager.ERROR_CANNOT_RESUME -> "Could not resume"
        DownloadManager.ERROR_UNKNOWN -> "Download failed"
        else -> "Download failed"
    }

    fun notificationIcon(): Int = android.R.drawable.stat_sys_download_done

    private fun isRunning(c: Context, id: Long): Boolean = try {
        dm(c).query(DownloadManager.Query().setFilterById(id))?.use { cur ->
            cur.moveToFirst() && (cur.getInt(cur.getColumnIndexOrThrow(DownloadManager.COLUMN_STATUS)) == DownloadManager.STATUS_RUNNING ||
                cur.getInt(cur.getColumnIndexOrThrow(DownloadManager.COLUMN_STATUS)) == DownloadManager.STATUS_PENDING ||
                cur.getInt(cur.getColumnIndexOrThrow(DownloadManager.COLUMN_STATUS)) == DownloadManager.STATUS_PAUSED)
        } ?: false
    } catch (_: Exception) {
        false
    }

    private fun tracked(c: Context): MutableList<Tracked> {
        val out = ArrayList<Tracked>()
        val raw = sp(c).getString(KEY_ITEMS, null) ?: return out
        try {
            val arr = JSONArray(raw)
            for (i in 0 until arr.length()) {
                val o = arr.optJSONObject(i) ?: continue
                val id = o.optLong("id", -1)
                if (id <= 0) continue
                out.add(Tracked(
                    id,
                    o.optString("url"),
                    o.optString("name"),
                    o.optString("mime"),
                    o.optLong("time"),
                    o.optBoolean("saved"),
                    o.optString("ua").takeIf { it.isNotBlank() },
                    o.optString("referer").takeIf { it.isNotBlank() }
                ))
            }
        } catch (_: Exception) {
        }
        return out
    }

    private fun write(c: Context, list: List<Tracked>) {
        val arr = JSONArray()
        list.takeLast(150).forEach {
            arr.put(JSONObject().apply {
                put("id", it.id)
                put("url", it.url)
                put("name", it.name)
                put("mime", it.mime)
                put("time", it.time)
                put("saved", it.saved)
                it.userAgent?.let { ua -> put("ua", ua) }
                it.referer?.let { ref -> put("referer", ref) }
            })
        }
        sp(c).edit().putString(KEY_ITEMS, arr.toString()).apply()
    }
}
