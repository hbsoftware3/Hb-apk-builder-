package com.example.videodownloader

import android.Manifest
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat

/** Separate screen for the WhatsApp / WhatsApp Business status saver. */
class StatusActivity : AppCompatActivity() {

    private lateinit var statusPane: StatusPane
    private var pendingApp: WaApp? = null

    /** Android's folder picker, used once to allow reading WhatsApp statuses. */
    private val pickTree =
        registerForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri: Uri? ->
            val app = pendingApp
            if (uri != null && app != null) statusPane.onAccessResult(app, uri)
        }

    /** Android 10 only: normal storage permission. Android 11+ uses the "All files access" screen instead. */
    private val askStorage =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) {
            if (::statusPane.isInitialized) statusPane.refresh()
        }

    private fun requestDirect() {
        if (Build.VERSION.SDK_INT >= 30) StatusRepo.openAllFilesSettings(this)
        else askStorage.launch(Manifest.permission.READ_EXTERNAL_STORAGE)
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Updater.blockIfForced(this)) return // forced update pending

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(ContextCompat.getColor(this@StatusActivity, R.color.hb_bg))
            setPadding(dp(18), dp(18), dp(18), dp(18))
        }

        // Top bar: title + Back
        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        bar.addView(TextView(this).apply {
            text = "WhatsApp Status"
            setTextColor(0xFFFFFFFF.toInt())
            textSize = 20f
            typeface = android.graphics.Typeface.DEFAULT_BOLD
        }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        bar.addView(Button(this).apply {
            text = "Back"
            isAllCaps = false
            setTextColor(0xFFFFFFFF.toInt())
            background = ContextCompat.getDrawable(this@StatusActivity, R.drawable.bg_btn_secondary)
            minHeight = 0
            minimumHeight = 0
            setPadding(dp(16), 0, dp(16), 0)
            setOnClickListener { finish() }
        }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(40)))
        root.addView(bar)

        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(
            box,
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
                .apply { topMargin = dp(14) }
        )

        setContentView(ScrollView(this).apply {
            isFillViewport = true
            addView(root)
        })

        statusPane = StatusPane(
            this, box,
            askAccess = { app, legacy ->
                pendingApp = app
                try {
                    pickTree.launch(StatusRepo.initialUri(app, legacy))
                } catch (e: Exception) {
                    Toast.makeText(this, "Cannot open the folder picker on this phone", Toast.LENGTH_LONG).show()
                }
            },
            askDirect = { requestDirect() }
        )
        statusPane.build()
    }

    /** New statuses may have appeared while the app was in the background. */
    override fun onResume() {
        super.onResume()
        if (::statusPane.isInitialized) statusPane.refresh()
    }
}
