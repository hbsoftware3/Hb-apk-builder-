#!/usr/bin/env python3
"""Reads versionCode/versionName from app/build.gradle.kts and rewrites update-v1.json.

usage: update_json.py <owner/repo> <tag> [--notes "text"] [--sha256 HEX] [--force] [--check]
notes order: --notes text, then release_notes.txt in the repo root, then old notes / default text
  --check : only verify versionCode is not lower than the one already in update-v1.json
"""
import argparse, json, re, sys, pathlib

root = pathlib.Path(__file__).resolve().parents[2]
gradle = (root / "app" / "build.gradle.kts").read_text(encoding="utf-8")
vc = int(re.search(r"versionCode\s*=\s*(\d+)", gradle).group(1))
vn = re.search(r'versionName\s*=\s*"([^"]+)"', gradle).group(1)

jpath = root / "update-v1.json"
old = json.loads(jpath.read_text(encoding="utf-8")) if jpath.exists() else {}

ap = argparse.ArgumentParser()
ap.add_argument("repo", nargs="?")
ap.add_argument("tag", nargs="?")
ap.add_argument("--notes", default="")
ap.add_argument("--sha256", default="")
ap.add_argument("--force", action="store_true")
ap.add_argument("--check", action="store_true")
a = ap.parse_args()

old_vc = int(old.get("versionCode", 0))
if vc < old_vc:
    sys.exit(f"ERROR: versionCode in build.gradle.kts ({vc}) is LOWER than update-v1.json ({old_vc}). Increase it.")
if a.check:
    if vc == old_vc:
        print(f"WARNING: versionCode {vc} is same as update-v1.json - phones will NOT see this as an update.")
    print(f"versionCode={vc} versionName={vn}")
    sys.exit(0)

notes = a.notes.strip()
nf = root / "release_notes.txt"
if not notes and nf.exists():
    notes = nf.read_text(encoding="utf-8").strip()
if not notes:
    notes = old.get("notes", "") if vc == old_vc else f"HB Super App {vn}: improvements and bug fixes."

new = {
    "versionCode": vc,
    "versionName": vn,
    "apkUrl": f"https://github.com/{a.repo}/releases/download/{a.tag}/app-release.apk",
    "minVersionCode": vc if a.force else int(old.get("minVersionCode", 0)),
    "notes": notes,
}
if a.sha256:
    new["sha256"] = a.sha256.strip().lower()
jpath.write_text(json.dumps(new, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
print(json.dumps(new, indent=2, ensure_ascii=False))
