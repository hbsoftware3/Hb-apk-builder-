# HB SUPER APP

All-in-one Android app by **HB Software**: video downloads, a built-in browser, a media player, a file manager, a converter and smart tools in one dark, modern interface.

[![Latest release](https://img.shields.io/github/v/release/hbsoftware3/Hb?label=download)](https://github.com/hbsoftware3/Hb/releases/latest)

- Version: `1.0` (`versionCode 1`)
- Package: `com.hbsoftware.aio`
- Requires Android 10 (API 29) or newer
- Credit: **Hakim Zaib**

## Download

1. Open the [Releases page](https://github.com/hbsoftware3/Hb/releases/latest).
2. Download `app-release.apk`.
3. Install it. Android may ask you to allow *Install unknown apps* for your browser or file manager.

This is a new app with a new signing key. It installs next to older versions and does not replace them. You can uninstall the old one after the new one works.

## Features

- **Home, Downloads, Browser, Tools, Library** tabs, plus Settings, search and notifications.
- **Downloads:** video and audio from YouTube, Instagram, TikTok, Facebook, X, Reddit, Vimeo and more. Quality picker, queue, pause and resume, Wi-Fi only mode, share a link to the app to download it.
- **Instagram login:** log in once inside the built-in browser and shared Instagram links download with that login.
- **Copied link offer:** copy a link, open the app and tap Download.
- **HB Browser:** tabs, private tabs, bookmarks, history, ad and tracker blocking, find in page, reader mode, desktop mode, video download button on video pages.
- **Media Player:** video and music, queue, subtitles, speed, aspect ratio, screen lock, gestures, picture-in-picture, background audio, resume.
- **File Manager:** search, sort, rename, copy, move, delete, ZIP.
- **Converter Studio:** video to MP3, audio convert, trim, compress, GIF, image convert and compress, images to PDF.
- **Smart tools:** QR scan and generate, PDF viewer, image viewer, ringtone maker, storage analyzer, file search, text tools, WhatsApp status saver.

## Privacy

- Browsing history is never uploaded.
- Websites cannot read local files, and SSL errors are never bypassed.
- Cookie files used for downloads are deleted as soon as the download ends.
- No Firebase keys or secrets inside the app.

## Updates

The app reads `update-v1.json` from this repository and offers new versions automatically.

To publish a new version:
1. Open `app/build.gradle.kts`, raise `versionCode` (for example 2) and change `versionName`.
2. Optionally edit `release_notes.txt`.
3. Go to **Actions**, choose **Build APK + Release + Update JSON** and press **Run workflow**.

The workflow builds a signed APK, creates a GitHub Release and updates `update-v1.json`.

## Signing key (important)

- The signing key is stored encrypted in `signing/hbkey.jks.enc`.
- The password is stored only in the repository secret `KEYSTORE_PASSWORD`.
- Write the password down and keep a copy somewhere safe. If the password or key is lost, users cannot update the app and must uninstall it first.
- Keep this repository **public**, otherwise the app cannot read updates.

## Build

First time only:
1. Add the secret `KEYSTORE_PASSWORD` (16 or more characters).
2. Run **Create signing key (run ONCE)**.
3. Run **Build APK + Release + Update JSON**.

Local build (Android Studio): open the project and run `./gradlew assembleRelease` with the signing environment variables set.

## Tech

Kotlin, AndroidX, Media3 ExoPlayer, youtubedl-android (yt-dlp + FFmpeg), ZXing. Compiled with SDK 35, targets Android 14 (API 34).
